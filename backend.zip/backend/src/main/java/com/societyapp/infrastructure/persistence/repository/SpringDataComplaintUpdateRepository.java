package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.ComplaintUpdate;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataComplaintUpdateRepository
        extends JpaRepository<ComplaintUpdate, UUID>,
                com.societyapp.repository.ComplaintUpdateRepository {
    List<ComplaintUpdate> findByComplaintIdOrderByCreatedAt(UUID complaintId);
}
