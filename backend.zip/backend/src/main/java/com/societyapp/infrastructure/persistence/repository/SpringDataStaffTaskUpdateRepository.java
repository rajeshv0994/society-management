package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.StaffTaskUpdate;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataStaffTaskUpdateRepository
        extends JpaRepository<StaffTaskUpdate, UUID>,
                com.societyapp.repository.StaffTaskUpdateRepository {
    List<StaffTaskUpdate> findByTaskIdOrderByCreatedAt(UUID taskId);
}
