package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.SubscriptionPlan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataSubscriptionPlanRepository
        extends JpaRepository<SubscriptionPlan, String>,
                com.societyapp.repository.SubscriptionPlanRepository {}
