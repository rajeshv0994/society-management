package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.PlatformPaymentAttempt;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataPlatformPaymentAttemptRepository
        extends JpaRepository<PlatformPaymentAttempt, UUID>,
                com.societyapp.repository.PlatformPaymentAttemptRepository {
    Optional<PlatformPaymentAttempt> findByProviderOrderId(String providerOrderId);

    Optional<PlatformPaymentAttempt> findByProviderPaymentId(String providerPaymentId);

    List<PlatformPaymentAttempt> findBySubscriptionOrderIdOrderByCreatedAtDesc(UUID orderId);
}
