package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.SetupCode;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataSetupCodeRepository
        extends JpaRepository<SetupCode, UUID>, com.societyapp.repository.SetupCodeRepository {
    List<SetupCode> findByStatusOrderByCreatedAtDesc(String status);
}
