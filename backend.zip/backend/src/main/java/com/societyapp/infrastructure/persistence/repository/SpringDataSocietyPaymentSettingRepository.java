package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.SocietyPaymentSetting;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataSocietyPaymentSettingRepository
        extends JpaRepository<SocietyPaymentSetting, UUID>,
                com.societyapp.repository.SocietyPaymentSettingRepository {
    Optional<SocietyPaymentSetting> findBySocietyId(UUID societyId);
}
