package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.Complaint;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataComplaintRepository
        extends JpaRepository<Complaint, UUID>, com.societyapp.repository.ComplaintRepository {
    List<Complaint> findBySocietyIdOrderByCreatedAtDesc(UUID societyId);

    List<Complaint> findBySocietyIdAndRaisedByOrderByCreatedAtDesc(UUID societyId, UUID raisedBy);

    Optional<Complaint> findByIdAndSocietyId(UUID id, UUID societyId);
}
