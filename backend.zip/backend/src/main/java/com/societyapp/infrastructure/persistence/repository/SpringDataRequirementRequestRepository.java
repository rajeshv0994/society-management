package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.RequirementRequest;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataRequirementRequestRepository
        extends JpaRepository<RequirementRequest, UUID>,
                com.societyapp.repository.RequirementRequestRepository {
    List<RequirementRequest> findAllByOrderByCreatedAtDesc();

    List<RequirementRequest> findBySocietyIdOrderByCreatedAtDesc(UUID societyId);
}
