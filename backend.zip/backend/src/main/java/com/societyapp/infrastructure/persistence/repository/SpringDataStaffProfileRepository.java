package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.StaffProfile;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataStaffProfileRepository
        extends JpaRepository<StaffProfile, UUID>,
                com.societyapp.repository.StaffProfileRepository {}
