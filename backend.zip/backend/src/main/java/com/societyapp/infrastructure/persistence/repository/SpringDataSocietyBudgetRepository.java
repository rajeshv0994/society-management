package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.SocietyBudget;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataSocietyBudgetRepository
        extends JpaRepository<SocietyBudget, UUID>,
                com.societyapp.repository.SocietyBudgetRepository {
    Optional<SocietyBudget> findBySocietyIdAndBudgetYear(UUID societyId, int budgetYear);
}
