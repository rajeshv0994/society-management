package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.ComplaintCategory;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataComplaintCategoryRepository
        extends JpaRepository<ComplaintCategory, UUID>,
                com.societyapp.repository.ComplaintCategoryRepository {
    List<ComplaintCategory> findBySocietyIdOrderByName(UUID societyId);

    Optional<ComplaintCategory> findByIdAndSocietyId(UUID id, UUID societyId);

    boolean existsBySocietyIdAndNameIgnoreCase(UUID societyId, String name);

    boolean existsBySocietyIdAndNameIgnoreCaseAndIdNot(UUID societyId, String name, UUID id);
}
