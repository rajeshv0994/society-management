package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.VerificationChallenge;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataVerificationChallengeRepository
        extends JpaRepository<VerificationChallenge, UUID>,
                com.societyapp.repository.VerificationChallengeRepository {}
