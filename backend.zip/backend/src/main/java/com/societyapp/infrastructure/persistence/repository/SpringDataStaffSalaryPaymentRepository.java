package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.StaffSalaryPayment;
import java.time.LocalDate;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataStaffSalaryPaymentRepository
        extends JpaRepository<StaffSalaryPayment, UUID>,
                com.societyapp.repository.StaffSalaryPaymentRepository {
    List<StaffSalaryPayment> findByStaffUserIdOrderBySalaryMonthDesc(UUID staffUserId);

    boolean existsByStaffUserIdAndSalaryMonth(UUID staffUserId, LocalDate salaryMonth);

    List<StaffSalaryPayment> findBySocietyIdAndPaidOnBetweenOrderByPaidOnDesc(
            UUID societyId, LocalDate from, LocalDate to);
}
