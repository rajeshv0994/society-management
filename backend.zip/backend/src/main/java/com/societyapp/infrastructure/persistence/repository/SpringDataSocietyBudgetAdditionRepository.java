package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.SocietyBudgetAddition;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataSocietyBudgetAdditionRepository
        extends JpaRepository<SocietyBudgetAddition, UUID>,
                com.societyapp.repository.SocietyBudgetAdditionRepository {
    List<SocietyBudgetAddition> findBySocietyIdAndBudgetYearOrderByAddedAtDesc(
            UUID societyId, int budgetYear);
}
