package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.SupportTicketMessage;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataSupportTicketMessageRepository
        extends JpaRepository<SupportTicketMessage, UUID>,
                com.societyapp.repository.SupportTicketMessageRepository {
    List<SupportTicketMessage> findByTicketIdOrderByCreatedAt(UUID ticketId);
}
