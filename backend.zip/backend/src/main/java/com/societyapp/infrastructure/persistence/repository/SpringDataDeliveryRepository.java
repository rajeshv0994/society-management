package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.Delivery;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataDeliveryRepository
        extends JpaRepository<Delivery, UUID>, com.societyapp.repository.DeliveryRepository {
    List<Delivery> findBySocietyIdOrderByCreatedAtDesc(UUID societyId);

    List<Delivery> findBySocietyIdAndResidentIdOrderByCreatedAtDesc(
            UUID societyId, UUID residentId);

    Optional<Delivery> findByIdAndSocietyId(UUID id, UUID societyId);

    long countBySocietyId(UUID societyId);

    long countBySocietyIdAndStatusIn(UUID societyId, Collection<String> statuses);
}
