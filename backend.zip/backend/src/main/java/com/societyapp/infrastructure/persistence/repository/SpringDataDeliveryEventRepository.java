package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.DeliveryEvent;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataDeliveryEventRepository
        extends JpaRepository<DeliveryEvent, UUID>,
                com.societyapp.repository.DeliveryEventRepository {
    List<DeliveryEvent> findByDeliveryIdOrderByOccurredAt(UUID deliveryId);
}
