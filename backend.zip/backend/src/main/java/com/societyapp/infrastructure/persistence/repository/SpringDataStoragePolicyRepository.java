package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.StoragePolicy;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataStoragePolicyRepository
        extends JpaRepository<StoragePolicy, Short>,
                com.societyapp.repository.StoragePolicyRepository {}
