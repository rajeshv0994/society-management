package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.PlatformPaymentSetting;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataPlatformPaymentSettingRepository
        extends JpaRepository<PlatformPaymentSetting, UUID>,
                com.societyapp.repository.PlatformPaymentSettingRepository {
    Optional<PlatformPaymentSetting> findFirstByOrderByUpdatedAtDesc();
}
