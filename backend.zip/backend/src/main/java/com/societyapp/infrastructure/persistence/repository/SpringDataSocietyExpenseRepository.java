package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.SocietyExpense;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataSocietyExpenseRepository
        extends JpaRepository<SocietyExpense, UUID>,
                com.societyapp.repository.SocietyExpenseRepository {
    List<SocietyExpense> findBySocietyIdOrderByExpenseDateDescCreatedAtDesc(UUID societyId);
}
