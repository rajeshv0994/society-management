package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.Amenity;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataAmenityRepository
        extends JpaRepository<Amenity, UUID>, com.societyapp.repository.AmenityRepository {
    List<Amenity> findBySocietyIdOrderByName(UUID societyId);

    Optional<Amenity> findByIdAndSocietyId(UUID id, UUID societyId);
}
