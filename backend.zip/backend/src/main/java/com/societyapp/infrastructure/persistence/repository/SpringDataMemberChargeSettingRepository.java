package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.MemberChargeSetting;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataMemberChargeSettingRepository
        extends JpaRepository<MemberChargeSetting, UUID>,
                com.societyapp.repository.MemberChargeSettingRepository {
    List<MemberChargeSetting> findBySocietyIdOrderByName(UUID societyId);
}
