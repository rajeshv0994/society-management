package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.*;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataNoticeReadRepository
        extends JpaRepository<NoticeRead, NoticeReadId>,
                com.societyapp.repository.NoticeReadRepository {
    Optional<NoticeRead> findByNoticeIdAndUserId(UUID noticeId, UUID userId);

    long countByNoticeId(UUID noticeId);

    long countByNoticeIdAndAcknowledgedAtIsNotNull(UUID noticeId);
}
