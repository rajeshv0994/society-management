package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.application.model.SocietyProfileUpdate;
import com.societyapp.repository.SocietyProfileStore;
import com.societyapp.repository.SocietyRepository;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import org.springframework.stereotype.Repository;

@Repository
public class JpaSocietyProfileStore implements SocietyProfileStore {
    private final SocietyRepository societies;

    public JpaSocietyProfileStore(SocietyRepository societies) {
        this.societies = societies;
    }

    public Map<String, Object> findById(UUID id) {
        var society =
                societies
                        .findById(id)
                        .orElseThrow(() -> new IllegalArgumentException("Society not found"));
        Map<String, Object> view = new LinkedHashMap<>();
        view.put("id", society.getId());
        view.put("name", society.getName());
        view.put("registration_number", society.getRegistrationNumber());
        view.put("society_code", society.getSocietyCode());
        view.put("society_type", society.getSocietyType());
        view.put("total_blocks", society.getTotalBlocks());
        view.put("total_flats", society.getTotalFlats());
        view.put("total_spaces", society.getTotalFlats());
        view.put("planned_staff", society.getPlannedStaff());
        view.put("approximate_residents", society.getApproximateResidents());
        view.put("address", society.getAddress());
        view.put("city", society.getCity());
        view.put("state", society.getState());
        view.put("pin_code", society.getPinCode());
        view.put("contact_person", society.getContactPerson());
        view.put("email", society.getEmail());
        view.put("mobile", society.getMobile());
        view.put("plan_code", society.getPlanCode());
        view.put("enabled_modules", society.getEnabledModules());
        view.put("status", society.getStatus());
        view.put("description", society.getDescription());
        view.put("website", society.getWebsite());
        view.put(
                "logo_url",
                society.getLogoStorageKey() == null
                        ? null
                        : "/api/public/societies/" + society.getId() + "/logo");
        view.put("updated_at", society.getUpdatedAt());
        return view;
    }

    public void update(UUID id, SocietyProfileUpdate request) {
        var society =
                societies
                        .findById(id)
                        .orElseThrow(() -> new IllegalArgumentException("Society not found"));
        society.setName(request.name());
        society.setDescription(request.description());
        society.setWebsite(request.website());
        society.setContactPerson(request.contactPerson());
        society.setEmail(request.email());
        society.setMobile(request.mobile());
        society.setAddress(request.address());
        society.setCity(request.city());
        society.setState(request.state());
        society.setPinCode(request.pinCode());
        society.setUpdatedAt(java.time.OffsetDateTime.now());
        societies.save(society);
    }

    public boolean exists(UUID id) {
        return societies.existsById(id);
    }

    public void updateLogo(UUID id, String storageKey, String contentType) {
        var society =
                societies
                        .findById(id)
                        .orElseThrow(() -> new IllegalArgumentException("Society not found"));
        society.setLogoStorageKey(storageKey);
        society.setLogoContentType(contentType);
        society.setUpdatedAt(java.time.OffsetDateTime.now());
        societies.save(society);
    }

    public Map<String, Object> findLogo(UUID id) {
        return societies
                .findById(id)
                .filter(society -> society.getLogoStorageKey() != null)
                .<Map<String, Object>>map(
                        society -> {
                            Map<String, Object> logo = new LinkedHashMap<>();
                            logo.put("logo_storage_key", society.getLogoStorageKey());
                            logo.put("logo_content_type", society.getLogoContentType());
                            return logo;
                        })
                .orElseGet(Map::of);
    }
}
