package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.EmergencyIncidentEvent;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataEmergencyIncidentEventRepository
        extends JpaRepository<EmergencyIncidentEvent, UUID>,
                com.societyapp.repository.EmergencyIncidentEventRepository {
    List<EmergencyIncidentEvent> findByIncidentIdOrderByOccurredAt(UUID incidentId);
}
