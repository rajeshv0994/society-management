package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.ResidentDocument;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataResidentDocumentRepository
        extends JpaRepository<ResidentDocument, UUID>,
                com.societyapp.repository.ResidentDocumentRepository {
    List<ResidentDocument> findByRegistrationId(UUID registrationId);
}
