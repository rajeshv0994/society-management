package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.ActivityEvent;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataActivityEventRepository
        extends JpaRepository<ActivityEvent, UUID>,
                com.societyapp.repository.ActivityEventRepository {
    List<ActivityEvent> findByActivityIdOrderByOccurredAt(UUID activityId);
}
