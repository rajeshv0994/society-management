package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.Notice;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataNoticeRepository
        extends JpaRepository<Notice, UUID>, com.societyapp.repository.NoticeRepository {
    List<Notice> findBySocietyIdOrderByPublishedAtDesc(UUID societyId);
}
