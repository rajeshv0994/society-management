package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.SocietyCustomPlan;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataSocietyCustomPlanRepository
        extends JpaRepository<SocietyCustomPlan, UUID>,
                com.societyapp.repository.SocietyCustomPlanRepository {
    List<SocietyCustomPlan> findAllByOrderByCreatedAtDesc();
}
