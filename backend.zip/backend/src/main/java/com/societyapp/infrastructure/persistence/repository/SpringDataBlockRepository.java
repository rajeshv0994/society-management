package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.entity.Block;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataBlockRepository
        extends JpaRepository<Block, UUID>, com.societyapp.repository.BlockRepository {
    List<Block> findBySocietyIdOrderByName(UUID societyId);

    boolean existsByIdAndSocietyId(UUID id, UUID societyId);
}
