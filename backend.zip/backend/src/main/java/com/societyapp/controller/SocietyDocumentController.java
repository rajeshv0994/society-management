package com.societyapp.controller;

import com.societyapp.application.port.in.SocietyDocumentUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.constraints.Pattern;
import java.util.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api")
public class SocietyDocumentController {
    private final SocietyDocumentUseCase service;

    public SocietyDocumentController(SocietyDocumentUseCase service) {
        this.service = service;
    }

    @PostMapping(value = "/public/societies/{id}/documents", consumes = "multipart/form-data")
    Map<String, Object> upload(
            @PathVariable UUID id,
            @RequestHeader("X-Registration-Token") String token,
            @RequestParam @Pattern(regexp = "REGISTRATION_CERTIFICATE|GST|PAN|ADDRESS_PROOF")
                    String documentType,
            @RequestPart MultipartFile file) {
        return service.upload(id, token, documentType, new SpringUploadedFile(file));
    }

    @GetMapping("/admin/societies/{id}/documents")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    List<Map<String, Object>> list(@PathVariable UUID id) {
        return service.list(id);
    }

    @GetMapping("/society/documents")
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    List<Map<String, Object>> societyDocuments() {
        return service.list(CurrentUser.societyId());
    }

    @PostMapping(value = "/society/documents", consumes = "multipart/form-data")
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    Map<String, Object> uploadSocietyDocument(
            @RequestParam @Pattern(regexp = "REGISTRATION_CERTIFICATE|GST|PAN|ADDRESS_PROOF|OTHER")
                    String documentType,
            @RequestPart MultipartFile file) {
        return service.uploadAuthenticated(
                CurrentUser.societyId(), documentType, new SpringUploadedFile(file));
    }

    @PatchMapping("/admin/societies/{societyId}/documents/{documentId}")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    Map<String, Object> verify(
            @PathVariable UUID societyId,
            @PathVariable UUID documentId,
            @RequestBody Map<String, String> body) {
        return service.verify(societyId, documentId, body.get("status"));
    }
}
