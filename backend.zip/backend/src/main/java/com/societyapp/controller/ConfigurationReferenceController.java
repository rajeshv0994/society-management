package com.societyapp.controller;

import com.societyapp.application.port.in.ConfigurationUseCase;
import com.societyapp.security.CurrentUser;
import java.util.Map;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/configuration/reference")
@PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
public class ConfigurationReferenceController {
    private final ConfigurationUseCase service;

    public ConfigurationReferenceController(ConfigurationUseCase service) {
        this.service = service;
    }

    @GetMapping
    public Map<String, Object> reference() {
        return service.reference(CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role());
    }
}
