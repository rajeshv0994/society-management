package com.societyapp.controller;

import com.societyapp.application.port.in.AmenityUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/amenities")
public class AmenityController {
    private final AmenityUseCase service;

    public AmenityController(AmenityUseCase service) {
        this.service = service;
    }

    public record AmenityRequest(
            @NotBlank String name,
            @NotBlank
                    @Pattern(
                            regexp =
                                    "COMMUNITY_CENTER|GYM|SWIMMING_POOL|SPORTS_COURT|GUEST_ROOM|PLAY_AREA|OTHER")
                    String amenityType,
            @NotBlank @Pattern(regexp = "[A-Z0-9][A-Z0-9_-]{1,39}") String amenityCode,
            String description,
            String location,
            @Min(1) Integer capacity,
            @NotNull @DecimalMin("0") BigDecimal hourlyCharge,
            @NotBlank @Pattern(regexp = "FREE|HOURLY|PER_SLOT|FIXED") String pricingType,
            @NotNull @DecimalMin("0") BigDecimal bookingCharge,
            @NotNull @DecimalMin("0") BigDecimal refundableDeposit,
            LocalTime opensAt,
            LocalTime closesAt,
            boolean bookingApprovalRequired,
            @Min(15) @Max(1440) int slotMinutes,
            @Min(1) @Max(365) int advanceBookingDays,
            @Min(0) @Max(168) int cancellationHours,
            @Size(max = 500) String instructions,
            Boolean active) {}

    public record Book(
            @NotNull OffsetDateTime startsAt,
            @NotNull OffsetDateTime endsAt,
            @Min(1) int attendees,
            @Size(max = 240) String purpose) {}

    public record Checkout(
            @NotBlank @Pattern(regexp = "UPI|CARD|NET_BANKING") String paymentMethod) {}

    public record BookingAction(
            @NotBlank @Pattern(regexp = "APPROVE|REJECT|CANCEL|CHECK_IN|CHECK_OUT|REFUND")
                    String action,
            @Size(max = 300) String reason) {}

    @GetMapping
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
    List<Map<String, Object>> list() {
        return service.list(CurrentUser.societyId(), CurrentUser.role());
    }

    @GetMapping("/bookings")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
    List<Map<String, Object>> bookings() {
        return service.bookings(CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role());
    }

    @PostMapping
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    Map<String, Object> create(@Valid @RequestBody AmenityRequest request) {
        return service.create(
                CurrentUser.societyId(),
                request.name(),
                request.amenityType(),
                request.amenityCode(),
                request.description(),
                request.location(),
                request.capacity(),
                request.hourlyCharge(),
                request.pricingType(),
                request.bookingCharge(),
                request.refundableDeposit(),
                request.opensAt(),
                request.closesAt(),
                request.bookingApprovalRequired(),
                request.slotMinutes(),
                request.advanceBookingDays(),
                request.cancellationHours(),
                request.instructions());
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    Map<String, Object> update(@PathVariable UUID id, @Valid @RequestBody AmenityRequest request) {
        return service.update(
                CurrentUser.societyId(),
                id,
                request.name(),
                request.amenityType(),
                request.amenityCode(),
                request.description(),
                request.location(),
                request.capacity(),
                request.hourlyCharge(),
                request.pricingType(),
                request.bookingCharge(),
                request.refundableDeposit(),
                request.opensAt(),
                request.closesAt(),
                request.bookingApprovalRequired(),
                request.slotMinutes(),
                request.advanceBookingDays(),
                request.cancellationHours(),
                request.instructions(),
                request.active() == null || request.active());
    }

    @PostMapping("/{id}/book")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','RESIDENT')")
    Map<String, Object> book(@PathVariable UUID id, @Valid @RequestBody Book request) {
        return service.book(
                CurrentUser.societyId(),
                CurrentUser.id(),
                id,
                request.startsAt(),
                request.endsAt(),
                request.attendees(),
                request.purpose());
    }

    @PostMapping("/bookings/{id}/checkout")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
    Map<String, Object> checkout(@PathVariable UUID id, @Valid @RequestBody Checkout request) {
        return service.checkout(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                id,
                request.paymentMethod());
    }

    @PostMapping("/bookings/{id}/cash")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF')")
    Map<String, Object> cash(@PathVariable UUID id) {
        return service.recordCash(
                CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role(), id);
    }

    @PatchMapping("/bookings/{id}")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
    Map<String, Object> action(@PathVariable UUID id, @Valid @RequestBody BookingAction request) {
        return service.action(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                id,
                request.action(),
                request.reason());
    }
}
