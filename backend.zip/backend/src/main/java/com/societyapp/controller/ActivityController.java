package com.societyapp.controller;

import com.societyapp.application.port.in.ActivityUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.*;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/activities")
@PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
public class ActivityController {
    private final ActivityUseCase service;

    public ActivityController(ActivityUseCase service) {
        this.service = service;
    }

    public record ActivityRequest(
            @NotBlank @Size(max = 180) String title,
            @NotBlank
                    @Pattern(
                            regexp =
                                    "SPORTS|CULTURAL|EDUCATIONAL|HEALTH|SOCIAL|RELIGIOUS|CHILDREN|SENIOR_CITIZEN|VOLUNTEERING|OTHER")
                    String category,
            @NotBlank @Size(max = 2000) String description,
            @NotBlank @Size(max = 300) String venue,
            @NotNull OffsetDateTime startsAt,
            @NotNull OffsetDateTime endsAt,
            @NotNull OffsetDateTime registrationOpensAt,
            @NotNull OffsetDateTime registrationClosesAt,
            @Min(1) Integer capacity,
            @NotNull @DecimalMin("0") BigDecimal feePerPerson,
            boolean approvalRequired,
            @Min(0) @Max(720) int cancellationHours,
            @NotBlank
                    @Pattern(regexp = "ALL_MEMBERS|ADULTS|CHILDREN|SENIOR_CITIZENS|WOMEN|MEN|OTHER")
                    String audience,
            @Size(max = 150) String organizerName,
            @Pattern(regexp = "^$|[0-9+() -]{7,20}$") String organizerMobile,
            @Size(max = 1000) String instructions,
            boolean publishNow) {}

    public record ActivityAction(
            @NotBlank @Pattern(regexp = "PUBLISH|CANCEL|COMPLETE|ARCHIVE") String action,
            @Size(max = 500) String reason) {}

    public record Join(
            @Min(1) @Max(50) int participantCount,
            @Size(max = 1000) String participantNames,
            @Pattern(regexp = "^$|[0-9+() -]{7,20}$") String contactMobile,
            @Size(max = 500) String notes) {}

    public record Checkout(
            @NotBlank @Pattern(regexp = "UPI|CARD|NET_BANKING") String paymentMethod) {}

    public record ParticipationAction(
            @NotBlank @Pattern(regexp = "APPROVE|REJECT|CHECK_IN|ATTENDED|NO_SHOW|CANCEL|REFUND")
                    String action,
            @Size(max = 500) String reason) {}

    public record PhotoAction(
            @NotBlank @Pattern(regexp = "APPROVE|REJECT|REMOVE|FEATURE|UNFEATURE") String action,
            @Size(max = 500) String reason) {}

    @GetMapping
    Map<String, Object> workspace() {
        return service.workspace(CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role());
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    Map<String, Object> create(@Valid @RequestBody ActivityRequest request) {
        return service.create(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                request.title(),
                request.category(),
                request.description(),
                request.venue(),
                request.startsAt(),
                request.endsAt(),
                request.registrationOpensAt(),
                request.registrationClosesAt(),
                request.capacity(),
                request.feePerPerson(),
                request.approvalRequired(),
                request.cancellationHours(),
                request.audience(),
                request.organizerName(),
                request.organizerMobile(),
                request.instructions(),
                request.publishNow());
    }

    @PutMapping("/{id}")
    Map<String, Object> update(@PathVariable UUID id, @Valid @RequestBody ActivityRequest request) {
        return service.update(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                id,
                request.title(),
                request.category(),
                request.description(),
                request.venue(),
                request.startsAt(),
                request.endsAt(),
                request.registrationOpensAt(),
                request.registrationClosesAt(),
                request.capacity(),
                request.feePerPerson(),
                request.approvalRequired(),
                request.cancellationHours(),
                request.audience(),
                request.organizerName(),
                request.organizerMobile(),
                request.instructions());
    }

    @PatchMapping("/{id}")
    Map<String, Object> activityAction(
            @PathVariable UUID id, @Valid @RequestBody ActivityAction request) {
        return service.activityAction(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                id,
                request.action(),
                request.reason());
    }

    @PostMapping("/{id}/join")
    @ResponseStatus(HttpStatus.CREATED)
    Map<String, Object> join(@PathVariable UUID id, @Valid @RequestBody Join request) {
        return service.join(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                id,
                request.participantCount(),
                request.participantNames(),
                request.contactMobile(),
                request.notes());
    }

    @PostMapping("/participations/{id}/checkout")
    Map<String, Object> checkout(@PathVariable UUID id, @Valid @RequestBody Checkout request) {
        return service.checkout(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                id,
                request.paymentMethod());
    }

    @PostMapping("/participations/{id}/cash")
    Map<String, Object> cash(@PathVariable UUID id) {
        return service.recordCash(
                CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role(), id);
    }

    @PatchMapping("/participations/{id}")
    Map<String, Object> participationAction(
            @PathVariable UUID id, @Valid @RequestBody ParticipationAction request) {
        return service.participationAction(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                id,
                request.action(),
                request.reason());
    }

    @PostMapping(value = "/{id}/photos", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    Map<String, Object> uploadPhoto(
            @PathVariable UUID id,
            @RequestParam(required = false) @Size(max = 500) String caption,
            @RequestPart("file") MultipartFile file) {
        return service.uploadPhoto(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                id,
                caption,
                new SpringUploadedFile(file));
    }

    @GetMapping("/photos/{id}")
    ResponseEntity<Resource> photo(@PathVariable UUID id) {
        var photo =
                service.photo(CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role(), id);
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(photo.contentType()))
                .contentLength(photo.content().length())
                .body(
                        new org.springframework.core.io.InputStreamResource(
                                photo.content().stream()));
    }

    @PatchMapping("/photos/{id}")
    Map<String, Object> photoAction(
            @PathVariable UUID id, @Valid @RequestBody PhotoAction request) {
        return service.photoAction(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                id,
                request.action(),
                request.reason());
    }

    @GetMapping("/{id}/history")
    List<Map<String, Object>> history(@PathVariable UUID id) {
        return service.history(CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role(), id);
    }
}
