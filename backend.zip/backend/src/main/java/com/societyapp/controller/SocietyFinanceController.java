package com.societyapp.controller;

import com.societyapp.application.port.in.SocietyFinanceUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/billing")
public class SocietyFinanceController {
    private final SocietyFinanceUseCase service;

    public SocietyFinanceController(SocietyFinanceUseCase service) {
        this.service = service;
    }

    public record Expense(
            @NotBlank String category,
            @Size(max = 150) String vendor,
            @NotBlank @Size(max = 300) String description,
            @NotNull @DecimalMin(value = "0", inclusive = false) BigDecimal amount,
            @NotNull LocalDate expenseDate,
            @NotBlank String paymentMethod,
            @Size(max = 120) String paymentReference) {}

    public record ChargeSetting(
            @NotBlank @Size(max = 120) String name,
            @NotBlank String chargeType,
            @NotNull @DecimalMin(value = "0", inclusive = false) BigDecimal amount,
            @NotBlank String frequency,
            @Size(max = 240) String description,
            UUID flatId) {}

    public record Budget(@NotNull @DecimalMin("0") BigDecimal amount) {}

    public record BudgetAddition(
            @NotNull @DecimalMin(value = "0", inclusive = false) BigDecimal amount,
            @Size(max = 240) String note) {}

    @GetMapping("/expenses")
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    List<Map<String, Object>> expenses() {
        return service.expenses(CurrentUser.societyId());
    }

    @PostMapping("/expenses")
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    Map<String, Object> expense(@Valid @RequestBody Expense request) {
        return service.createExpense(
                CurrentUser.societyId(),
                CurrentUser.id(),
                request.category(),
                request.vendor(),
                request.description(),
                request.amount(),
                request.expenseDate(),
                request.paymentMethod(),
                request.paymentReference());
    }

    @GetMapping("/charge-settings")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
    List<Map<String, Object>> chargeSettings() {
        return service.chargeSettings(
                CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role());
    }

    @PostMapping("/charge-settings")
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    Map<String, Object> chargeSetting(@Valid @RequestBody ChargeSetting request) {
        return service.createChargeSetting(
                CurrentUser.societyId(),
                request.name(),
                request.chargeType(),
                request.amount(),
                request.frequency(),
                request.description(),
                request.flatId());
    }

    @GetMapping("/finance-summary")
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    Map<String, Object> financeSummary() {
        return service.financeSummary(CurrentUser.societyId(), LocalDate.now().getYear());
    }

    @PutMapping("/budget")
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    Map<String, Object> budget(@Valid @RequestBody Budget request) {
        return service.setBudget(
                CurrentUser.societyId(),
                CurrentUser.id(),
                LocalDate.now().getYear(),
                request.amount());
    }

    @PostMapping("/budget/additions")
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    Map<String, Object> addBudget(@Valid @RequestBody BudgetAddition request) {
        return service.addBudget(
                CurrentUser.societyId(),
                CurrentUser.id(),
                LocalDate.now().getYear(),
                request.amount(),
                request.note());
    }

    @GetMapping("/staff-salaries")
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    List<Map<String, Object>> staffSalaries() {
        return service.staffSalaries(CurrentUser.societyId());
    }
}
