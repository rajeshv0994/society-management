package com.societyapp.controller;

import com.societyapp.application.port.in.ComplaintUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.util.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/complaints")
public class ComplaintController {
    private final ComplaintUseCase service;

    public ComplaintController(ComplaintUseCase service) {
        this.service = service;
    }

    public record Create(
            UUID residentId,
            UUID flatId,
            UUID categoryId,
            UUID assignedTo,
            @NotBlank String title,
            @NotBlank String description,
            @Pattern(regexp = "LOW|NORMAL|HIGH|URGENT") String priority) {}

    public record Update(
            @Pattern(regexp = "OPEN|ASSIGNED|IN_PROGRESS|RESOLVED|CLOSED") String status,
            UUID assignedTo,
            String note,
            String resolution) {}

    public record Comment(@NotBlank String note) {}

    @GetMapping
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
    List<Map<String, Object>> list() {
        return service.list(CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role());
    }

    @GetMapping("/options")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
    Map<String, Object> options() {
        return service.options(CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
    Map<String, Object> detail(@PathVariable UUID id) {
        return service.detail(CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role(), id);
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
    Map<String, Object> create(@Valid @RequestBody Create r) {
        return service.create(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                r.residentId(),
                r.flatId(),
                r.categoryId(),
                r.assignedTo(),
                r.title(),
                r.description(),
                r.priority());
    }

    @PatchMapping("/{id}")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF')")
    Map<String, Object> update(@PathVariable UUID id, @Valid @RequestBody Update r) {
        return service.update(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                id,
                r.status(),
                r.assignedTo(),
                r.note(),
                r.resolution());
    }

    @PostMapping("/{id}/comments")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
    Map<String, Object> comment(@PathVariable UUID id, @Valid @RequestBody Comment r) {
        return service.comment(
                CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role(), id, r.note());
    }
}
