package com.societyapp.controller;

import com.societyapp.application.port.in.NoticeUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.time.OffsetDateTime;
import java.util.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/notices")
public class NoticeController {
    private final NoticeUseCase service;

    public NoticeController(NoticeUseCase service) {
        this.service = service;
    }

    public record Save(
            @NotBlank @Size(max = 180) String title,
            @NotBlank String body,
            @NotNull @Pattern(regexp = "ALL|RESIDENTS|STAFF") String audience,
            @NotNull @Pattern(regexp = "NORMAL|IMPORTANT|URGENT") String priority,
            boolean pinned,
            boolean requiresAcknowledgement,
            @NotNull @Pattern(regexp = "DRAFT|PUBLISHED|ARCHIVED") String status,
            OffsetDateTime expiresAt) {}

    @GetMapping
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
    List<Map<String, Object>> list() {
        return service.list(CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role());
    }

    @GetMapping("/options")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
    Map<String, Object> options() {
        return service.options(CurrentUser.id(), CurrentUser.role());
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF')")
    Map<String, Object> create(@Valid @RequestBody Save request) {
        return service.create(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                request.title(),
                request.body(),
                request.audience(),
                request.priority(),
                request.pinned(),
                request.requiresAcknowledgement(),
                request.status(),
                request.expiresAt());
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF')")
    Map<String, Object> update(@PathVariable UUID id, @Valid @RequestBody Save request) {
        return service.update(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                id,
                request.title(),
                request.body(),
                request.audience(),
                request.priority(),
                request.pinned(),
                request.requiresAcknowledgement(),
                request.status(),
                request.expiresAt());
    }

    @PostMapping("/{id}/read")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
    Map<String, Object> read(@PathVariable UUID id) {
        return service.markRead(CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role(), id);
    }

    @PostMapping("/{id}/acknowledge")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
    Map<String, Object> acknowledge(@PathVariable UUID id) {
        return service.acknowledge(
                CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role(), id);
    }
}
