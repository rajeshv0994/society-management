package com.societyapp.controller;

import com.societyapp.application.port.in.StorageMeterUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.util.Map;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin/platform/storage")
@PreAuthorize("hasRole('SUPER_ADMIN')")
public class StorageAdminController {
    private final StorageMeterUseCase storage;

    public StorageAdminController(StorageMeterUseCase storage) {
        this.storage = storage;
    }

    public record PolicyUpdate(
            @Min(0) int defaultFreeGb,
            @Min(1) int purchaseBlockGb,
            @NotNull @DecimalMin("0.00") BigDecimal pricePerBlockMonthly) {}

    @GetMapping
    Map<String, Object> dashboard() {
        return storage.adminDashboard();
    }

    @PutMapping("/policy")
    Map<String, Object> policy(@Valid @RequestBody PolicyUpdate request) {
        return storage.updatePolicy(
                CurrentUser.id(),
                request.defaultFreeGb(),
                request.purchaseBlockGb(),
                request.pricePerBlockMonthly());
    }
}
