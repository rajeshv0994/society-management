package com.societyapp.controller;

import com.societyapp.application.port.in.HouseholdUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.time.LocalDate;
import java.util.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/households")
@PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
public class HouseholdManagementController {
    private final HouseholdUseCase service;

    public HouseholdManagementController(HouseholdUseCase service) {
        this.service = service;
    }

    public record MemberRequest(
            UUID residentId,
            @NotBlank @Size(max = 150) String fullName,
            @NotBlank @Size(max = 40) String relationship,
            @Pattern(regexp = "^$|[0-9+() -]{7,20}$") String mobile,
            @Email String email,
            LocalDate dateOfBirth,
            @Pattern(regexp = "MALE|FEMALE|OTHER|PREFER_NOT_TO_SAY") String gender,
            @Pattern(regexp = "A\\+|A-|B\\+|B-|AB\\+|AB-|O\\+|O-") String bloodGroup,
            @Size(max = 120) String occupation,
            @Pattern(regexp = "AADHAAR|PASSPORT|DRIVING_LICENCE|VOTER_ID|OTHER")
                    String identityType,
            @Pattern(regexp = "[A-Za-z0-9]{4}") String identityLast4,
            @Size(max = 150) String emergencyContactName,
            @Pattern(regexp = "^$|[0-9+() -]{7,20}$") String emergencyContactMobile,
            Boolean accessEnabled) {}

    public record VehicleRequest(
            UUID residentId,
            @NotBlank @Pattern(regexp = "CAR|MOTORCYCLE|SCOOTER|BICYCLE|OTHER") String vehicleType,
            @NotBlank @Pattern(regexp = "[A-Za-z0-9 -]{4,20}") String registrationNumber,
            @Size(max = 80) String make,
            @Size(max = 80) String model,
            @Size(max = 40) String color,
            @Size(max = 40) String parkingSlot,
            @Size(max = 40) String stickerNumber) {}

    public record ContactRequest(
            UUID residentId,
            @NotBlank @Size(max = 150) String fullName,
            @NotBlank @Size(max = 40) String relationship,
            @NotBlank @Pattern(regexp = "[0-9+() -]{7,20}") String mobile,
            @Pattern(regexp = "^$|[0-9+() -]{7,20}$") String alternateMobile,
            @Min(1) @Max(3) int priority) {}

    public record ReviewRequest(
            @NotNull UUID residentId,
            @NotBlank @Pattern(regexp = "PENDING|VERIFIED|REJECTED") String status,
            @Size(max = 300) String note) {}

    @GetMapping
    Map<String, Object> workspace() {
        return service.workspace(CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role());
    }

    @PostMapping("/members")
    Map<String, Object> addMember(@Valid @RequestBody MemberRequest request) {
        return service.addMember(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                request.residentId(),
                request.fullName(),
                request.relationship(),
                request.mobile(),
                request.email(),
                request.dateOfBirth(),
                request.gender(),
                request.bloodGroup(),
                request.occupation(),
                request.identityType(),
                request.identityLast4(),
                request.emergencyContactName(),
                request.emergencyContactMobile(),
                request.accessEnabled());
    }

    @PutMapping("/members/{id}")
    Map<String, Object> updateMember(
            @PathVariable UUID id, @Valid @RequestBody MemberRequest request) {
        return service.updateMember(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                request.residentId(),
                id,
                request.fullName(),
                request.relationship(),
                request.mobile(),
                request.email(),
                request.dateOfBirth(),
                request.gender(),
                request.bloodGroup(),
                request.occupation(),
                request.identityType(),
                request.identityLast4(),
                request.emergencyContactName(),
                request.emergencyContactMobile(),
                request.accessEnabled());
    }

    @PatchMapping("/members/{id}/verification")
    Map<String, Object> reviewMember(
            @PathVariable UUID id, @Valid @RequestBody ReviewRequest request) {
        return service.reviewMember(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                request.residentId(),
                id,
                request.status(),
                request.note());
    }

    @DeleteMapping("/members/{id}")
    Map<String, Object> removeMember(
            @PathVariable UUID id, @RequestParam(required = false) UUID residentId) {
        return service.removeMember(
                CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role(), residentId, id);
    }

    @PostMapping("/vehicles")
    Map<String, Object> addVehicle(@Valid @RequestBody VehicleRequest request) {
        return service.addVehicle(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                request.residentId(),
                request.vehicleType(),
                request.registrationNumber(),
                request.make(),
                request.model(),
                request.color(),
                request.parkingSlot(),
                request.stickerNumber());
    }

    @PutMapping("/vehicles/{id}")
    Map<String, Object> updateVehicle(
            @PathVariable UUID id, @Valid @RequestBody VehicleRequest request) {
        return service.updateVehicle(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                request.residentId(),
                id,
                request.vehicleType(),
                request.registrationNumber(),
                request.make(),
                request.model(),
                request.color(),
                request.parkingSlot(),
                request.stickerNumber());
    }

    @PatchMapping("/vehicles/{id}/verification")
    Map<String, Object> reviewVehicle(
            @PathVariable UUID id, @Valid @RequestBody ReviewRequest request) {
        return service.reviewVehicle(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                request.residentId(),
                id,
                request.status(),
                request.note());
    }

    @DeleteMapping("/vehicles/{id}")
    Map<String, Object> removeVehicle(
            @PathVariable UUID id, @RequestParam(required = false) UUID residentId) {
        return service.removeVehicle(
                CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role(), residentId, id);
    }

    @PostMapping("/emergency-contacts")
    Map<String, Object> addContact(@Valid @RequestBody ContactRequest request) {
        return service.addContact(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                request.residentId(),
                request.fullName(),
                request.relationship(),
                request.mobile(),
                request.alternateMobile(),
                request.priority());
    }

    @PutMapping("/emergency-contacts/{id}")
    Map<String, Object> updateContact(
            @PathVariable UUID id, @Valid @RequestBody ContactRequest request) {
        return service.updateContact(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                request.residentId(),
                id,
                request.fullName(),
                request.relationship(),
                request.mobile(),
                request.alternateMobile(),
                request.priority());
    }

    @DeleteMapping("/emergency-contacts/{id}")
    Map<String, Object> removeContact(
            @PathVariable UUID id, @RequestParam(required = false) UUID residentId) {
        return service.removeContact(
                CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role(), residentId, id);
    }
}
