package com.societyapp.controller;

import com.societyapp.application.port.in.StaffUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/society/staff")
@PreAuthorize("hasRole('SOCIETY_ADMIN')")
public class StaffController {
    private final StaffUseCase service;

    public StaffController(StaffUseCase service) {
        this.service = service;
    }

    public record CreateStaff(
            @NotBlank String fullName,
            @NotBlank @Email String email,
            @NotBlank String mobile,
            @NotBlank @Size(min = 8) String temporaryPassword,
            @NotBlank String staffType,
            String employeeCode,
            String dutyArea,
            String shiftName) {}

    public record UpdateStaff(
            @NotBlank String fullName,
            @NotBlank @Email String email,
            @NotBlank String mobile,
            @NotBlank String staffType,
            String employeeCode,
            String dutyArea,
            String shiftName) {}

    public record StaffStatus(@Pattern(regexp = "ACTIVE|INACTIVE") String status) {}

    public record ResetPassword(@NotBlank @Size(min = 8) String temporaryPassword) {}

    public record Permissions(@NotNull Set<String> permissions) {}

    public record Employment(
            @NotNull LocalDate joinedOn,
            LocalDate dateOfBirth,
            @Pattern(regexp = "MALE|FEMALE|OTHER|PREFER_NOT_TO_SAY") String gender,
            @Size(max = 20) String alternateMobile,
            String address,
            String emergencyContactName,
            String emergencyContactMobile,
            String idType,
            String idNumber,
            @DecimalMin("0.00") BigDecimal monthlySalary,
            @Size(max = 150) String bankAccountName,
            @Size(max = 40) String bankAccountNumber,
            @Size(max = 20) String bankIfsc,
            @Size(max = 100) String upiId) {}

    public record Attendance(
            @NotNull LocalDate attendanceDate,
            @NotNull @Pattern(regexp = "PRESENT|ABSENT|HALF_DAY|LEAVE") String status,
            LocalTime checkIn,
            LocalTime checkOut,
            @Size(max = 250) String note) {}

    public record SalaryPayment(
            @NotNull LocalDate salaryMonth,
            @NotNull @DecimalMin(value = "0.01") BigDecimal amount,
            @NotNull LocalDate paidOn,
            @NotNull @Pattern(regexp = "CASH|BANK_TRANSFER|UPI|CHEQUE") String paymentMethod,
            String referenceNumber,
            @Size(max = 250) String note) {}

    @GetMapping
    public List<Map<String, Object>> list() {
        return service.list(CurrentUser.societyId());
    }

    @GetMapping("/me")
    @PreAuthorize("hasRole('STAFF')")
    public Map<String, Object> ownProfile() {
        return service.detail(CurrentUser.societyId(), CurrentUser.id());
    }

    @GetMapping("/me/attendance")
    @PreAuthorize("hasRole('STAFF')")
    public Map<String, Object> ownAttendance() {
        return service.ownAttendance(CurrentUser.societyId(), CurrentUser.id());
    }

    @PostMapping("/me/attendance/clock-in")
    @PreAuthorize("hasRole('STAFF')")
    public Map<String, Object> clockIn() {
        return service.clockIn(CurrentUser.societyId(), CurrentUser.id());
    }

    @PostMapping("/me/attendance/clock-out")
    @PreAuthorize("hasRole('STAFF')")
    public Map<String, Object> clockOut() {
        return service.clockOut(CurrentUser.societyId(), CurrentUser.id());
    }

    @GetMapping("/{staffId}")
    public Map<String, Object> detail(@PathVariable UUID staffId) {
        return service.detail(CurrentUser.societyId(), staffId);
    }

    @PostMapping
    public Map<String, Object> create(@Valid @RequestBody CreateStaff request) {
        return service.create(
                CurrentUser.societyId(),
                request.fullName(),
                request.email(),
                request.mobile(),
                request.temporaryPassword(),
                request.staffType(),
                request.employeeCode(),
                request.dutyArea(),
                request.shiftName());
    }

    @PutMapping("/{staffId}")
    public Map<String, Object> update(
            @PathVariable UUID staffId, @Valid @RequestBody UpdateStaff request) {
        return service.update(
                CurrentUser.societyId(),
                staffId,
                request.fullName(),
                request.email(),
                request.mobile(),
                request.staffType(),
                request.employeeCode(),
                request.dutyArea(),
                request.shiftName());
    }

    @PatchMapping("/{staffId}/status")
    public Map<String, Object> status(
            @PathVariable UUID staffId, @Valid @RequestBody StaffStatus request) {
        return service.setStatus(CurrentUser.societyId(), staffId, request.status());
    }

    @PostMapping("/{staffId}/reset-password")
    public Map<String, Object> resetPassword(
            @PathVariable UUID staffId, @Valid @RequestBody ResetPassword request) {
        return service.resetPassword(CurrentUser.societyId(), staffId, request.temporaryPassword());
    }

    @PutMapping("/{staffId}/permissions")
    public Map<String, Object> permissions(
            @PathVariable UUID staffId, @Valid @RequestBody Permissions request) {
        return service.setPermissions(
                CurrentUser.societyId(), CurrentUser.id(), staffId, request.permissions());
    }

    @PutMapping("/{staffId}/employment")
    public Map<String, Object> employment(
            @PathVariable UUID staffId, @Valid @RequestBody Employment request) {
        return service.updateEmployment(
                CurrentUser.societyId(),
                staffId,
                request.joinedOn(),
                request.dateOfBirth(),
                request.gender(),
                request.alternateMobile(),
                request.address(),
                request.emergencyContactName(),
                request.emergencyContactMobile(),
                request.idType(),
                request.idNumber(),
                request.monthlySalary(),
                request.bankAccountName(),
                request.bankAccountNumber(),
                request.bankIfsc(),
                request.upiId());
    }

    @PutMapping("/{staffId}/attendance")
    public Map<String, Object> attendance(
            @PathVariable UUID staffId, @Valid @RequestBody Attendance request) {
        return service.markAttendance(
                CurrentUser.societyId(),
                CurrentUser.id(),
                staffId,
                request.attendanceDate(),
                request.status(),
                request.checkIn(),
                request.checkOut(),
                request.note());
    }

    @PostMapping("/{staffId}/salary-payments")
    public Map<String, Object> salaryPayment(
            @PathVariable UUID staffId, @Valid @RequestBody SalaryPayment request) {
        return service.recordSalaryPayment(
                CurrentUser.societyId(),
                CurrentUser.id(),
                staffId,
                request.salaryMonth(),
                request.amount(),
                request.paidOn(),
                request.paymentMethod(),
                request.referenceNumber(),
                request.note());
    }
}
