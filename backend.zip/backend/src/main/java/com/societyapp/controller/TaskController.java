package com.societyapp.controller;

import com.societyapp.application.port.in.TaskUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.time.OffsetDateTime;
import java.util.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {
    private final TaskUseCase service;

    public TaskController(TaskUseCase service) {
        this.service = service;
    }

    public record Create(
            @NotBlank @Size(max = 180) String title,
            String description,
            @NotNull UUID assignedTo,
            OffsetDateTime dueAt,
            @NotNull @Pattern(regexp = "LOW|NORMAL|HIGH|URGENT") String priority) {}

    public record Edit(
            @NotBlank @Size(max = 180) String title,
            String description,
            @NotNull UUID assignedTo,
            OffsetDateTime dueAt,
            @NotNull @Pattern(regexp = "LOW|NORMAL|HIGH|URGENT") String priority) {}

    public record Progress(
            @NotNull @Pattern(regexp = "OPEN|IN_PROGRESS|BLOCKED|COMPLETED|CANCELLED")
                    String status,
            String note) {}

    public record Complete(@NotBlank String completionNote) {}

    public record Comment(@NotBlank String note) {}

    @GetMapping
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF')")
    List<Map<String, Object>> list() {
        return service.list(CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role());
    }

    @GetMapping("/options")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF')")
    Map<String, Object> options() {
        return service.options(CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF')")
    Map<String, Object> detail(@PathVariable UUID id) {
        return service.detail(CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role(), id);
    }

    @PostMapping
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    Map<String, Object> create(@Valid @RequestBody Create request) {
        return service.create(
                CurrentUser.societyId(),
                CurrentUser.id(),
                request.title(),
                request.description(),
                request.assignedTo(),
                request.dueAt(),
                request.priority());
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    Map<String, Object> edit(@PathVariable UUID id, @Valid @RequestBody Edit request) {
        return service.edit(
                CurrentUser.societyId(),
                CurrentUser.id(),
                id,
                request.title(),
                request.description(),
                request.assignedTo(),
                request.dueAt(),
                request.priority());
    }

    @PatchMapping("/{id}/progress")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF')")
    Map<String, Object> progress(@PathVariable UUID id, @Valid @RequestBody Progress request) {
        return service.progress(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                id,
                request.status(),
                request.note());
    }

    @PostMapping("/{id}/comments")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF')")
    Map<String, Object> comment(@PathVariable UUID id, @Valid @RequestBody Comment request) {
        return service.comment(
                CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role(), id, request.note());
    }

    @PatchMapping("/{id}/complete")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF')")
    Map<String, Object> complete(@PathVariable UUID id, @Valid @RequestBody Complete request) {
        return service.complete(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                id,
                request.completionNote());
    }
}
