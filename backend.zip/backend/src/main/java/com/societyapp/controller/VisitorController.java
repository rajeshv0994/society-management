package com.societyapp.controller;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.societyapp.application.port.in.VisitorUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.time.OffsetDateTime;
import java.util.*;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/visitors")
public class VisitorController {
    private final VisitorUseCase service;

    public VisitorController(VisitorUseCase service) {
        this.service = service;
    }

    public record Create(
            @JsonAlias({"spaceId", "unitId"}) UUID flatId,
            UUID hostResidentId,
            @Pattern(regexp = "RESIDENT|STAFF|OTHER") String targetType,
            UUID targetUserId,
            String targetName,
            @NotBlank String visitorName,
            String mobile,
            @NotBlank String purpose,
            String vehicleNumber,
            OffsetDateTime expectedAt,
            @Min(0) int accompanyingMembers) {}

    public record Approval(
            @NotNull @Pattern(regexp = "APPROVE|DENY") String decision,
            @Size(max = 250) String note) {}

    public record Cancellation(@Size(max = 250) String note) {}

    public record StaffApproval(@NotBlank @Size(max = 250) String note) {}

    public record Status(
            @NotNull @Pattern(regexp = "CHECKED_IN|CHECKED_OUT|CANCELLED|DENIED") String status) {}

    @GetMapping
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
    List<Map<String, Object>> list() {
        return service.list(CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role());
    }

    @GetMapping("/permissions")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF')")
    Map<String, Object> permissions() {
        return service.permissions(CurrentUser.id(), CurrentUser.role());
    }

    @GetMapping("/hosts")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF')")
    List<Map<String, Object>> hosts() {
        service.requireGate(CurrentUser.id(), CurrentUser.role());
        return service.hosts(CurrentUser.societyId());
    }

    @GetMapping("/targets")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF')")
    List<Map<String, Object>> targets() {
        service.requireGate(CurrentUser.id(), CurrentUser.role());
        return service.targets(CurrentUser.societyId());
    }

    @GetMapping("/member-options")
    @PreAuthorize("hasRole('RESIDENT')")
    Map<String, Object> memberOptions() {
        return service.memberOptions(CurrentUser.societyId(), CurrentUser.id());
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
    Map<String, Object> create(@Valid @RequestBody Create r) {
        return service.create(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                r.flatId(),
                r.hostResidentId(),
                r.targetType(),
                r.targetUserId(),
                r.targetName(),
                r.visitorName(),
                r.mobile(),
                r.purpose(),
                r.vehicleNumber(),
                r.expectedAt(),
                r.accompanyingMembers());
    }

    @PostMapping(value = "/{id}/photo", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF')")
    Map<String, Object> photo(@PathVariable UUID id, @RequestPart("file") MultipartFile file) {
        return service.uploadPhoto(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                id,
                new SpringUploadedFile(file));
    }

    @GetMapping("/photos/{id}")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
    ResponseEntity<Resource> photo(@PathVariable UUID id) {
        var photo =
                service.photo(CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role(), id);
        var contentType = photo.contentType() == null ? "image/jpeg" : photo.contentType();
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))
                .contentLength(photo.content().length())
                .body(
                        new org.springframework.core.io.InputStreamResource(
                                photo.content().stream()));
    }

    @PatchMapping("/{id}/approval")
    @PreAuthorize("hasRole('RESIDENT')")
    Map<String, Object> approval(@PathVariable UUID id, @Valid @RequestBody Approval r) {
        return service.residentDecision(
                CurrentUser.societyId(), CurrentUser.id(), id, r.decision(), r.note());
    }

    @PatchMapping("/{id}/cancel")
    @PreAuthorize("hasRole('RESIDENT')")
    Map<String, Object> cancel(@PathVariable UUID id, @Valid @RequestBody Cancellation r) {
        return service.residentCancel(CurrentUser.societyId(), CurrentUser.id(), id, r.note());
    }

    @PatchMapping("/{id}/staff-approval")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF')")
    Map<String, Object> staffApproval(@PathVariable UUID id, @Valid @RequestBody StaffApproval r) {
        return service.staffApproval(
                CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role(), id, r.note());
    }

    @PatchMapping("/{id}/staff-decision")
    @PreAuthorize("hasRole('STAFF')")
    Map<String, Object> staffDecision(@PathVariable UUID id, @Valid @RequestBody Approval r) {
        return service.targetStaffDecision(
                CurrentUser.societyId(), CurrentUser.id(), id, r.decision());
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF')")
    Map<String, Object> status(@PathVariable UUID id, @Valid @RequestBody Status r) {
        return service.updateStatus(
                CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role(), id, r.status());
    }
}
