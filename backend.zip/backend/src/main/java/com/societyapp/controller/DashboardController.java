package com.societyapp.controller;

import com.societyapp.application.port.in.DashboardUseCase;
import com.societyapp.security.CurrentUser;
import java.util.Map;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {
    private final DashboardUseCase service;

    public DashboardController(DashboardUseCase service) {
        this.service = service;
    }

    @GetMapping("/platform")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    Map<String, Object> platform() {
        return service.platform();
    }

    @GetMapping("/society")
    @PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
    Map<String, Object> society() {
        return service.society(CurrentUser.societyId());
    }
}
