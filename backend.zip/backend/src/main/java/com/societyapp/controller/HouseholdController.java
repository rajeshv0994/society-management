package com.societyapp.controller;

import com.societyapp.application.port.in.HouseholdUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.time.LocalDate;
import java.util.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/member")
@PreAuthorize("hasRole('RESIDENT')")
public class HouseholdController {
    private final HouseholdUseCase service;

    public HouseholdController(HouseholdUseCase service) {
        this.service = service;
    }

    public record Add(
            @NotBlank String fullName,
            @NotBlank String relationship,
            String mobile,
            LocalDate dateOfBirth) {}

    @GetMapping("/profile")
    Map<String, Object> profile() {
        return service.profile(CurrentUser.societyId(), CurrentUser.id());
    }

    @PostMapping("/household")
    Map<String, Object> add(@Valid @RequestBody Add r) {
        return service.add(
                CurrentUser.societyId(),
                CurrentUser.id(),
                r.fullName(),
                r.relationship(),
                r.mobile(),
                r.dateOfBirth());
    }

    @DeleteMapping("/household/{id}")
    Map<String, Object> remove(@PathVariable UUID id) {
        return service.remove(CurrentUser.societyId(), CurrentUser.id(), id);
    }
}
