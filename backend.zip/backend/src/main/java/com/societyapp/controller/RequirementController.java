package com.societyapp.controller;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.societyapp.application.port.in.RequirementUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class RequirementController {
    private final RequirementUseCase service;

    public RequirementController(RequirementUseCase service) {
        this.service = service;
    }

    public record Submit(
            UUID societyId,
            @NotBlank String societyName,
            @NotBlank String contactPerson,
            @Email String email,
            @NotBlank String mobile,
            String city,
            @JsonAlias({"estimatedSpaces", "estimatedUnits"}) @Min(1) Integer estimatedFlats,
            @Min(0) Integer estimatedStaff,
            @NotEmpty List<String> requestedModules,
            @NotBlank String requirementDetails,
            @DecimalMin("0") BigDecimal budgetMonthly) {}

    public record Review(
            @Pattern(regexp = "NEW|CONTACTED|ANALYSING|PROPOSAL_SENT|ACCEPTED|REJECTED|CLOSED")
                    String status,
            String adminNotes) {}

    public record CustomPlan(
            @NotNull UUID societyId,
            UUID requirementId,
            @NotBlank String planName,
            String description,
            @NotEmpty List<String> enabledModules,
            @JsonAlias({"maxSpaces", "maxUnits"}) @Min(1) Integer maxFlats,
            @Min(1) Integer maxStaff,
            @Min(1) Integer maxStorageGb,
            @JsonAlias("priceMonthly") @NotNull @DecimalMin("0") BigDecimal pricePerSpace,
            @NotNull @DecimalMin("0") BigDecimal pricePerStaff,
            @DecimalMin("0") BigDecimal fixedMonthlyPrice,
            @DecimalMin("0") BigDecimal setupFee,
            @NotBlank @Pattern(regexp = "MONTHLY|QUARTERLY|YEARLY") String billingCycle,
            @NotNull LocalDate validFrom,
            LocalDate validUntil,
            @NotBlank @Pattern(regexp = "DRAFT|ACTIVE") String status) {}

    public record CustomPlanUpdate(
            @NotBlank String planName,
            String description,
            @NotEmpty List<String> enabledModules,
            @JsonAlias({"maxSpaces", "maxUnits"}) @Min(1) Integer maxFlats,
            @Min(1) Integer maxStaff,
            @Min(1) Integer maxStorageGb,
            @NotNull @DecimalMin("0") BigDecimal pricePerSpace,
            @NotNull @DecimalMin("0") BigDecimal pricePerStaff,
            @DecimalMin("0") BigDecimal fixedMonthlyPrice,
            @DecimalMin("0") BigDecimal setupFee,
            @NotBlank @Pattern(regexp = "MONTHLY|QUARTERLY|YEARLY") String billingCycle,
            @NotNull LocalDate validFrom,
            LocalDate validUntil,
            @NotBlank @Pattern(regexp = "DRAFT|ACTIVE") String status) {}

    public record CancelCustomPlan(@NotBlank @Size(max = 300) String reason) {}

    @PostMapping("/public/requirements")
    Map<String, Object> submit(@Valid @RequestBody Submit r) {
        return service.submit(
                r.societyId(),
                r.societyName(),
                r.contactPerson(),
                r.email(),
                r.mobile(),
                r.city(),
                r.estimatedFlats(),
                r.estimatedStaff(),
                r.requestedModules(),
                r.requirementDetails(),
                r.budgetMonthly());
    }

    @GetMapping("/admin/platform/requirements")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    List<Map<String, Object>> list() {
        return service.list();
    }

    @PatchMapping("/admin/platform/requirements/{id}")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    Map<String, Object> review(@PathVariable UUID id, @Valid @RequestBody Review r) {
        return service.review(id, CurrentUser.id(), r.status(), r.adminNotes());
    }

    @PostMapping("/admin/platform/custom-plans")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    Map<String, Object> createPlan(@Valid @RequestBody CustomPlan r) {
        return service.createPlan(
                CurrentUser.id(),
                r.societyId(),
                r.requirementId(),
                r.planName(),
                r.description(),
                r.enabledModules(),
                r.maxFlats(),
                r.maxStaff(),
                r.maxStorageGb(),
                r.pricePerSpace(),
                r.pricePerStaff(),
                r.fixedMonthlyPrice(),
                r.setupFee(),
                r.billingCycle(),
                r.validFrom(),
                r.validUntil(),
                r.status());
    }

    @PutMapping("/admin/platform/custom-plans/{id}")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    Map<String, Object> updatePlan(@PathVariable UUID id, @Valid @RequestBody CustomPlanUpdate r) {
        return service.updatePlan(
                id,
                r.planName(),
                r.description(),
                r.enabledModules(),
                r.maxFlats(),
                r.maxStaff(),
                r.maxStorageGb(),
                r.pricePerSpace(),
                r.pricePerStaff(),
                r.fixedMonthlyPrice(),
                r.setupFee(),
                r.billingCycle(),
                r.validFrom(),
                r.validUntil(),
                r.status());
    }

    @PostMapping("/admin/platform/custom-plans/{id}/cancel")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    Map<String, Object> cancelPlan(
            @PathVariable UUID id, @Valid @RequestBody CancelCustomPlan request) {
        return service.cancelPlan(id, CurrentUser.id(), request.reason());
    }

    @GetMapping("/admin/platform/custom-plans")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    List<Map<String, Object>> plans() {
        return service.plans();
    }
}
