package com.societyapp.controller;

import com.societyapp.application.port.in.SupportUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.util.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/support")
@PreAuthorize("hasAnyRole('SUPER_ADMIN','SOCIETY_ADMIN')")
public class SupportChatController {
    private final SupportUseCase service;

    public SupportChatController(SupportUseCase service) {
        this.service = service;
    }

    public record CreateTicket(
            @NotBlank String subject,
            @NotBlank String description,
            @Pattern(regexp = "LOW|NORMAL|HIGH|URGENT") String priority) {}

    public record Send(@NotBlank @Size(max = 5000) String message) {}

    @GetMapping
    List<Map<String, Object>> tickets() {
        return service.tickets(CurrentUser.societyId());
    }

    @PostMapping
    Map<String, Object> create(@Valid @RequestBody CreateTicket r) {
        return service.create(
                CurrentUser.societyId(),
                CurrentUser.id(),
                r.subject(),
                r.description(),
                r.priority());
    }

    @GetMapping("/{ticketId}/messages")
    List<Map<String, Object>> messages(@PathVariable UUID ticketId) {
        return service.messages(
                ticketId, CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role());
    }

    @PostMapping("/{ticketId}/messages")
    Map<String, Object> send(@PathVariable UUID ticketId, @Valid @RequestBody Send r) {
        return service.send(
                ticketId,
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                r.message());
    }
}
