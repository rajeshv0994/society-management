package com.societyapp.controller;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.societyapp.application.port.in.SocietyOnboardingUseCase;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.util.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class SocietyController {
    private final SocietyOnboardingUseCase service;

    public SocietyController(SocietyOnboardingUseCase service) {
        this.service = service;
    }

    public record Registration(
            @NotBlank String name,
            @NotBlank String societyType,
            @Min(1) int totalBlocks,
            @JsonAlias({"totalSpaces", "totalUnits"}) @Min(1) int totalFlats,
            @Min(0) int plannedStaff,
            Integer approximateResidents,
            @NotBlank String address,
            @NotBlank String city,
            @NotBlank String state,
            @Pattern(regexp = "[0-9]{6}") String pinCode,
            @NotBlank String contactPerson,
            @Email String email,
            @NotBlank String mobile,
            @NotBlank String planCode,
            @NotNull List<String> enabledModules) {}

    public record Activation(
            @NotBlank String setupCode,
            @NotBlank String fullName,
            @Email String email,
            @NotBlank @Size(min = 8) String password,
            String mobile) {}

    @GetMapping("/public/plans")
    List<Map<String, Object>> plans() {
        return service.plans();
    }

    @GetMapping("/public/services")
    List<Map<String, Object>> services() {
        return service.services();
    }

    @GetMapping("/public/societies")
    List<Map<String, Object>> societies() {
        return service.activeSocieties();
    }

    @PostMapping("/public/societies/register")
    Map<String, Object> register(@Valid @RequestBody Registration r) {
        return service.register(
                new SocietyOnboardingUseCase.Registration(
                        r.name(),
                        r.societyType(),
                        r.totalBlocks(),
                        r.totalFlats(),
                        r.plannedStaff(),
                        r.approximateResidents(),
                        r.address(),
                        r.city(),
                        r.state(),
                        r.pinCode(),
                        r.contactPerson(),
                        r.email(),
                        r.mobile(),
                        r.planCode(),
                        r.enabledModules()));
    }

    @GetMapping("/admin/societies/pending")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    List<Map<String, Object>> pending() {
        return service.pending();
    }

    @PostMapping("/admin/societies/{id}/approve")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    Map<String, Object> approve(@PathVariable UUID id) {
        return service.approve(id);
    }

    @PostMapping("/admin/societies/{id}/reject")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    Map<String, Object> reject(@PathVariable UUID id, @RequestBody Map<String, String> body) {
        return service.reject(id, body.get("reason"));
    }

    @PostMapping("/public/societies/activate")
    Map<String, Object> activate(@Valid @RequestBody Activation a) {
        return service.activate(a.setupCode(), a.fullName(), a.email(), a.password(), a.mobile());
    }
}
