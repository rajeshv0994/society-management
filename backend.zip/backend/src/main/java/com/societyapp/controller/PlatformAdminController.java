package com.societyapp.controller;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.societyapp.application.port.in.AuditUseCase;
import com.societyapp.application.port.in.PlatformAdminUseCase;
import com.societyapp.application.port.in.PlatformMembershipBillingUseCase;
import com.societyapp.domain.type.SubscriptionPlanCode;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin/platform")
@PreAuthorize("hasRole('SUPER_ADMIN')")
public class PlatformAdminController {
    private final PlatformAdminUseCase service;
    private final PlatformMembershipBillingUseCase membershipBilling;
    private final AuditUseCase audits;

    public PlatformAdminController(
            PlatformAdminUseCase service,
            PlatformMembershipBillingUseCase membershipBilling,
            AuditUseCase audits) {
        this.service = service;
        this.membershipBilling = membershipBilling;
        this.audits = audits;
    }

    public record PlanUpdate(
            String name,
            @Pattern(regexp = "AUTO|MANUAL") String approvalMode,
            @JsonAlias({"maxSpaces", "maxUnits"}) @Min(1) Integer maxFlats,
            @JsonAlias("priceMonthly") @NotNull @DecimalMin("0") BigDecimal pricePerSpace,
            @Min(1) Integer maxStaff,
            @NotNull @DecimalMin("0") BigDecimal pricePerStaff,
            @Min(1) Integer trialDurationValue,
            @Pattern(regexp = "DAYS|MONTHS") String trialDurationUnit,
            @Min(1) Integer trialDurationMonths) {}

    public record TicketUpdate(
            @Pattern(regexp = "OPEN|IN_PROGRESS|RESOLVED|CLOSED") String status,
            String resolution) {}

    public record ServiceDefinition(
            @NotBlank @Pattern(regexp = "[A-Z][A-Z0-9_]{1,39}") String code,
            @NotBlank String name,
            String description,
            @NotBlank @Pattern(regexp = "ACTIVE|COMING_SOON|RETIRED") String status,
            @Min(0) int sortOrder,
            @NotBlank @Pattern(regexp = "DEFAULT_FREE|OPTIONAL_FREE|PAID_PER_SPACE")
                    String availabilityType,
            @NotNull @DecimalMin("0.00") BigDecimal pricePerSpace) {}

    public record SubscriptionInvoice(
            @NotNull UUID societyId, @NotNull LocalDate billingMonth, @NotNull LocalDate dueDate) {}

    public record PaymentReview(
            @NotBlank @Pattern(regexp = "PAID|REJECTED") String status, String rejectionReason) {}

    public record Cancellation(@NotBlank @Size(max = 300) String reason) {}

    public record PlatformPaymentSettings(
            @NotBlank String beneficiaryName,
            String bankName,
            String accountNumber,
            String ifscCode,
            String upiId,
            String instructions) {}

    public record CreateSociety(
            @NotBlank String name,
            @NotBlank String societyType,
            @Min(1) int totalBlocks,
            @JsonAlias({"totalSpaces", "totalUnits"}) @Min(1) int totalFlats,
            @Min(0) int plannedStaff,
            @NotBlank String address,
            @NotBlank String city,
            @NotBlank String state,
            @Pattern(regexp = "[0-9]{6}") String pinCode,
            @NotBlank String contactPerson,
            @Email String email,
            @NotBlank String mobile,
            @NotBlank String planCode,
            @NotNull List<String> enabledModules,
            Boolean issueInvoice) {}

    public record SocietyUpdate(
            @NotBlank String name,
            String description,
            String website,
            @NotBlank String contactPerson,
            @Email String email,
            @NotBlank String mobile,
            @NotBlank String address,
            @NotBlank String city,
            @NotBlank String state,
            @Pattern(regexp = "[0-9]{6}") String pinCode,
            @NotBlank String planCode,
            @Min(0) int plannedStaff,
            @Pattern(regexp = "ACTIVE|SUSPENDED|APPROVED") String status,
            @NotNull List<String> enabledModules) {}

    @GetMapping("/dashboard")
    Map<String, Object> dashboard() {
        return service.dashboard();
    }

    @GetMapping("/societies")
    List<Map<String, Object>> societies(
            @RequestParam(name = "status", required = false) String status,
            @RequestParam(name = "search", required = false) String search) {
        return service.societies(status, search);
    }

    @PostMapping("/societies")
    Map<String, Object> createSociety(@Valid @RequestBody CreateSociety request) {
        var created =
                service.createSociety(
                        CurrentUser.id(),
                        new PlatformAdminUseCase.CreateSociety(
                                request.name(),
                                request.societyType(),
                                request.totalBlocks(),
                                request.totalFlats(),
                                request.plannedStaff(),
                                request.address(),
                                request.city(),
                                request.state(),
                                request.pinCode(),
                                request.contactPerson(),
                                request.email(),
                                request.mobile(),
                                request.planCode(),
                                request.enabledModules()));
        var result = new LinkedHashMap<String, Object>(created);
        if (Boolean.TRUE.equals(request.issueInvoice())
                && !SubscriptionPlanCode.TRIAL.matches(request.planCode())) {
            var today = LocalDate.now();
            result.put(
                    "initialInvoice",
                    membershipBilling.issue(
                            UUID.fromString(created.get("societyId").toString()),
                            today.withDayOfMonth(1),
                            today.plusDays(15)));
        }
        return result;
    }

    @GetMapping("/societies/{id}")
    Map<String, Object> society(@PathVariable UUID id) {
        return service.society(id);
    }

    @PutMapping("/societies/{id}")
    Map<String, Object> updateSociety(
            @PathVariable UUID id, @Valid @RequestBody SocietyUpdate request) {
        return service.updateSociety(
                CurrentUser.id(),
                id,
                new PlatformAdminUseCase.UpdateSociety(
                        request.name(),
                        request.description(),
                        request.website(),
                        request.contactPerson(),
                        request.email(),
                        request.mobile(),
                        request.address(),
                        request.city(),
                        request.state(),
                        request.pinCode(),
                        request.planCode(),
                        request.plannedStaff(),
                        request.status(),
                        request.enabledModules()));
    }

    @GetMapping("/plans")
    List<Map<String, Object>> plans() {
        return service.plans();
    }

    @GetMapping("/services")
    List<Map<String, Object>> services() {
        return service.services();
    }

    @PostMapping("/services")
    Map<String, Object> createService(@Valid @RequestBody ServiceDefinition request) {
        return service.createService(
                CurrentUser.id(),
                request.code(),
                request.name(),
                request.description(),
                request.status(),
                request.sortOrder(),
                request.availabilityType(),
                request.pricePerSpace());
    }

    @PutMapping("/services/{code}")
    Map<String, Object> updateService(
            @PathVariable String code, @Valid @RequestBody ServiceDefinition request) {
        return service.updateService(
                CurrentUser.id(),
                code,
                request.name(),
                request.description(),
                request.status(),
                request.sortOrder(),
                request.availabilityType(),
                request.pricePerSpace());
    }

    @PutMapping("/plans/{code}")
    Map<String, Object> plan(@PathVariable String code, @Valid @RequestBody PlanUpdate request) {
        return service.updatePlan(
                CurrentUser.id(),
                code,
                request.name(),
                request.approvalMode(),
                request.maxFlats(),
                request.pricePerSpace(),
                request.maxStaff(),
                request.pricePerStaff(),
                request.trialDurationValue(),
                request.trialDurationUnit(),
                request.trialDurationMonths());
    }

    @GetMapping("/orders")
    List<Map<String, Object>> orders() {
        return membershipBilling.allOrders();
    }

    @PostMapping("/orders")
    Map<String, Object> issueInvoice(@Valid @RequestBody SubscriptionInvoice request) {
        return membershipBilling.issue(
                request.societyId(), request.billingMonth(), request.dueDate());
    }

    @GetMapping("/payment-gateway")
    Map<String, Object> paymentGateway() {
        return membershipBilling.gatewayStatus();
    }

    @GetMapping("/payment-settings")
    Map<String, Object> paymentSettings() {
        return membershipBilling.paymentSettings();
    }

    @PutMapping("/payment-settings")
    Map<String, Object> paymentSettings(@Valid @RequestBody PlatformPaymentSettings request) {
        return membershipBilling.updatePaymentSettings(
                CurrentUser.id(),
                request.beneficiaryName(),
                request.bankName(),
                request.accountNumber(),
                request.ifscCode(),
                request.upiId(),
                request.instructions());
    }

    @PostMapping("/orders/{id}/review")
    Map<String, Object> reviewPayment(
            @PathVariable UUID id, @Valid @RequestBody PaymentReview request) {
        return membershipBilling.review(
                CurrentUser.id(), id, request.status(), request.rejectionReason());
    }

    @PostMapping("/orders/{id}/reconcile")
    Map<String, Object> reconcilePayment(@PathVariable UUID id) {
        return membershipBilling.reconcile(id);
    }

    @PostMapping("/orders/{id}/cancel")
    Map<String, Object> cancelInvoice(
            @PathVariable UUID id, @Valid @RequestBody Cancellation request) {
        return membershipBilling.cancel(CurrentUser.id(), id, request.reason());
    }

    @GetMapping(value = "/orders/{id}/invoice", produces = MediaType.APPLICATION_PDF_VALUE)
    ResponseEntity<byte[]> invoice(@PathVariable UUID id) {
        var bytes = membershipBilling.adminInvoice(id);
        return ResponseEntity.ok()
                .header(
                        HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=platform-membership-invoice.pdf")
                .contentLength(bytes.length)
                .body(bytes);
    }

    @GetMapping("/notifications")
    List<Map<String, Object>> notifications(
            @RequestParam(name = "status", required = false) String status) {
        return service.notifications(status);
    }

    @PostMapping("/notifications/{id}/retry")
    Map<String, Object> retry(@PathVariable UUID id) {
        return service.retry(id);
    }

    @GetMapping("/audit")
    Map<String, Object> audit(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size,
            @RequestParam(required = false) String action,
            @RequestParam(required = false) String entityType,
            @RequestParam(required = false) UUID societyId,
            @RequestParam(required = false) UUID actorId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
                    java.time.OffsetDateTime from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
                    java.time.OffsetDateTime to,
            @RequestParam(required = false) String search) {
        return audits.search(page, size, action, entityType, societyId, actorId, from, to, search);
    }

    @GetMapping("/support")
    List<Map<String, Object>> tickets() {
        return service.tickets();
    }

    @PatchMapping("/support/{id}")
    Map<String, Object> ticket(@PathVariable UUID id, @Valid @RequestBody TicketUpdate request) {
        return service.updateTicket(CurrentUser.id(), id, request.status(), request.resolution());
    }
}
