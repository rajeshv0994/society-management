package com.societyapp.controller;

import com.societyapp.application.port.in.PlatformMembershipBillingUseCase;
import com.societyapp.application.port.in.SubscriptionQuantityUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import jakarta.validation.constraints.Min;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/society/subscription")
@PreAuthorize("hasRole('SOCIETY_ADMIN')")
public class SubscriptionController {
    private final SubscriptionQuantityUseCase service;
    private final PlatformMembershipBillingUseCase billing;

    public SubscriptionController(
            SubscriptionQuantityUseCase service, PlatformMembershipBillingUseCase billing) {
        this.service = service;
        this.billing = billing;
    }

    public record QuantityRequest(
            @Min(1) int totalSpaces,
            @Min(0) int totalStaff,
            @NotBlank @Pattern(regexp = "MONTHLY|QUARTERLY|YEARLY") String billingCycle,
            List<String> enabledModules) {}

    public record RazorpayCheckout(
            @NotBlank @Pattern(regexp = "UPI|CARD|NET_BANKING") String paymentMethod) {}

    public record RazorpayVerification(
            @NotBlank String razorpayOrderId,
            @NotBlank String razorpayPaymentId,
            @NotBlank String razorpaySignature) {}

    @GetMapping
    Map<String, Object> get() {
        return service.get(CurrentUser.societyId());
    }

    @PutMapping("/quantities")
    Map<String, Object> update(@Valid @RequestBody QuantityRequest request) {
        return service.update(
                CurrentUser.societyId(),
                request.totalSpaces(),
                request.totalStaff(),
                request.billingCycle(),
                request.enabledModules());
    }

    @GetMapping("/orders")
    List<Map<String, Object>> orders() {
        return billing.societyOrders(CurrentUser.societyId());
    }

    @PostMapping("/orders/{id}/checkout")
    Map<String, Object> checkout(
            @PathVariable UUID id, @Valid @RequestBody RazorpayCheckout request) {
        return billing.checkout(CurrentUser.societyId(), id, request.paymentMethod());
    }

    @PostMapping("/orders/{id}/verify")
    Map<String, Object> verify(
            @PathVariable UUID id, @Valid @RequestBody RazorpayVerification request) {
        return billing.verifyCheckout(
                CurrentUser.societyId(),
                id,
                request.razorpayOrderId(),
                request.razorpayPaymentId(),
                request.razorpaySignature());
    }

    @GetMapping(value = "/orders/{id}/invoice", produces = MediaType.APPLICATION_PDF_VALUE)
    ResponseEntity<byte[]> invoice(@PathVariable UUID id) {
        var bytes = billing.societyInvoice(CurrentUser.societyId(), id);
        return ResponseEntity.ok()
                .header(
                        HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=platform-membership-invoice.pdf")
                .contentLength(bytes.length)
                .body(bytes);
    }
}
