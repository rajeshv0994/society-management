package com.societyapp.controller;

import com.societyapp.application.port.in.ConfigurationUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/society/configuration")
@PreAuthorize("hasRole('SOCIETY_ADMIN')")
public class ConfigurationController {
    private final ConfigurationUseCase service;

    public ConfigurationController(ConfigurationUseCase service) {
        this.service = service;
    }

    public record Parking(
            @NotBlank @Size(max = 40) String slotNumber,
            @Pattern(regexp = "CAR|BIKE|VISITOR|ACCESSIBLE") String slotType) {}

    public record ParkingAction(
            @NotBlank @Pattern(regexp = "ALLOCATE|RELEASE|RESERVE|MAINTENANCE|ACTIVATE|DEACTIVATE")
                    String action,
            UUID flatId,
            @Size(max = 30) String vehicleNumber) {}

    public record Vendor(
            @NotBlank @Size(max = 150) String name,
            @NotBlank @Size(max = 80) String serviceType,
            @Size(max = 120) String contactPerson,
            @NotBlank @Pattern(regexp = "[0-9+() -]{7,20}") String mobile,
            @Email @Size(max = 180) String email,
            @Pattern(regexp = "^$|[A-Za-z0-9 -]{5,30}") String gstNumber) {}

    public record Category(
            @NotBlank @Size(max = 100) String name, @Min(1) @Max(8760) int slaHours) {}

    public record Charge(
            @NotBlank @Size(max = 120) String name,
            @Pattern(regexp = "FIXED|PER_SQFT|PERCENTAGE") String calculationType,
            @NotNull @DecimalMin("0") BigDecimal amount,
            @Pattern(regexp = "MONTHLY|QUARTERLY|YEARLY|ONE_TIME") String frequency,
            @NotNull LocalDate effectiveFrom,
            LocalDate effectiveTo) {}

    public record Active(@NotNull Boolean active) {}

    public record VendorStatus(@Pattern(regexp = "ACTIVE|INACTIVE") String status) {}

    public record Permissions(@NotEmpty Set<String> permissions) {}

    @GetMapping
    Map<String, Object> get() {
        return service.get(CurrentUser.societyId());
    }

    @PostMapping("/parking")
    Map<String, Object> parking(@Valid @RequestBody Parking r) {
        return service.addParking(
                CurrentUser.societyId(), CurrentUser.id(), r.slotNumber(), r.slotType());
    }

    @PutMapping("/parking/{id}")
    Map<String, Object> parking(@PathVariable UUID id, @Valid @RequestBody Parking request) {
        return service.updateParking(
                CurrentUser.societyId(),
                CurrentUser.id(),
                id,
                request.slotNumber(),
                request.slotType());
    }

    @PatchMapping("/parking/{id}")
    Map<String, Object> parkingAction(
            @PathVariable UUID id, @Valid @RequestBody ParkingAction request) {
        return service.parkingAction(
                CurrentUser.societyId(),
                CurrentUser.id(),
                id,
                request.action(),
                request.flatId(),
                request.vehicleNumber());
    }

    @DeleteMapping("/parking/{id}")
    Map<String, Object> removeParking(@PathVariable UUID id) {
        return service.parkingAction(
                CurrentUser.societyId(), CurrentUser.id(), id, "DEACTIVATE", null, null);
    }

    @PostMapping("/vendors")
    Map<String, Object> vendor(@Valid @RequestBody Vendor r) {
        return service.addVendor(
                CurrentUser.societyId(),
                CurrentUser.id(),
                r.name(),
                r.serviceType(),
                r.contactPerson(),
                r.mobile(),
                r.email(),
                r.gstNumber());
    }

    @PutMapping("/vendors/{id}")
    Map<String, Object> vendor(@PathVariable UUID id, @Valid @RequestBody Vendor request) {
        return service.updateVendor(
                CurrentUser.societyId(),
                CurrentUser.id(),
                id,
                request.name(),
                request.serviceType(),
                request.contactPerson(),
                request.mobile(),
                request.email(),
                request.gstNumber());
    }

    @PatchMapping("/vendors/{id}")
    Map<String, Object> vendorStatus(
            @PathVariable UUID id, @Valid @RequestBody VendorStatus request) {
        return service.setVendorStatus(
                CurrentUser.societyId(), CurrentUser.id(), id, request.status());
    }

    @DeleteMapping("/vendors/{id}")
    Map<String, Object> removeVendor(@PathVariable UUID id) {
        return service.setVendorStatus(CurrentUser.societyId(), CurrentUser.id(), id, "INACTIVE");
    }

    @PostMapping("/complaint-categories")
    Map<String, Object> category(@Valid @RequestBody Category r) {
        return service.addCategory(
                CurrentUser.societyId(), CurrentUser.id(), r.name(), r.slaHours());
    }

    @PutMapping("/complaint-categories/{id}")
    Map<String, Object> category(@PathVariable UUID id, @Valid @RequestBody Category request) {
        return service.updateCategory(
                CurrentUser.societyId(), CurrentUser.id(), id, request.name(), request.slaHours());
    }

    @PatchMapping("/complaint-categories/{id}")
    Map<String, Object> categoryStatus(@PathVariable UUID id, @Valid @RequestBody Active request) {
        return service.setCategoryStatus(
                CurrentUser.societyId(), CurrentUser.id(), id, request.active());
    }

    @DeleteMapping("/complaint-categories/{id}")
    Map<String, Object> removeCategory(@PathVariable UUID id) {
        return service.setCategoryStatus(CurrentUser.societyId(), CurrentUser.id(), id, false);
    }

    @PostMapping("/charge-rules")
    Map<String, Object> charge(@Valid @RequestBody Charge r) {
        return service.addCharge(
                CurrentUser.societyId(),
                CurrentUser.id(),
                r.name(),
                r.calculationType(),
                r.amount(),
                r.frequency(),
                r.effectiveFrom(),
                r.effectiveTo());
    }

    @PutMapping("/charge-rules/{id}")
    Map<String, Object> charge(@PathVariable UUID id, @Valid @RequestBody Charge request) {
        return service.updateCharge(
                CurrentUser.societyId(),
                CurrentUser.id(),
                id,
                request.name(),
                request.calculationType(),
                request.amount(),
                request.frequency(),
                request.effectiveFrom(),
                request.effectiveTo());
    }

    @PatchMapping("/charge-rules/{id}")
    Map<String, Object> chargeStatus(@PathVariable UUID id, @Valid @RequestBody Active request) {
        return service.setChargeStatus(
                CurrentUser.societyId(), CurrentUser.id(), id, request.active());
    }

    @DeleteMapping("/charge-rules/{id}")
    Map<String, Object> removeCharge(@PathVariable UUID id) {
        return service.setChargeStatus(CurrentUser.societyId(), CurrentUser.id(), id, false);
    }

    @PutMapping("/staff/{staffId}/permissions")
    Map<String, Object> permissions(@PathVariable UUID staffId, @Valid @RequestBody Permissions r) {
        return service.setPermissions(
                CurrentUser.societyId(), CurrentUser.id(), staffId, r.permissions());
    }

    @PostMapping("/complete")
    Map<String, Object> complete() {
        return service.complete(CurrentUser.societyId(), CurrentUser.id());
    }
}
