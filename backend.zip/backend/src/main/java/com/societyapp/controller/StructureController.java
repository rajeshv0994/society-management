package com.societyapp.controller;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.societyapp.application.port.in.StructureUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.util.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/society/structure")
@PreAuthorize("hasRole('SOCIETY_ADMIN')")
public class StructureController {
    private final StructureUseCase service;

    public StructureController(StructureUseCase service) {
        this.service = service;
    }

    public record BlockRequest(@NotBlank String name) {}

    public record FloorRequest(@NotBlank String name, @JsonAlias("sectionOrder") int floorNumber) {}

    public record FlatRequest(
            @JsonAlias({"spaceNumber", "unitNumber"}) @NotBlank String flatNumber,
            @DecimalMin("0") BigDecimal areaSqft) {}

    @GetMapping
    Map<String, Object> get() {
        return service.get(CurrentUser.societyId());
    }

    @PostMapping("/blocks")
    Map<String, Object> block(@Valid @RequestBody BlockRequest r) {
        return service.addBlock(CurrentUser.societyId(), r.name());
    }

    @PutMapping("/blocks/{blockId}")
    Map<String, Object> updateBlock(
            @PathVariable UUID blockId, @Valid @RequestBody BlockRequest r) {
        return service.updateBlock(CurrentUser.societyId(), blockId, r.name());
    }

    @DeleteMapping("/blocks/{blockId}")
    Map<String, Object> deleteBlock(@PathVariable UUID blockId) {
        return service.deleteBlock(CurrentUser.societyId(), blockId);
    }

    @PostMapping({"/blocks/{blockId}/sections", "/blocks/{blockId}/floors"})
    Map<String, Object> floor(@PathVariable UUID blockId, @Valid @RequestBody FloorRequest r) {
        return service.addFloor(CurrentUser.societyId(), blockId, r.name(), r.floorNumber());
    }

    @PutMapping({"/sections/{floorId}", "/floors/{floorId}"})
    Map<String, Object> updateFloor(
            @PathVariable UUID floorId, @Valid @RequestBody FloorRequest r) {
        return service.updateFloor(CurrentUser.societyId(), floorId, r.name(), r.floorNumber());
    }

    @DeleteMapping({"/sections/{floorId}", "/floors/{floorId}"})
    Map<String, Object> deleteFloor(@PathVariable UUID floorId) {
        return service.deleteFloor(CurrentUser.societyId(), floorId);
    }

    @PostMapping({
        "/sections/{floorId}/spaces",
        "/floors/{floorId}/units",
        "/floors/{floorId}/flats"
    })
    Map<String, Object> flat(@PathVariable UUID floorId, @Valid @RequestBody FlatRequest r) {
        return service.addFlat(CurrentUser.societyId(), floorId, r.flatNumber(), r.areaSqft());
    }

    @PostMapping("/spaces")
    Map<String, Object> space(@Valid @RequestBody FlatRequest r) {
        return service.addSpace(CurrentUser.societyId(), r.flatNumber(), r.areaSqft());
    }

    @PutMapping({"/spaces/{flatId}", "/units/{flatId}", "/flats/{flatId}"})
    Map<String, Object> updateFlat(@PathVariable UUID flatId, @Valid @RequestBody FlatRequest r) {
        return service.updateFlat(CurrentUser.societyId(), flatId, r.flatNumber(), r.areaSqft());
    }

    @DeleteMapping({"/spaces/{flatId}", "/units/{flatId}", "/flats/{flatId}"})
    Map<String, Object> deleteFlat(@PathVariable UUID flatId) {
        return service.deleteFlat(CurrentUser.societyId(), flatId);
    }
}
