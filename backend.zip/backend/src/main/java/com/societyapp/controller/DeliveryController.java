package com.societyapp.controller;

import com.societyapp.application.port.in.DeliveryUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/deliveries")
@PreAuthorize("hasAnyRole('SOCIETY_ADMIN','STAFF','RESIDENT')")
public class DeliveryController {
    private final DeliveryUseCase service;

    public DeliveryController(DeliveryUseCase service) {
        this.service = service;
    }

    public record DeliveryRequest(
            UUID residentId,
            @NotNull UUID flatId,
            @Size(max = 100) String trackingNumber,
            @NotBlank @Size(max = 80) String provider,
            @Size(max = 150) String senderName,
            @Size(max = 150) String deliveryPersonName,
            @Pattern(regexp = "^$|[0-9+() -]{7,20}$") String deliveryPersonMobile,
            @NotBlank @Pattern(regexp = "DOCUMENT|PACKAGE|FOOD|GROCERY|MEDICINE|OTHER")
                    String parcelType,
            @Min(1) @Max(100) int packageCount,
            @NotBlank @Pattern(regexp = "SMALL|MEDIUM|LARGE|OVERSIZED") String parcelSize,
            boolean fragile,
            @Size(max = 80) String storageLocation,
            OffsetDateTime expectedAt,
            @Size(max = 500) String notes,
            @NotNull @DecimalMin("0") BigDecimal codAmount,
            boolean receivedNow) {}

    public record ActionRequest(
            @NotBlank
                    @Pattern(
                            regexp =
                                    "ACCEPT|REJECT|AUTHORIZE|CANCEL|RECEIVE|MARK_READY|OUT_FOR_DELIVERY|HANDOVER|DELIVER|RETURN|DAMAGED|LOST")
                    String action,
            @Size(max = 500) String note,
            @Size(max = 150) String collectorName,
            @Pattern(regexp = "[0-9]{6}") String pickupCode) {}

    public record CheckoutRequest(
            @NotBlank @Pattern(regexp = "UPI|CARD|NET_BANKING") String paymentMethod) {}

    public record CodRequest(@NotBlank @Pattern(regexp = "CASH|UPI|CARD") String paymentMethod) {}

    @GetMapping
    Map<String, Object> workspace() {
        return service.workspace(CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role());
    }

    @GetMapping("/{id}/history")
    List<Map<String, Object>> history(@PathVariable UUID id) {
        return service.history(CurrentUser.societyId(), CurrentUser.id(), CurrentUser.role(), id);
    }

    @PostMapping
    Map<String, Object> create(@Valid @RequestBody DeliveryRequest request) {
        return service.create(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                request.residentId(),
                request.flatId(),
                request.trackingNumber(),
                request.provider(),
                request.senderName(),
                request.deliveryPersonName(),
                request.deliveryPersonMobile(),
                request.parcelType(),
                request.packageCount(),
                request.parcelSize(),
                request.fragile(),
                request.storageLocation(),
                request.expectedAt(),
                request.notes(),
                request.codAmount(),
                request.receivedNow());
    }

    @PatchMapping("/{id}")
    Map<String, Object> action(@PathVariable UUID id, @Valid @RequestBody ActionRequest request) {
        return service.action(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                id,
                request.action(),
                request.note(),
                request.collectorName(),
                request.pickupCode());
    }

    @PostMapping("/{id}/checkout")
    Map<String, Object> checkout(
            @PathVariable UUID id, @Valid @RequestBody CheckoutRequest request) {
        return service.checkout(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                id,
                request.paymentMethod());
    }

    @PostMapping("/{id}/cod")
    Map<String, Object> recordCod(@PathVariable UUID id, @Valid @RequestBody CodRequest request) {
        return service.recordCod(
                CurrentUser.societyId(),
                CurrentUser.id(),
                CurrentUser.role(),
                id,
                request.paymentMethod());
    }
}
