package com.societyapp.controller;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.societyapp.application.port.in.ResidentUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.time.LocalDate;
import java.util.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ResidentController {
    private final ResidentUseCase service;

    public ResidentController(ResidentUseCase service) {
        this.service = service;
    }

    public record Request(
            @NotNull UUID societyId,
            @JsonAlias({"spaceId", "unitId"}) @NotNull UUID flatId,
            @Pattern(regexp = "OWNER|TENANT") String residentType,
            @NotBlank String fullName,
            @NotBlank String mobile,
            @Email String email,
            LocalDate dob,
            String gender,
            String emergencyContact,
            LocalDate moveInDate,
            LocalDate moveOutDate) {}

    public record Review(
            @Pattern(regexp = "APPROVE|REJECT") String decision,
            String reason,
            @Size(min = 8) String temporaryPassword) {}

    public record AdminCreate(
            @JsonAlias({"spaceId", "unitId"}) @NotNull UUID flatId,
            @Pattern(regexp = "OWNER|TENANT") String residentType,
            @NotBlank String fullName,
            @NotBlank String mobile,
            @NotBlank @Email String email,
            LocalDate dob,
            String gender,
            String emergencyContact,
            LocalDate moveInDate,
            LocalDate moveOutDate,
            @NotBlank @Size(min = 8) String temporaryPassword) {}

    public record HouseholdMember(
            @NotBlank String fullName,
            @NotBlank String relationship,
            String mobile,
            LocalDate dateOfBirth) {}

    @GetMapping({
        "/public/societies/{societyId}/spaces",
        "/public/societies/{societyId}/units",
        "/public/societies/{societyId}/flats"
    })
    List<Map<String, Object>> flats(@PathVariable UUID societyId) {
        return service.flats(societyId);
    }

    @PostMapping("/public/residents/register")
    Map<String, Object> register(@Valid @RequestBody Request r) {
        return service.register(
                r.societyId(),
                r.flatId(),
                r.residentType(),
                r.fullName(),
                r.mobile(),
                r.email(),
                r.dob(),
                r.gender(),
                r.emergencyContact(),
                r.moveInDate(),
                r.moveOutDate());
    }

    @GetMapping("/society/residents/pending")
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    List<Map<String, Object>> pending() {
        return service.pending(CurrentUser.societyId());
    }

    @GetMapping("/society/residents")
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    List<Map<String, Object>> residents() {
        return service.residents(CurrentUser.societyId());
    }

    @PostMapping("/society/residents")
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    Map<String, Object> create(@Valid @RequestBody AdminCreate request) {
        return service.createResident(
                CurrentUser.societyId(),
                CurrentUser.id(),
                request.flatId(),
                request.residentType(),
                request.fullName(),
                request.mobile(),
                request.email(),
                request.dob(),
                request.gender(),
                request.emergencyContact(),
                request.moveInDate(),
                request.moveOutDate(),
                request.temporaryPassword());
    }

    @GetMapping("/society/residents/{id}")
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    Map<String, Object> resident(@PathVariable UUID id) {
        return service.resident(CurrentUser.societyId(), id);
    }

    @PostMapping("/society/residents/{id}/household")
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    Map<String, Object> addHousehold(
            @PathVariable UUID id, @Valid @RequestBody HouseholdMember member) {
        return service.addHouseholdMember(
                CurrentUser.societyId(),
                id,
                member.fullName(),
                member.relationship(),
                member.mobile(),
                member.dateOfBirth());
    }

    @DeleteMapping("/society/residents/{residentId}/household/{memberId}")
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    Map<String, Object> removeHousehold(
            @PathVariable UUID residentId, @PathVariable UUID memberId) {
        return service.removeHouseholdMember(CurrentUser.societyId(), residentId, memberId);
    }

    @PostMapping("/society/residents/{id}/review")
    @PreAuthorize("hasRole('SOCIETY_ADMIN')")
    Map<String, Object> review(@PathVariable UUID id, @Valid @RequestBody Review review) {
        return service.review(
                CurrentUser.societyId(),
                CurrentUser.id(),
                id,
                review.decision(),
                review.reason(),
                review.temporaryPassword());
    }
}
