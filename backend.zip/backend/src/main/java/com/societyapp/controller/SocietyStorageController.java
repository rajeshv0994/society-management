package com.societyapp.controller;

import com.societyapp.application.port.in.StorageCleanupUseCase;
import com.societyapp.application.port.in.StorageMeterUseCase;
import com.societyapp.security.CurrentUser;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import java.util.Map;
import java.util.UUID;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/society/storage")
@PreAuthorize("hasRole('SOCIETY_ADMIN')")
public class SocietyStorageController {
    private final StorageMeterUseCase storage;
    private final StorageCleanupUseCase cleanup;

    public SocietyStorageController(StorageMeterUseCase storage, StorageCleanupUseCase cleanup) {
        this.storage = storage;
        this.cleanup = cleanup;
    }

    public record Purchase(@Min(1) @Max(100) int blocks) {}

    @GetMapping
    Map<String, Object> dashboard() {
        return storage.societyDashboard(CurrentUser.societyId());
    }

    @PostMapping("/purchases")
    Map<String, Object> purchase(@Valid @RequestBody Purchase request) {
        return storage.purchase(CurrentUser.societyId(), CurrentUser.id(), request.blocks());
    }

    @DeleteMapping("/files/{id}")
    Map<String, Object> delete(@PathVariable UUID id) {
        return cleanup.delete(CurrentUser.societyId(), CurrentUser.id(), id);
    }
}
