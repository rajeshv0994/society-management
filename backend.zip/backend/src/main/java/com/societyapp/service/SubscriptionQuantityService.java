package com.societyapp.service;

import com.societyapp.application.exception.ConflictException;
import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.policy.ServiceCatalogPolicy;
import com.societyapp.application.port.in.SubscriptionQuantityUseCase;
import com.societyapp.domain.type.AccountStatus;
import com.societyapp.domain.type.BillingCycle;
import com.societyapp.domain.type.LifecycleStatus;
import com.societyapp.domain.type.PricingModel;
import com.societyapp.domain.type.UserRole;
import com.societyapp.entity.SocietyCustomPlan;
import com.societyapp.repository.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.*;

public class SubscriptionQuantityService implements SubscriptionQuantityUseCase {
    private final SocietyRepository societies;
    private final SubscriptionPlanRepository plans;
    private final SocietyCustomPlanRepository customPlans;
    private final BlockRepository blocks;
    private final FloorRepository sections;
    private final FlatRepository spaces;
    private final UserAccountJpaRepository users;
    private final ServiceCatalogPolicy serviceCatalog;

    public SubscriptionQuantityService(
            SocietyRepository societies,
            SubscriptionPlanRepository plans,
            SocietyCustomPlanRepository customPlans,
            BlockRepository blocks,
            FloorRepository sections,
            FlatRepository spaces,
            UserAccountJpaRepository users,
            ServiceCatalogPolicy serviceCatalog) {
        this.societies = societies;
        this.plans = plans;
        this.customPlans = customPlans;
        this.blocks = blocks;
        this.sections = sections;
        this.spaces = spaces;
        this.users = users;
        this.serviceCatalog = serviceCatalog;
    }

    public Map<String, Object> get(UUID societyId) {
        var society =
                societies
                        .findById(societyId)
                        .orElseThrow(() -> new ResourceNotFoundException("Society not found"));
        var pricing = pricing(societyId, society.getPlanCode());
        long configuredSpaces = configuredSpaces(societyId);
        long activeStaff = activeStaff(societyId);
        BigDecimal baseMonthly =
                pricing.fixedMonthlyPrice()
                        .add(
                                pricing.pricePerSpace()
                                        .multiply(BigDecimal.valueOf(society.getTotalFlats()))
                                        .add(
                                                pricing.pricePerStaff()
                                                        .multiply(
                                                                BigDecimal.valueOf(
                                                                        society
                                                                                .getPlannedStaff()))));
        var servicePricing = serviceCatalog.servicePricing(society);
        BigDecimal monthly = baseMonthly.add(servicePricing.monthlyAmount());

        var result = new LinkedHashMap<String, Object>();
        result.put("plan_code", society.getPlanCode());
        result.put("selected_spaces", society.getTotalFlats());
        result.put("selected_staff", society.getPlannedStaff());
        result.put("configured_spaces", configuredSpaces);
        result.put("active_staff", activeStaff);
        result.put("price_per_space", pricing.pricePerSpace());
        result.put("price_per_staff", pricing.pricePerStaff());
        result.put("fixed_monthly_price", pricing.fixedMonthlyPrice());
        result.put(
                "pricing_model",
                pricing.fixedMonthlyPrice().signum() > 0
                        ? PricingModel.FIXED_CUSTOM.code()
                        : PricingModel.USAGE_BASED.code());
        result.put("max_spaces", pricing.maxSpaces());
        result.put("max_staff", pricing.maxStaff());
        result.put("base_monthly_price", baseMonthly);
        result.put("service_monthly_price", servicePricing.monthlyAmount());
        result.put("estimated_monthly_price", monthly);
        int cycleMonths = cycleMonths(society.getSubscriptionBillingCycle());
        result.put("billing_cycle", society.getSubscriptionBillingCycle());
        result.put("billing_cycle_months", cycleMonths);
        result.put("billing_cycle_amount", monthly.multiply(BigDecimal.valueOf(cycleMonths)));
        result.put("subscription_status", society.getSubscriptionStatus());
        result.put("subscription_expires_at", society.getSubscriptionExpiresAt());
        result.put("enabled_modules", serviceCatalog.selected(society));
        result.put("service_catalog", serviceCatalog.catalogFor(society));
        var breakdown = new ArrayList<Map<String, Object>>();
        if (pricing.fixedMonthlyPrice().signum() > 0) {
            breakdown.add(
                    Map.of(
                            "code",
                            PricingModel.FIXED_BASE.code(),
                            "name",
                            "Fixed custom plan",
                            "quantity",
                            1,
                            "rate",
                            pricing.fixedMonthlyPrice(),
                            "monthly_amount",
                            pricing.fixedMonthlyPrice()));
        }
        breakdown.add(
                Map.of(
                        "code",
                        "BASE_SPACE",
                        "name",
                        "Base space subscription",
                        "quantity",
                        society.getTotalFlats(),
                        "rate",
                        pricing.pricePerSpace(),
                        "monthly_amount",
                        pricing.pricePerSpace()
                                .multiply(BigDecimal.valueOf(society.getTotalFlats()))));
        breakdown.add(
                Map.of(
                        "code",
                        "BASE_STAFF",
                        "name",
                        "Staff seats",
                        "quantity",
                        society.getPlannedStaff(),
                        "rate",
                        pricing.pricePerStaff(),
                        "monthly_amount",
                        pricing.pricePerStaff()
                                .multiply(BigDecimal.valueOf(society.getPlannedStaff()))));
        breakdown.addAll(servicePricing.lines());
        result.put("pricing_breakdown", breakdown);
        return result;
    }

    public Map<String, Object> update(
            UUID societyId, int totalSpaces, int totalStaff, String billingCycle) {
        return update(societyId, totalSpaces, totalStaff, billingCycle, null);
    }

    public Map<String, Object> update(
            UUID societyId,
            int totalSpaces,
            int totalStaff,
            String billingCycle,
            List<String> enabledModules) {
        var society =
                societies
                        .findById(societyId)
                        .orElseThrow(() -> new ResourceNotFoundException("Society not found"));
        long configuredSpaces = configuredSpaces(societyId);
        long activeStaff = activeStaff(societyId);
        if (totalSpaces < configuredSpaces) {
            throw new ConflictException(
                    "Selected spaces cannot be below the "
                            + configuredSpaces
                            + " spaces currently configured.");
        }
        if (totalStaff < activeStaff) {
            throw new ConflictException(
                    "Selected staff cannot be below the "
                            + activeStaff
                            + " active staff accounts.");
        }
        var pricing = pricing(societyId, society.getPlanCode());
        if (pricing.maxSpaces() != null && totalSpaces > pricing.maxSpaces()) {
            throw new ConflictException(
                    "This plan allows a maximum of " + pricing.maxSpaces() + " spaces.");
        }
        if (pricing.maxStaff() != null && totalStaff > pricing.maxStaff()) {
            throw new ConflictException(
                    "This plan allows a maximum of " + pricing.maxStaff() + " staff.");
        }
        society.setTotalFlats(totalSpaces);
        society.setPlannedStaff(totalStaff);
        society.setSubscriptionBillingCycle(billingCycle);
        if (enabledModules != null) {
            society.setEnabledModules(
                    serviceCatalog.writeSelection(
                            serviceCatalog.normalizeSelection(enabledModules)));
        }
        society.setUpdatedAt(OffsetDateTime.now());
        societies.save(society);
        return get(societyId);
    }

    private int cycleMonths(String cycle) {
        return switch (BillingCycle.from(cycle == null ? BillingCycle.MONTHLY.code() : cycle)) {
            case QUARTERLY -> 3;
            case YEARLY -> 12;
            case MONTHLY -> 1;
        };
    }

    private long configuredSpaces(UUID societyId) {
        return blocks.findBySocietyIdOrderByName(societyId).stream()
                .flatMap(block -> sections.findByBlockIdOrderByFloorNumber(block.getId()).stream())
                .mapToLong(section -> spaces.findByFloorIdOrderByFlatNumber(section.getId()).size())
                .sum();
    }

    private long activeStaff(UUID societyId) {
        return users
                .findBySocietyIdAndRoleOrderByFullName(societyId, UserRole.STAFF.code())
                .stream()
                .filter(user -> AccountStatus.ACTIVE.matches(user.getStatus()))
                .count();
    }

    private Pricing pricing(UUID societyId, String planCode) {
        Optional<SocietyCustomPlan> custom =
                customPlans.findAllByOrderByCreatedAtDesc().stream()
                        .filter(plan -> societyId.equals(plan.getSocietyId()))
                        .filter(plan -> LifecycleStatus.ACTIVE.matches(plan.getStatus()))
                        .findFirst();
        if (custom.isPresent()) {
            var plan = custom.get();
            var fixedMonthly =
                    plan.getPricePerSpace().signum() == 0 && plan.getPricePerStaff().signum() == 0
                            ? plan.getPriceMonthly()
                            : BigDecimal.ZERO;
            return new Pricing(
                    plan.getPricePerSpace(),
                    plan.getPricePerStaff(),
                    fixedMonthly,
                    plan.getMaxFlats(),
                    plan.getMaxStaff());
        }
        var plan =
                plans.findById(planCode)
                        .orElseThrow(
                                () -> new ResourceNotFoundException("Subscription plan not found"));
        return new Pricing(
                plan.getPricePerSpace(),
                plan.getPricePerStaff(),
                BigDecimal.ZERO,
                plan.getMaxFlats(),
                plan.getMaxStaff());
    }

    private record Pricing(
            BigDecimal pricePerSpace,
            BigDecimal pricePerStaff,
            BigDecimal fixedMonthlyPrice,
            Integer maxSpaces,
            Integer maxStaff) {}
}
