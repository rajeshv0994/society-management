package com.societyapp.service;

import com.societyapp.application.exception.AuthorizationException;
import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.port.in.BillingUseCase;
import com.societyapp.application.port.in.StructureAccessUseCase;
import com.societyapp.application.port.out.ReceiptRenderer;
import com.societyapp.domain.type.PaymentChannel;
import com.societyapp.domain.type.PaymentMethod;
import com.societyapp.domain.type.PaymentStatus;
import com.societyapp.domain.type.StaffPermissionCode;
import com.societyapp.domain.type.UserRole;
import com.societyapp.entity.*;
import com.societyapp.repository.*;
import java.math.BigDecimal;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class BillingService implements BillingUseCase {
    private static final Set<PaymentMethod> OFFICE_METHODS = Set.of(PaymentMethod.CASH);
    private static final Set<PaymentMethod> ONLINE_METHODS =
            Set.of(PaymentMethod.UPI, PaymentMethod.CARD, PaymentMethod.NET_BANKING);

    private final MaintenanceInvoiceRepository invoices;
    private final PaymentRepository payments;
    private final FlatRepository flats;
    private final FloorRepository floors;
    private final BlockRepository blocks;
    private final StructureAccessUseCase access;
    private final StaffPermissionRepository permissions;
    private final UserAccountJpaRepository users;
    private final SocietyRepository societies;
    private final SocietyPaymentSettingRepository paymentSettings;
    private final ReceiptRenderer receiptRenderer;

    public BillingService(
            MaintenanceInvoiceRepository invoices,
            PaymentRepository payments,
            FlatRepository flats,
            FloorRepository floors,
            BlockRepository blocks,
            StructureAccessUseCase access,
            StaffPermissionRepository permissions,
            UserAccountJpaRepository users,
            SocietyRepository societies,
            SocietyPaymentSettingRepository paymentSettings,
            ReceiptRenderer receiptRenderer) {
        this.invoices = invoices;
        this.payments = payments;
        this.flats = flats;
        this.floors = floors;
        this.blocks = blocks;
        this.access = access;
        this.permissions = permissions;
        this.users = users;
        this.societies = societies;
        this.paymentSettings = paymentSettings;
        this.receiptRenderer = receiptRenderer;
    }

    public List<Map<String, Object>> list(UUID societyId, UUID userId, String role) {
        requireRoleAccess(userId, role);
        return invoices.findBySocietyIdOrderByBillingMonthDesc(societyId).stream()
                .filter(invoice -> canViewInvoice(invoice, userId, role))
                .map(this::invoiceView)
                .toList();
    }

    public List<Map<String, Object>> payments(UUID societyId, UUID userId, String role) {
        requireRoleAccess(userId, role);
        return payments.findBySocietyIdOrderByPaidAtDesc(societyId).stream()
                .filter(
                        payment ->
                                invoices.findById(payment.getInvoiceId())
                                        .filter(invoice -> canViewInvoice(invoice, userId, role))
                                        .isPresent())
                .map(this::paymentView)
                .toList();
    }

    public List<Map<String, Object>> invoicePayments(
            UUID societyId, UUID userId, String role, UUID invoiceId) {
        requireInvoice(societyId, userId, role, invoiceId);
        return payments.findByInvoiceIdOrderByPaidAtDesc(invoiceId).stream()
                .map(this::paymentView)
                .toList();
    }

    public Map<String, Object> options(UUID societyId, UUID userId, String role) {
        requireRoleAccess(userId, role);
        var result = new LinkedHashMap<String, Object>();
        result.put("current_user_id", userId);
        result.put("role", role);
        result.put(
                "payment_methods",
                (UserRole.RESIDENT.matches(role) ? ONLINE_METHODS : OFFICE_METHODS)
                        .stream().map(PaymentMethod::code).toList());
        paymentSettings
                .findBySocietyId(societyId)
                .ifPresent(
                        setting ->
                                result.put(
                                        "online_payment",
                                        paymentSettingView(
                                                setting, UserRole.SOCIETY_ADMIN.matches(role))));
        var spaces = new ArrayList<Map<String, Object>>();
        for (var flat : flats.findAll()) {
            if (!access.belongsToSociety(flat.getId(), societyId)) continue;
            if (UserRole.RESIDENT.matches(role) && !access.occupiedBy(flat.getId(), userId))
                continue;
            spaces.add(spaceView(flat));
        }
        result.put("spaces", spaces);
        return result;
    }

    public Map<String, Object> create(
            UUID societyId,
            UUID flatId,
            String invoiceNumber,
            LocalDate billingMonth,
            LocalDate dueDate,
            BigDecimal membershipFee,
            BigDecimal otherCharges,
            String otherChargeNote,
            BigDecimal legacySubtotal) {
        access.requireFlat(flatId, societyId);
        if (dueDate.isBefore(billingMonth.withDayOfMonth(1))) {
            throw new IllegalArgumentException("Due date cannot be before the billing month");
        }
        BigDecimal membership = membershipFee == null ? BigDecimal.ZERO : membershipFee;
        BigDecimal other = otherCharges == null ? BigDecimal.ZERO : otherCharges;
        if (membership.signum() == 0 && other.signum() == 0 && legacySubtotal != null) {
            membership = legacySubtotal;
        }
        BigDecimal subtotal = membership.add(other);
        if (subtotal.signum() <= 0) {
            throw new IllegalArgumentException("Add a membership fee or another society charge");
        }
        if (other.signum() > 0 && (otherChargeNote == null || otherChargeNote.isBlank())) {
            throw new IllegalArgumentException("Describe the other society charge");
        }
        var invoice = new MaintenanceInvoice();
        invoice.setSocietyId(societyId);
        invoice.setFlatId(flatId);
        invoice.setInvoiceNumber(
                invoiceNumber == null || invoiceNumber.isBlank()
                        ? automaticInvoiceNumber(flatId, billingMonth)
                        : invoiceNumber.trim().toUpperCase());
        invoice.setBillingMonth(billingMonth.withDayOfMonth(1));
        invoice.setDueDate(dueDate);
        invoice.setSubtotal(subtotal);
        invoice.setMembershipFee(membership);
        invoice.setOtherCharges(other);
        invoice.setOtherChargeNote(
                otherChargeNote == null || otherChargeNote.isBlank()
                        ? null
                        : otherChargeNote.trim());
        invoice.setLateFee(BigDecimal.ZERO);
        invoice.setPaidAmount(BigDecimal.ZERO);
        invoice.setStatus(PaymentStatus.DUE.code());
        invoice.setCreatedAt(OffsetDateTime.now());
        invoice = invoices.save(invoice);
        return Map.of(
                "id", invoice.getId(),
                "invoiceNumber", invoice.getInvoiceNumber(),
                "status", invoice.getStatus());
    }

    public Map<String, Object> pay(
            UUID societyId,
            UUID actorId,
            String role,
            UUID invoiceId,
            BigDecimal amount,
            String method,
            String providerReference,
            String note) {
        requireRoleAccess(actorId, role);
        if (UserRole.RESIDENT.matches(role)) {
            throw new AuthorizationException("Members must use Razorpay online checkout");
        }
        var requestedMethod = PaymentMethod.from(method);
        if (!OFFICE_METHODS.contains(requestedMethod)) {
            throw new IllegalArgumentException("Invalid office payment method");
        }
        return recordPayment(
                societyId,
                actorId,
                role,
                invoiceId,
                amount,
                requestedMethod.code(),
                officeChannel(requestedMethod),
                normalizeReference(requestedMethod, providerReference),
                note);
    }

    public Map<String, Object> checkout(
            UUID societyId,
            UUID actorId,
            String role,
            UUID invoiceId,
            BigDecimal amount,
            String method) {
        requireRoleAccess(actorId, role);
        var requestedMethod = PaymentMethod.from(method);
        if (!ONLINE_METHODS.contains(requestedMethod)) {
            throw new IllegalArgumentException("Invalid Razorpay payment method");
        }
        var setting =
                paymentSettings
                        .findBySocietyId(societyId)
                        .orElseThrow(
                                () ->
                                        new IllegalStateException(
                                                "Society online payment account is not configured"));
        if (setting.getRazorpayKeyId() == null || setting.getRazorpayKeyId().isBlank()) {
            throw new IllegalStateException("Society Razorpay account is not configured");
        }
        String reference =
                (setting.isTestMode() ? "pay_soc_test_" : "pay_soc_")
                        + UUID.randomUUID().toString().replace("-", "").substring(0, 20);
        return recordPayment(
                societyId,
                actorId,
                role,
                invoiceId,
                amount,
                requestedMethod.razorpayCode(),
                PaymentChannel.ONLINE.code(),
                reference,
                setting.isTestMode() ? "Razorpay test-mode society collection" : null);
    }

    public Map<String, Object> updatePaymentSettings(
            UUID societyId,
            UUID actorId,
            String beneficiaryName,
            String bankName,
            String accountNumber,
            String ifscCode,
            String upiId,
            String razorpayKeyId,
            boolean testMode) {
        if (!testMode) {
            throw new IllegalArgumentException(
                    "Live Razorpay is not enabled yet. Keep the society account in test mode.");
        }
        var setting =
                paymentSettings
                        .findBySocietyId(societyId)
                        .orElseGet(
                                () -> {
                                    var created = new SocietyPaymentSetting();
                                    created.setSocietyId(societyId);
                                    return created;
                                });
        setting.setBeneficiaryName(beneficiaryName.trim());
        setting.setBankName(blankToNull(bankName));
        setting.setAccountNumber(blankToNull(accountNumber));
        setting.setIfscCode(
                ifscCode == null || ifscCode.isBlank() ? null : ifscCode.trim().toUpperCase());
        setting.setUpiId(blankToNull(upiId));
        setting.setRazorpayKeyId(razorpayKeyId.trim());
        setting.setTestMode(true);
        setting.setUpdatedBy(actorId);
        setting.setUpdatedAt(OffsetDateTime.now());
        return paymentSettingView(paymentSettings.save(setting), true);
    }

    private Map<String, Object> recordPayment(
            UUID societyId,
            UUID actorId,
            String role,
            UUID invoiceId,
            BigDecimal amount,
            String method,
            String channel,
            String reference,
            String note) {
        var invoice =
                invoices.findForUpdateByIdAndSocietyId(invoiceId, societyId)
                        .filter(item -> canViewInvoice(item, actorId, role))
                        .orElseThrow(() -> new ResourceNotFoundException("Invoice not found"));
        var total = invoice.getSubtotal().add(invoice.getLateFee());
        var outstanding = total.subtract(invoice.getPaidAmount());
        if (outstanding.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalStateException("Invoice is already paid");
        }
        if (amount.compareTo(outstanding) > 0) {
            throw new IllegalArgumentException("Payment exceeds outstanding amount");
        }
        var payment = new Payment();
        payment.setSocietyId(societyId);
        payment.setInvoiceId(invoiceId);
        payment.setPaidBy(
                UserRole.RESIDENT.matches(role)
                        ? actorId
                        : residentForFlat(invoice.getFlatId()).orElse(actorId));
        payment.setRecordedBy(actorId);
        payment.setAmount(amount);
        payment.setPaymentMethod(method);
        payment.setPaymentChannel(channel);
        payment.setProviderReference(reference);
        payment.setReceiptNumber(receiptNumber());
        payment.setNote(note == null || note.isBlank() ? null : note.trim());
        payment.setStatus(PaymentStatus.SUCCESS.code());
        payment.setPaidAt(OffsetDateTime.now());
        payment = payments.save(payment);

        var paid = invoice.getPaidAmount().add(amount);
        String status =
                paid.compareTo(total) == 0
                        ? PaymentStatus.PAID.code()
                        : PaymentStatus.PART_PAID.code();
        invoice.setPaidAmount(paid);
        invoice.setStatus(status);
        invoices.save(invoice);
        return Map.of(
                "paymentId",
                payment.getId(),
                "receiptNumber",
                payment.getReceiptNumber(),
                "invoiceStatus",
                status,
                "paidAmount",
                paid);
    }

    public Map<String, Object> receipt(UUID societyId, UUID userId, String role, UUID paymentId) {
        requireRoleAccess(userId, role);
        var payment =
                payments.findByIdAndSocietyId(paymentId, societyId)
                        .orElseThrow(() -> new ResourceNotFoundException("Receipt not found"));
        var invoice = requireInvoice(societyId, userId, role, payment.getInvoiceId());
        var result = new LinkedHashMap<String, Object>(paymentView(payment));
        result.put(
                "society_name",
                societies.findById(societyId).map(Society::getName).orElse("Society"));
        result.put(
                "society_registration",
                societies.findById(societyId).map(Society::getRegistrationNumber).orElse(null));
        result.put("billing_month", invoice.getBillingMonth());
        result.put("due_date", invoice.getDueDate());
        result.put("membership_fee", invoice.getMembershipFee());
        result.put("other_charges", invoice.getOtherCharges());
        result.put("other_charge_note", invoice.getOtherChargeNote());
        result.put("invoice_total", invoice.getSubtotal().add(invoice.getLateFee()));
        result.put("invoice_paid_amount", invoice.getPaidAmount());
        result.put("invoice_status", invoice.getStatus());
        result.put(
                "payer_name",
                users.findById(payment.getPaidBy())
                        .map(UserAccount::getFullName)
                        .orElse("Resident"));
        result.put(
                "recorded_by_name",
                users.findById(payment.getRecordedBy())
                        .map(UserAccount::getFullName)
                        .orElse("System"));
        return result;
    }

    public byte[] receiptPdf(UUID societyId, UUID userId, String role, UUID paymentId) {
        return receiptRenderer.render(receipt(societyId, userId, role, paymentId));
    }

    private MaintenanceInvoice requireInvoice(
            UUID societyId, UUID userId, String role, UUID invoiceId) {
        requireRoleAccess(userId, role);
        return invoices.findByIdAndSocietyId(invoiceId, societyId)
                .filter(invoice -> canViewInvoice(invoice, userId, role))
                .orElseThrow(() -> new ResourceNotFoundException("Invoice not found"));
    }

    private boolean canViewInvoice(MaintenanceInvoice invoice, UUID userId, String role) {
        return !UserRole.RESIDENT.matches(role) || access.occupiedBy(invoice.getFlatId(), userId);
    }

    private void requireRoleAccess(UUID userId, String role) {
        if (UserRole.STAFF.matches(role)
                && !permissions.existsByStaffUserIdAndPermissionCode(
                        userId, StaffPermissionCode.PAYMENTS.code())) {
            throw new AuthorizationException("Payments permission is required");
        }
    }

    private String automaticInvoiceNumber(UUID flatId, LocalDate billingMonth) {
        String space =
                flats.findById(flatId)
                        .map(Flat::getFlatNumber)
                        .orElse("SPACE")
                        .replaceAll("[^A-Za-z0-9]", "")
                        .toUpperCase();
        return "INV-"
                + billingMonth.format(DateTimeFormatter.ofPattern("yyyyMM"))
                + "-"
                + space
                + "-"
                + UUID.randomUUID().toString().substring(0, 4).toUpperCase();
    }

    private String receiptNumber() {
        return "RCT-"
                + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMM"))
                + "-"
                + UUID.randomUUID().toString().replace("-", "").substring(0, 12).toUpperCase();
    }

    private String officeChannel(PaymentMethod method) {
        return Set.of(PaymentMethod.UPI, PaymentMethod.CARD).contains(method)
                ? PaymentChannel.ONLINE.code()
                : PaymentChannel.OFFLINE.code();
    }

    private String normalizeReference(PaymentMethod method, String reference) {
        if (reference != null && !reference.isBlank()) return reference.trim().toUpperCase();
        if (Set.of(PaymentMethod.CHEQUE, PaymentMethod.BANK_TRANSFER).contains(method)) {
            throw new IllegalArgumentException("Transaction or cheque reference is required");
        }
        return method
                + "-"
                + UUID.randomUUID().toString().replace("-", "").substring(0, 12).toUpperCase();
    }

    private Map<String, Object> paymentSettingView(
            SocietyPaymentSetting setting, boolean includePrivate) {
        var map = new LinkedHashMap<String, Object>();
        map.put("beneficiary_name", setting.getBeneficiaryName());
        map.put("bank_name", setting.getBankName());
        map.put("account_number_masked", maskAccount(setting.getAccountNumber()));
        map.put("upi_id", setting.getUpiId());
        map.put("razorpay_key_id", setting.getRazorpayKeyId());
        map.put("test_mode", setting.isTestMode());
        map.put(
                "configured",
                setting.getRazorpayKeyId() != null && !setting.getRazorpayKeyId().isBlank());
        map.put("updated_at", setting.getUpdatedAt());
        if (includePrivate) {
            map.put("account_number", setting.getAccountNumber());
            map.put("ifsc_code", setting.getIfscCode());
        }
        return map;
    }

    private String maskAccount(String account) {
        if (account == null || account.isBlank()) return null;
        String clean = account.trim();
        return clean.length() <= 4 ? clean : "XXXX" + clean.substring(clean.length() - 4);
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private Optional<UUID> residentForFlat(UUID flatId) {
        return flats.findById(flatId)
                .map(
                        flat ->
                                flat.getActiveTenantId() != null
                                        ? flat.getActiveTenantId()
                                        : flat.getActiveOwnerId());
    }

    private Map<String, Object> invoiceView(MaintenanceInvoice invoice) {
        var map = new LinkedHashMap<String, Object>();
        BigDecimal total = invoice.getSubtotal().add(invoice.getLateFee());
        map.put("id", invoice.getId());
        map.put("society_id", invoice.getSocietyId());
        map.put("space_id", invoice.getFlatId());
        map.put("unit_id", invoice.getFlatId());
        map.put("flat_id", invoice.getFlatId());
        map.put("invoice_number", invoice.getInvoiceNumber());
        map.put("billing_month", invoice.getBillingMonth());
        map.put("due_date", invoice.getDueDate());
        map.put("subtotal", invoice.getSubtotal());
        map.put("membership_fee", invoice.getMembershipFee());
        map.put("other_charges", invoice.getOtherCharges());
        map.put("other_charge_note", invoice.getOtherChargeNote());
        map.put("late_fee", invoice.getLateFee());
        map.put("total", total);
        map.put("paid_amount", invoice.getPaidAmount());
        map.put("outstanding", total.subtract(invoice.getPaidAmount()));
        map.put("status", invoice.getStatus());
        map.put(
                "overdue",
                !PaymentStatus.PAID.matches(invoice.getStatus())
                        && invoice.getDueDate().isBefore(LocalDate.now()));
        map.put("created_at", invoice.getCreatedAt());
        map.put("payment_count", payments.findByInvoiceIdOrderByPaidAtDesc(invoice.getId()).size());
        map.putAll(spaceView(invoice.getFlatId()));
        return map;
    }

    private Map<String, Object> paymentView(Payment payment) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", payment.getId());
        map.put("invoice_id", payment.getInvoiceId());
        map.put("amount", payment.getAmount());
        map.put("payment_method", payment.getPaymentMethod());
        map.put("payment_channel", payment.getPaymentChannel());
        map.put("provider_reference", payment.getProviderReference());
        map.put("receipt_number", payment.getReceiptNumber());
        map.put("note", payment.getNote());
        map.put("status", payment.getStatus());
        map.put("paid_at", payment.getPaidAt());
        map.put("paid_by", payment.getPaidBy());
        map.put("recorded_by", payment.getRecordedBy());
        invoices.findById(payment.getInvoiceId())
                .ifPresent(
                        invoice -> {
                            map.put("invoice_number", invoice.getInvoiceNumber());
                            map.putAll(spaceView(invoice.getFlatId()));
                        });
        map.put(
                "payer_name",
                users.findById(payment.getPaidBy())
                        .map(UserAccount::getFullName)
                        .orElse("Resident"));
        map.put(
                "recorded_by_name",
                users.findById(payment.getRecordedBy())
                        .map(UserAccount::getFullName)
                        .orElse("System"));
        return map;
    }

    private Map<String, Object> spaceView(UUID flatId) {
        return flats.findById(flatId).map(this::spaceView).orElseGet(LinkedHashMap::new);
    }

    private Map<String, Object> spaceView(Flat flat) {
        var map = new LinkedHashMap<String, Object>();
        map.put("space_id", flat.getId());
        map.put("space_number", flat.getFlatNumber());
        UUID residentId =
                flat.getActiveTenantId() != null
                        ? flat.getActiveTenantId()
                        : flat.getActiveOwnerId();
        map.put("resident_id", residentId);
        if (residentId != null) {
            users.findById(residentId)
                    .ifPresent(
                            resident -> {
                                map.put("resident_name", resident.getFullName());
                                map.put("resident_mobile", resident.getMobile());
                            });
        }
        floors.findById(flat.getFloorId())
                .flatMap(floor -> blocks.findById(floor.getBlockId()))
                .ifPresent(block -> map.put("block", block.getName()));
        return map;
    }
}
