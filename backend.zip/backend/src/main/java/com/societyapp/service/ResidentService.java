package com.societyapp.service;

import com.societyapp.application.mapper.ApiViewMapper;
import com.societyapp.application.port.in.ResidentUseCase;
import com.societyapp.application.port.in.StructureAccessUseCase;
import com.societyapp.application.port.out.PasswordCodec;
import com.societyapp.domain.type.AccountStatus;
import com.societyapp.domain.type.ApprovalAction;
import com.societyapp.domain.type.FlatOccupancyStatus;
import com.societyapp.domain.type.RegistrationStatus;
import com.societyapp.domain.type.ResidentType;
import com.societyapp.domain.type.UserRole;
import com.societyapp.domain.type.VerificationStatus;
import com.societyapp.entity.*;
import com.societyapp.repository.*;
import java.time.*;
import java.util.*;

public class ResidentService implements ResidentUseCase {
    private final ResidentRegistrationRepository registrations;
    private final UserAccountJpaRepository users;
    private final FlatRepository flats;
    private final FloorRepository floors;
    private final BlockRepository blocks;
    private final ComplaintRepository complaints;
    private final MaintenanceInvoiceRepository invoices;
    private final PaymentRepository payments;
    private final VisitorRepository visitors;
    private final HouseholdMemberRepository householdMembers;
    private final AmenityBookingRepository amenityBookings;
    private final AmenityRepository amenities;
    private final StructureAccessUseCase access;
    private final PasswordCodec passwords;
    private final ApiViewMapper views;

    public ResidentService(
            ResidentRegistrationRepository registrations,
            UserAccountJpaRepository users,
            FlatRepository flats,
            FloorRepository floors,
            BlockRepository blocks,
            ComplaintRepository complaints,
            MaintenanceInvoiceRepository invoices,
            PaymentRepository payments,
            VisitorRepository visitors,
            HouseholdMemberRepository householdMembers,
            AmenityBookingRepository amenityBookings,
            AmenityRepository amenities,
            StructureAccessUseCase access,
            PasswordCodec passwords,
            ApiViewMapper views) {
        this.registrations = registrations;
        this.users = users;
        this.flats = flats;
        this.floors = floors;
        this.blocks = blocks;
        this.complaints = complaints;
        this.invoices = invoices;
        this.payments = payments;
        this.visitors = visitors;
        this.householdMembers = householdMembers;
        this.amenityBookings = amenityBookings;
        this.amenities = amenities;
        this.access = access;
        this.passwords = passwords;
        this.views = views;
    }

    public List<Map<String, Object>> flats(UUID societyId) {
        var result = new ArrayList<Map<String, Object>>();
        for (var block : blocks.findBySocietyIdOrderByName(societyId)) {
            for (var floor : floors.findByBlockIdOrderByFloorNumber(block.getId())) {
                for (var flat : flats.findByFloorIdOrderByFlatNumber(floor.getId())) {
                    var view = new LinkedHashMap<String, Object>();
                    view.put("id", flat.getId());
                    view.put("block", block.getName());
                    view.put("section", floor.getName());
                    view.put("floor", floor.getName());
                    view.put("space_number", flat.getFlatNumber());
                    view.put("unit_number", flat.getFlatNumber());
                    view.put("flat_number", flat.getFlatNumber());
                    view.put("occupancy_status", flat.getOccupancyStatus());
                    result.add(view);
                }
            }
        }
        return result;
    }

    public Map<String, Object> register(
            UUID societyId,
            UUID flatId,
            String type,
            String fullName,
            String mobile,
            String email,
            LocalDate dob,
            String gender,
            String emergency,
            LocalDate moveIn,
            LocalDate moveOut) {
        if (!access.belongsToSociety(flatId, societyId)) {
            throw new IllegalArgumentException("Space does not belong to society");
        }
        if (moveIn != null && moveOut != null && !moveOut.isAfter(moveIn)) {
            throw new IllegalArgumentException("Move-out must be after move-in");
        }
        var registration = new ResidentRegistration();
        registration.setSocietyId(societyId);
        registration.setFlatId(flatId);
        registration.setResidentType(ResidentType.from(type).code());
        registration.setFullName(fullName);
        registration.setMobile(mobile);
        registration.setEmail(email);
        registration.setDob(dob);
        registration.setGender(gender);
        registration.setEmergencyContact(emergency);
        registration.setMoveInDate(moveIn);
        registration.setMoveOutDate(moveOut);
        registration.setStatus(RegistrationStatus.PENDING_APPROVAL.code());
        registration.setInvited(false);
        registration.setSubmittedAt(OffsetDateTime.now());
        registration = registrations.save(registration);
        return Map.of("registrationId", registration.getId(), "status", registration.getStatus());
    }

    public List<Map<String, Object>> pending(UUID societyId) {
        return registrations
                .findBySocietyIdAndStatusOrderBySubmittedAtDesc(
                        societyId, RegistrationStatus.PENDING_APPROVAL.code())
                .stream()
                .map(this::registrationView)
                .toList();
    }

    public List<Map<String, Object>> residents(UUID societyId) {
        return users
                .findBySocietyIdAndRoleOrderByFullName(societyId, UserRole.RESIDENT.code())
                .stream()
                .map(this::residentView)
                .toList();
    }

    public Map<String, Object> createResident(
            UUID societyId,
            UUID reviewerId,
            UUID flatId,
            String type,
            String fullName,
            String mobile,
            String email,
            LocalDate dob,
            String gender,
            String emergency,
            LocalDate moveIn,
            LocalDate moveOut,
            String temporaryPassword) {
        if (users.findByEmailIgnoreCase(email.trim()).isPresent()) {
            throw new IllegalStateException("A user with this email already exists");
        }
        var registration =
                register(
                        societyId,
                        flatId,
                        type,
                        fullName.trim(),
                        mobile.trim(),
                        email.trim().toLowerCase(Locale.ROOT),
                        dob,
                        gender,
                        emergency,
                        moveIn,
                        moveOut);
        var registrationId = (UUID) registration.get("registrationId");
        var result =
                new LinkedHashMap<String, Object>(
                        review(
                                societyId,
                                reviewerId,
                                registrationId,
                                ApprovalAction.APPROVE.code(),
                                null,
                                temporaryPassword));
        result.put("registrationId", registrationId);
        return result;
    }

    public Map<String, Object> resident(UUID societyId, UUID residentId) {
        var user = requireResident(societyId, residentId);
        var flat =
                flats.findAll().stream()
                        .filter(
                                item ->
                                        residentId.equals(item.getActiveOwnerId())
                                                || residentId.equals(item.getActiveTenantId()))
                        .findFirst()
                        .orElseThrow(
                                () -> new IllegalStateException("Resident has no active space"));
        var invoiceList =
                invoices.findBySocietyIdAndFlatIdOrderByBillingMonthDesc(societyId, flat.getId());
        var invoiceIds = invoiceList.stream().map(MaintenanceInvoice::getId).toList();
        var registration =
                registrations.findBySocietyIdOrderBySubmittedAtDesc(societyId).stream()
                        .filter(item -> flat.getId().equals(item.getFlatId()))
                        .filter(item -> user.getEmail().equalsIgnoreCase(item.getEmail()))
                        .findFirst()
                        .map(views::toMap)
                        .orElseGet(LinkedHashMap::new);
        var result = new LinkedHashMap<String, Object>();
        result.put("resident", residentView(user));
        result.put("registration", registration);
        result.put("space", spaceView(flat));
        result.put(
                "household",
                householdMembers
                        .findBySocietyIdAndPrimaryResidentIdAndActiveTrue(societyId, residentId)
                        .stream()
                        .map(this::householdView)
                        .toList());
        result.put(
                "complaints",
                complaints
                        .findBySocietyIdAndRaisedByOrderByCreatedAtDesc(societyId, residentId)
                        .stream()
                        .map(this::complaintView)
                        .toList());
        result.put("invoices", invoiceList.stream().map(this::invoiceView).toList());
        result.put(
                "payments",
                invoiceIds.isEmpty()
                        ? List.of()
                        : payments
                                .findBySocietyIdAndInvoiceIdInOrderByPaidAtDesc(
                                        societyId, invoiceIds)
                                .stream()
                                .map(this::paymentView)
                                .toList());
        result.put(
                "visitors",
                visitors
                        .findBySocietyIdAndFlatIdOrderByCreatedAtDesc(societyId, flat.getId())
                        .stream()
                        .map(this::visitorView)
                        .toList());
        result.put(
                "amenityBookings",
                amenityBookings
                        .findBySocietyIdAndBookedByOrderByStartsAtDesc(societyId, residentId)
                        .stream()
                        .map(this::bookingView)
                        .toList());
        return result;
    }

    public Map<String, Object> addHouseholdMember(
            UUID societyId,
            UUID residentId,
            String fullName,
            String relationship,
            String mobile,
            LocalDate dateOfBirth) {
        requireResident(societyId, residentId);
        var member = new HouseholdMember();
        member.setSocietyId(societyId);
        member.setPrimaryResidentId(residentId);
        member.setMemberCode(
                "HM-"
                        + UUID.randomUUID()
                                .toString()
                                .replace("-", "")
                                .substring(0, 10)
                                .toUpperCase(Locale.ROOT));
        member.setFullName(fullName);
        member.setRelationship(relationship);
        member.setMobile(mobile);
        member.setDateOfBirth(dateOfBirth);
        member.setAccessEnabled(false);
        member.setVerificationStatus(VerificationStatus.PENDING.code());
        member.setActive(true);
        member.setCreatedAt(OffsetDateTime.now());
        member.setUpdatedAt(OffsetDateTime.now());
        return Map.of("id", householdMembers.save(member).getId());
    }

    public Map<String, Object> removeHouseholdMember(
            UUID societyId, UUID residentId, UUID memberId) {
        requireResident(societyId, residentId);
        var member =
                householdMembers
                        .findByIdAndSocietyIdAndPrimaryResidentId(memberId, societyId, residentId)
                        .orElseThrow(
                                () -> new IllegalArgumentException("Household member not found"));
        member.setActive(false);
        householdMembers.save(member);
        return Map.of("id", memberId, "active", false);
    }

    public Map<String, Object> review(
            UUID societyId,
            UUID reviewerId,
            UUID registrationId,
            String decision,
            String reason,
            String temporaryPassword) {
        var registration =
                registrations
                        .findByIdAndSocietyId(registrationId, societyId)
                        .filter(
                                item ->
                                        RegistrationStatus.PENDING_APPROVAL.matches(
                                                item.getStatus()))
                        .orElseThrow(
                                () -> new IllegalStateException("Registration is not pending"));
        if (ApprovalAction.from(decision) == ApprovalAction.REJECT) {
            if (reason == null || reason.isBlank()) {
                throw new IllegalArgumentException("Rejection reason is required");
            }
            registration.setStatus(RegistrationStatus.REJECTED.code());
            registration.setRejectionReason(reason);
            registration.setReviewedBy(reviewerId);
            registration.setReviewedAt(OffsetDateTime.now());
            registrations.save(registration);
            return Map.of("status", RegistrationStatus.REJECTED.code());
        }
        if (temporaryPassword == null) {
            throw new IllegalArgumentException("Temporary password is required for approval");
        }
        var flat = flats.findById(registration.getFlatId()).orElseThrow();
        boolean owner = ResidentType.OWNER.matches(registration.getResidentType());
        if ((owner && flat.getActiveOwnerId() != null)
                || (!owner && flat.getActiveTenantId() != null)) {
            throw new IllegalStateException(
                    "Space already has an active " + registration.getResidentType().toLowerCase());
        }
        var user = new UserAccount();
        user.setSocietyId(societyId);
        user.setFullName(registration.getFullName());
        user.setEmail(registration.getEmail());
        user.setMobile(registration.getMobile());
        user.setPasswordHash(passwords.encode(temporaryPassword));
        user.setRole(UserRole.RESIDENT.code());
        user.setStatus(AccountStatus.ACTIVE.code());
        user.setCreatedAt(OffsetDateTime.now());
        user = users.save(user);
        if (owner) {
            flat.setActiveOwnerId(user.getId());
            flat.setOccupancyStatus(FlatOccupancyStatus.OWNER_OCCUPIED.code());
        } else {
            flat.setActiveTenantId(user.getId());
            flat.setOccupancyStatus(FlatOccupancyStatus.TENANT_OCCUPIED.code());
        }
        flats.save(flat);
        registration.setStatus(RegistrationStatus.ACTIVE.code());
        registration.setReviewedBy(reviewerId);
        registration.setReviewedAt(OffsetDateTime.now());
        registrations.save(registration);
        return Map.of("status", RegistrationStatus.ACTIVE.code(), "userId", user.getId());
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> registrationView(ResidentRegistration registration) {
        var map = new LinkedHashMap<String, Object>(views.toMap(registration));
        flats.findById(registration.getFlatId())
                .ifPresent(
                        flat -> {
                            map.put("space_number", flat.getFlatNumber());
                            map.put("unit_number", flat.getFlatNumber());
                            map.put("flat_number", flat.getFlatNumber());
                            floors.findById(flat.getFloorId())
                                    .flatMap(floor -> blocks.findById(floor.getBlockId()))
                                    .ifPresent(block -> map.put("block", block.getName()));
                        });
        return map;
    }

    private Map<String, Object> residentView(UserAccount user) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", user.getId());
        map.put("full_name", user.getFullName());
        map.put("email", user.getEmail());
        map.put("mobile", user.getMobile());
        map.put("status", user.getStatus());
        flats.findAll().stream()
                .filter(
                        flat ->
                                user.getId().equals(flat.getActiveOwnerId())
                                        || user.getId().equals(flat.getActiveTenantId()))
                .findFirst()
                .ifPresent(
                        flat -> {
                            map.put("space_number", flat.getFlatNumber());
                            map.put("unit_number", flat.getFlatNumber());
                            map.put("flat_number", flat.getFlatNumber());
                            map.put(
                                    "resident_type",
                                    user.getId().equals(flat.getActiveOwnerId())
                                            ? ResidentType.OWNER.code()
                                            : ResidentType.TENANT.code());
                            floors.findById(flat.getFloorId())
                                    .flatMap(floor -> blocks.findById(floor.getBlockId()))
                                    .ifPresent(block -> map.put("block", block.getName()));
                        });
        return map;
    }

    private UserAccount requireResident(UUID societyId, UUID residentId) {
        return users.findById(residentId)
                .filter(user -> societyId.equals(user.getSocietyId()))
                .filter(user -> UserRole.RESIDENT.matches(user.getRole()))
                .orElseThrow(() -> new IllegalArgumentException("Resident not found"));
    }

    private Map<String, Object> spaceView(Flat flat) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", flat.getId());
        map.put("space_number", flat.getFlatNumber());
        map.put("occupancy_status", flat.getOccupancyStatus());
        map.put("area_sqft", flat.getAreaSqft());
        floors.findById(flat.getFloorId())
                .ifPresent(
                        floor -> {
                            map.put("section", floor.getName());
                            blocks.findById(floor.getBlockId())
                                    .ifPresent(block -> map.put("block", block.getName()));
                        });
        return map;
    }

    private Map<String, Object> householdView(HouseholdMember member) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", member.getId());
        map.put("full_name", member.getFullName());
        map.put("relationship", member.getRelationship());
        map.put("mobile", member.getMobile());
        map.put("date_of_birth", member.getDateOfBirth());
        return map;
    }

    private Map<String, Object> complaintView(Complaint complaint) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", complaint.getId());
        map.put("title", complaint.getTitle());
        map.put("description", complaint.getDescription());
        map.put("priority", complaint.getPriority());
        map.put("status", complaint.getStatus());
        map.put("resolution", complaint.getResolution());
        map.put("created_at", complaint.getCreatedAt());
        return map;
    }

    private Map<String, Object> invoiceView(MaintenanceInvoice invoice) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", invoice.getId());
        map.put("invoice_number", invoice.getInvoiceNumber());
        map.put("billing_month", invoice.getBillingMonth());
        map.put("due_date", invoice.getDueDate());
        map.put("subtotal", invoice.getSubtotal());
        map.put("late_fee", invoice.getLateFee());
        map.put("paid_amount", invoice.getPaidAmount());
        map.put("status", invoice.getStatus());
        return map;
    }

    private Map<String, Object> paymentView(Payment payment) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", payment.getId());
        map.put("invoice_id", payment.getInvoiceId());
        map.put("amount", payment.getAmount());
        map.put("payment_method", payment.getPaymentMethod());
        map.put("provider_reference", payment.getProviderReference());
        map.put("status", payment.getStatus());
        map.put("paid_at", payment.getPaidAt());
        return map;
    }

    private Map<String, Object> visitorView(Visitor visitor) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", visitor.getId());
        map.put("visitor_name", visitor.getVisitorName());
        map.put("mobile", visitor.getMobile());
        map.put("purpose", visitor.getPurpose());
        map.put("vehicle_number", visitor.getVehicleNumber());
        map.put("expected_at", visitor.getExpectedAt());
        map.put("status", visitor.getStatus());
        return map;
    }

    private Map<String, Object> bookingView(AmenityBooking booking) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", booking.getId());
        map.put("amenity_id", booking.getAmenityId());
        map.put(
                "amenity_name",
                amenities.findById(booking.getAmenityId()).map(Amenity::getName).orElse("Amenity"));
        map.put("starts_at", booking.getStartsAt());
        map.put("ends_at", booking.getEndsAt());
        map.put("amount", booking.getAmount());
        map.put("status", booking.getStatus());
        return map;
    }
}
