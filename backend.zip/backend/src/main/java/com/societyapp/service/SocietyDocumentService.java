package com.societyapp.service;

import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.port.in.SocietyDocumentUseCase;
import com.societyapp.application.port.out.DocumentStorage;
import com.societyapp.application.port.out.PasswordCodec;
import com.societyapp.application.port.out.UploadedFile;
import com.societyapp.domain.type.VerificationStatus;
import com.societyapp.entity.SocietyDocument;
import com.societyapp.repository.*;
import java.util.*;

public class SocietyDocumentService implements SocietyDocumentUseCase {
    private final SocietyRepository societies;
    private final SocietyDocumentRepository documents;
    private final DocumentStorage storage;
    private final PasswordCodec passwords;

    public SocietyDocumentService(
            SocietyRepository societies,
            SocietyDocumentRepository documents,
            DocumentStorage storage,
            PasswordCodec passwords) {
        this.societies = societies;
        this.documents = documents;
        this.storage = storage;
        this.passwords = passwords;
    }

    public Map<String, Object> upload(
            UUID societyId, String token, String type, UploadedFile file) {
        var society =
                societies
                        .findById(societyId)
                        .orElseThrow(() -> new ResourceNotFoundException("Society not found"));
        if (society.getRegistrationAccessHash() == null
                || !passwords.matches(token, society.getRegistrationAccessHash())) {
            throw new IllegalArgumentException("Invalid registration token");
        }
        var document = new SocietyDocument();
        document.setSocietyId(societyId);
        document.setDocumentType(type);
        document.setStorageKey(storage.store(societyId, file));
        document.setVerificationStatus(VerificationStatus.PENDING.code());
        document = documents.save(document);
        storage.attach(
                document.getStorageKey(), "SOCIETY_DOCUMENT", document.getId(), type + " document");
        return Map.of(
                "documentId",
                document.getId(),
                "documentType",
                type,
                "status",
                VerificationStatus.PENDING.code());
    }

    public Map<String, Object> uploadAuthenticated(UUID societyId, String type, UploadedFile file) {
        if (!societies.existsById(societyId)) {
            throw new ResourceNotFoundException("Society not found");
        }
        var document = new SocietyDocument();
        document.setSocietyId(societyId);
        document.setDocumentType(type);
        document.setStorageKey(storage.store(societyId, file));
        document.setVerificationStatus(VerificationStatus.PENDING.code());
        document = documents.save(document);
        storage.attach(
                document.getStorageKey(), "SOCIETY_DOCUMENT", document.getId(), type + " document");
        return Map.of(
                "documentId",
                document.getId(),
                "documentType",
                type,
                "status",
                VerificationStatus.PENDING.code());
    }

    public List<Map<String, Object>> list(UUID societyId) {
        return documents.findBySocietyId(societyId).stream()
                .sorted(Comparator.comparing(SocietyDocument::getDocumentType))
                .map(
                        document ->
                                Map.<String, Object>of(
                                        "id", document.getId(),
                                        "document_type", document.getDocumentType(),
                                        "storage_key", document.getStorageKey(),
                                        "verification_status", document.getVerificationStatus()))
                .toList();
    }

    public Map<String, Object> verify(UUID societyId, UUID documentId, String status) {
        var requestedStatus = VerificationStatus.from(status);
        if (requestedStatus == VerificationStatus.PENDING) {
            throw new IllegalArgumentException("Status must be VERIFIED or REJECTED");
        }
        var document =
                documents
                        .findByIdAndSocietyId(documentId, societyId)
                        .orElseThrow(() -> new ResourceNotFoundException("Document not found"));
        document.setVerificationStatus(requestedStatus.code());
        documents.save(document);
        return Map.of("documentId", documentId, "status", requestedStatus.code());
    }
}
