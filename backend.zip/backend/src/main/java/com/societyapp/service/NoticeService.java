package com.societyapp.service;

import com.societyapp.application.exception.AuthorizationException;
import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.port.in.NoticeUseCase;
import com.societyapp.domain.type.NoticeAudience;
import com.societyapp.domain.type.NoticePriority;
import com.societyapp.domain.type.NoticeStatus;
import com.societyapp.domain.type.StaffPermissionCode;
import com.societyapp.domain.type.UserRole;
import com.societyapp.entity.*;
import com.societyapp.repository.*;
import java.time.OffsetDateTime;
import java.util.*;

public class NoticeService implements NoticeUseCase {
    private final NoticeRepository notices;
    private final NoticeReadRepository reads;
    private final UserAccountJpaRepository users;
    private final StaffPermissionRepository permissions;

    public NoticeService(
            NoticeRepository notices,
            NoticeReadRepository reads,
            UserAccountJpaRepository users,
            StaffPermissionRepository permissions) {
        this.notices = notices;
        this.reads = reads;
        this.users = users;
        this.permissions = permissions;
    }

    public List<Map<String, Object>> list(UUID societyId, UUID userId, String role) {
        boolean manager = canManage(userId, role);
        var now = OffsetDateTime.now();
        return notices.findBySocietyIdOrderByPublishedAtDesc(societyId).stream()
                .filter(
                        notice ->
                                manager
                                        || (NoticeStatus.PUBLISHED.matches(notice.getStatus())
                                                && (notice.getExpiresAt() == null
                                                        || notice.getExpiresAt().isAfter(now))
                                                && visibleTo(notice.getAudience(), role)))
                .sorted(
                        Comparator.comparing(Notice::isPinned)
                                .reversed()
                                .thenComparing(
                                        notice ->
                                                notice.getPublishedAt() == null
                                                        ? OffsetDateTime.MIN
                                                        : notice.getPublishedAt(),
                                        Comparator.reverseOrder()))
                .map(notice -> view(notice, userId, manager))
                .toList();
    }

    public Map<String, Object> options(UUID userId, String role) {
        return Map.of(
                "can_manage", canManage(userId, role),
                "audiences",
                        Arrays.stream(NoticeAudience.values()).map(NoticeAudience::code).toList(),
                "priorities",
                        Arrays.stream(NoticePriority.values()).map(NoticePriority::code).toList(),
                "statuses", Arrays.stream(NoticeStatus.values()).map(NoticeStatus::code).toList());
    }

    public Map<String, Object> create(
            UUID societyId,
            UUID publisherId,
            String role,
            String title,
            String body,
            String audience,
            String priority,
            boolean pinned,
            boolean requiresAcknowledgement,
            String status,
            OffsetDateTime expiresAt) {
        requireManager(publisherId, role);
        var requestedStatus =
                NoticeStatus.from(status == null ? NoticeStatus.PUBLISHED.code() : status);
        var requestedPriority =
                NoticePriority.from(priority == null ? NoticePriority.NORMAL.code() : priority);
        validate(requestedStatus, expiresAt);
        var now = OffsetDateTime.now();
        var notice = new Notice();
        notice.setSocietyId(societyId);
        notice.setTitle(title.trim());
        notice.setBody(body.trim());
        notice.setAudience(NoticeAudience.from(audience).code());
        notice.setPriority(requestedPriority.code());
        notice.setPinned(pinned);
        notice.setRequiresAcknowledgement(requiresAcknowledgement);
        notice.setStatus(requestedStatus.code());
        notice.setPublishedBy(publisherId);
        notice.setPublishedAt(requestedStatus == NoticeStatus.PUBLISHED ? now : null);
        notice.setExpiresAt(expiresAt);
        notice.setUpdatedAt(now);
        notice = notices.save(notice);
        return Map.of("id", notice.getId(), "status", notice.getStatus());
    }

    public Map<String, Object> update(
            UUID societyId,
            UUID actorId,
            String role,
            UUID noticeId,
            String title,
            String body,
            String audience,
            String priority,
            boolean pinned,
            boolean requiresAcknowledgement,
            String status,
            OffsetDateTime expiresAt) {
        requireManager(actorId, role);
        var notice =
                notices.findById(noticeId)
                        .filter(item -> societyId.equals(item.getSocietyId()))
                        .orElseThrow(() -> new ResourceNotFoundException("Notice not found"));
        var requestedStatus = NoticeStatus.from(status);
        var previousStatus = NoticeStatus.from(notice.getStatus());
        validate(requestedStatus, expiresAt);
        notice.setTitle(title.trim());
        notice.setBody(body.trim());
        notice.setAudience(NoticeAudience.from(audience).code());
        notice.setPriority(NoticePriority.from(priority).code());
        notice.setPinned(pinned);
        notice.setRequiresAcknowledgement(requiresAcknowledgement);
        notice.setStatus(requestedStatus.code());
        notice.setExpiresAt(expiresAt);
        notice.setUpdatedAt(OffsetDateTime.now());
        if (requestedStatus == NoticeStatus.PUBLISHED && previousStatus != NoticeStatus.PUBLISHED) {
            notice.setPublishedAt(OffsetDateTime.now());
        }
        notices.save(notice);
        return Map.of("id", noticeId, "status", requestedStatus.code());
    }

    public Map<String, Object> markRead(UUID societyId, UUID userId, String role, UUID noticeId) {
        requireVisible(societyId, userId, role, noticeId);
        var read =
                reads.findByNoticeIdAndUserId(noticeId, userId)
                        .orElseGet(
                                () -> {
                                    var created = new NoticeRead();
                                    created.setNoticeId(noticeId);
                                    created.setUserId(userId);
                                    created.setReadAt(OffsetDateTime.now());
                                    return created;
                                });
        reads.save(read);
        return Map.of("id", noticeId, "read", true);
    }

    public Map<String, Object> acknowledge(
            UUID societyId, UUID userId, String role, UUID noticeId) {
        var notice = requireVisible(societyId, userId, role, noticeId);
        if (!notice.isRequiresAcknowledgement()) {
            throw new IllegalStateException("This notice does not require acknowledgement");
        }
        var read =
                reads.findByNoticeIdAndUserId(noticeId, userId)
                        .orElseGet(
                                () -> {
                                    var created = new NoticeRead();
                                    created.setNoticeId(noticeId);
                                    created.setUserId(userId);
                                    created.setReadAt(OffsetDateTime.now());
                                    return created;
                                });
        read.setAcknowledgedAt(OffsetDateTime.now());
        reads.save(read);
        return Map.of("id", noticeId, "acknowledged", true);
    }

    private Notice requireVisible(UUID societyId, UUID userId, String role, UUID noticeId) {
        boolean manager = canManage(userId, role);
        var now = OffsetDateTime.now();
        return notices.findById(noticeId)
                .filter(notice -> societyId.equals(notice.getSocietyId()))
                .filter(
                        notice ->
                                manager
                                        || (NoticeStatus.PUBLISHED.matches(notice.getStatus())
                                                && (notice.getExpiresAt() == null
                                                        || notice.getExpiresAt().isAfter(now))
                                                && visibleTo(notice.getAudience(), role)))
                .orElseThrow(() -> new ResourceNotFoundException("Notice not found"));
    }

    private boolean canManage(UUID userId, String role) {
        return UserRole.SOCIETY_ADMIN.matches(role)
                || (UserRole.STAFF.matches(role)
                        && permissions.existsByStaffUserIdAndPermissionCode(
                                userId, StaffPermissionCode.NOTICES.code()));
    }

    private void requireManager(UUID userId, String role) {
        if (!canManage(userId, role)) {
            throw new AuthorizationException("Notices permission is required");
        }
    }

    private void validate(NoticeStatus status, OffsetDateTime expiresAt) {
        if (status == NoticeStatus.PUBLISHED
                && expiresAt != null
                && !expiresAt.isAfter(OffsetDateTime.now())) {
            throw new IllegalArgumentException("Published notice expiry must be in the future");
        }
    }

    private boolean visibleTo(String audience, String role) {
        return UserRole.SOCIETY_ADMIN.matches(role)
                || NoticeAudience.ALL.matches(audience)
                || (UserRole.STAFF.matches(role) && UserRole.STAFF.matches(audience))
                || (UserRole.RESIDENT.matches(role) && NoticeAudience.RESIDENTS.matches(audience));
    }

    private Map<String, Object> view(Notice notice, UUID userId, boolean manager) {
        var read = reads.findByNoticeIdAndUserId(notice.getId(), userId).orElse(null);
        var result = new LinkedHashMap<String, Object>();
        result.put("id", notice.getId());
        result.put("title", notice.getTitle());
        result.put("body", notice.getBody());
        result.put("audience", notice.getAudience());
        result.put("priority", notice.getPriority());
        result.put("pinned", notice.isPinned());
        result.put("requires_acknowledgement", notice.isRequiresAcknowledgement());
        result.put("status", notice.getStatus());
        result.put("published_at", notice.getPublishedAt());
        result.put("expires_at", notice.getExpiresAt());
        result.put("updated_at", notice.getUpdatedAt());
        result.put(
                "expired",
                notice.getExpiresAt() != null
                        && notice.getExpiresAt().isBefore(OffsetDateTime.now()));
        result.put("read", read != null);
        result.put("read_at", read == null ? null : read.getReadAt());
        result.put("acknowledged", read != null && read.getAcknowledgedAt() != null);
        result.put("acknowledged_at", read == null ? null : read.getAcknowledgedAt());
        result.put("published_by", notice.getPublishedBy());
        result.put(
                "published_by_name",
                users.findById(notice.getPublishedBy())
                        .map(UserAccount::getFullName)
                        .orElse("Society Admin"));
        if (manager) {
            result.put("read_count", reads.countByNoticeId(notice.getId()));
            result.put(
                    "acknowledgement_count",
                    reads.countByNoticeIdAndAcknowledgedAtIsNotNull(notice.getId()));
        }
        return result;
    }
}
