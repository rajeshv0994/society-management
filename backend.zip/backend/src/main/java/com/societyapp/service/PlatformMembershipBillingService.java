package com.societyapp.service;

import com.societyapp.application.exception.ConflictException;
import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.port.in.PlatformMembershipBillingUseCase;
import com.societyapp.application.port.in.StorageMeterUseCase;
import com.societyapp.application.port.in.SubscriptionQuantityUseCase;
import com.societyapp.application.port.out.JsonCodec;
import com.societyapp.application.port.out.JsonCodecException;
import com.societyapp.application.port.out.PlatformInvoiceRenderer;
import com.societyapp.application.port.out.RazorpayGateway;
import com.societyapp.domain.type.BillingCycle;
import com.societyapp.domain.type.PaymentAttemptStatus;
import com.societyapp.domain.type.PaymentMethod;
import com.societyapp.domain.type.PaymentProvider;
import com.societyapp.domain.type.PaymentStatus;
import com.societyapp.domain.type.SubscriptionStatus;
import com.societyapp.entity.*;
import com.societyapp.repository.*;
import java.math.BigDecimal;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class PlatformMembershipBillingService implements PlatformMembershipBillingUseCase {
    private static final Set<PaymentMethod> METHODS =
            Set.of(
                    PaymentMethod.BANK_TRANSFER,
                    PaymentMethod.UPI,
                    PaymentMethod.CARD,
                    PaymentMethod.CHEQUE);
    private final SubscriptionOrderRepository orders;
    private final SocietyRepository societies;
    private final SubscriptionQuantityUseCase quantities;
    private final PlatformPaymentSettingRepository paymentSettings;
    private final StorageMeterUseCase storage;
    private final JsonCodec json;
    private final PlatformPaymentAttemptRepository attempts;
    private final RazorpayWebhookEventRepository webhookEvents;
    private final RazorpayGateway razorpay;
    private final PlatformInvoiceRenderer invoiceRenderer;

    public PlatformMembershipBillingService(
            SubscriptionOrderRepository orders,
            SocietyRepository societies,
            SubscriptionQuantityUseCase quantities,
            PlatformPaymentSettingRepository paymentSettings,
            StorageMeterUseCase storage,
            JsonCodec json,
            PlatformPaymentAttemptRepository attempts,
            RazorpayWebhookEventRepository webhookEvents,
            RazorpayGateway razorpay,
            PlatformInvoiceRenderer invoiceRenderer) {
        this.orders = orders;
        this.societies = societies;
        this.quantities = quantities;
        this.paymentSettings = paymentSettings;
        this.storage = storage;
        this.json = json;
        this.attempts = attempts;
        this.webhookEvents = webhookEvents;
        this.razorpay = razorpay;
        this.invoiceRenderer = invoiceRenderer;
    }

    public List<Map<String, Object>> societyOrders(UUID societyId) {
        return orders.findBySocietyIdOrderByBillingMonthDesc(societyId).stream()
                .map(this::view)
                .toList();
    }

    public List<Map<String, Object>> allOrders() {
        return orders.findAllByOrderByCreatedAtDesc().stream()
                .map(
                        order -> {
                            var map = new LinkedHashMap<String, Object>(view(order));
                            map.put(
                                    "society_name",
                                    societies
                                            .findById(order.getSocietyId())
                                            .map(Society::getName)
                                            .orElse("Society"));
                            societies
                                    .findById(order.getSocietyId())
                                    .ifPresent(
                                            society -> {
                                                map.put("society_email", society.getEmail());
                                                map.put("society_mobile", society.getMobile());
                                                map.put("society_code", society.getSocietyCode());
                                            });
                            return (Map<String, Object>) map;
                        })
                .toList();
    }

    public Map<String, Object> paymentSettings() {
        return paymentSettings
                .findFirstByOrderByUpdatedAtDesc()
                .map(this::paymentSettingView)
                .orElseGet(LinkedHashMap::new);
    }

    public Map<String, Object> updatePaymentSettings(
            UUID actorId,
            String beneficiaryName,
            String bankName,
            String accountNumber,
            String ifscCode,
            String upiId,
            String instructions) {
        var setting =
                paymentSettings
                        .findFirstByOrderByUpdatedAtDesc()
                        .orElseGet(PlatformPaymentSetting::new);
        setting.setBeneficiaryName(beneficiaryName.trim());
        setting.setBankName(blankToNull(bankName));
        setting.setAccountNumber(blankToNull(accountNumber));
        setting.setIfscCode(ifscCode == null ? null : ifscCode.trim().toUpperCase());
        setting.setUpiId(blankToNull(upiId));
        setting.setPaymentInstructions(blankToNull(instructions));
        setting.setUpdatedBy(actorId);
        setting.setUpdatedAt(OffsetDateTime.now());
        return paymentSettingView(paymentSettings.save(setting));
    }

    public Map<String, Object> issue(UUID societyId, LocalDate billingMonth, LocalDate dueDate) {
        var society =
                societies
                        .findById(societyId)
                        .orElseThrow(() -> new ResourceNotFoundException("Society not found"));
        billingMonth = billingMonth.withDayOfMonth(1);
        if (orders.existsBySocietyIdAndBillingMonthAndStatusNot(
                societyId, billingMonth, PaymentStatus.CANCELLED.code())) {
            throw new ConflictException(
                    "A platform membership invoice already exists for this month");
        }
        if (dueDate.isBefore(billingMonth)) {
            throw new IllegalArgumentException("Due date cannot be before the billing month");
        }
        var pricing = quantities.get(societyId);
        String billingCycle =
                society.getSubscriptionBillingCycle() == null
                        ? BillingCycle.MONTHLY.code()
                        : society.getSubscriptionBillingCycle();
        int cycleMonths = cycleMonths(billingCycle);
        var order = new SubscriptionOrder();
        order.setSocietyId(societyId);
        order.setPlanCode(society.getPlanCode());
        order.setInvoiceNumber(
                "SUB-"
                        + billingMonth.format(DateTimeFormatter.ofPattern("yyyyMM"))
                        + "-"
                        + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        order.setBillingMonth(billingMonth);
        order.setDueDate(dueDate);
        order.setBillingCycle(billingCycle);
        order.setPeriodStart(billingMonth);
        order.setPeriodEnd(billingMonth.plusMonths(cycleMonths).minusDays(1));
        BigDecimal storageMonthly = storage.monthlyAmount(societyId);
        BigDecimal storageCycle = storageMonthly.multiply(BigDecimal.valueOf(cycleMonths));
        order.setAmount(
                new BigDecimal(pricing.get("billing_cycle_amount").toString()).add(storageCycle));
        var breakdown = new ArrayList<Object>((List<?>) pricing.get("pricing_breakdown"));
        if (storageMonthly.signum() > 0) {
            breakdown.add(
                    Map.of(
                            "code",
                            "STORAGE_ADDON",
                            "name",
                            "Additional storage",
                            "monthly_amount",
                            storageMonthly,
                            "cycle_amount",
                            storageCycle));
        }
        order.setPricingBreakdown(writeJson(breakdown));
        order.setCurrency("INR");
        order.setProvider(PaymentProvider.MANUAL.code());
        order.setStatus(PaymentStatus.DUE.code());
        order.setCreatedAt(OffsetDateTime.now());
        order = orders.save(order);
        return view(order);
    }

    public Map<String, Object> submit(
            UUID societyId, UUID orderId, String method, String reference, String note) {
        var order =
                orders.findByIdAndSocietyId(orderId, societyId)
                        .orElseThrow(
                                () ->
                                        new ResourceNotFoundException(
                                                "Subscription invoice not found"));
        if (!Set.of(PaymentStatus.DUE.code(), PaymentStatus.REJECTED.code())
                .contains(order.getStatus())) {
            throw new IllegalStateException("Only due or rejected invoices can be submitted");
        }
        var requestedMethod = PaymentMethod.from(method);
        if (!METHODS.contains(requestedMethod)) {
            throw new IllegalArgumentException("Invalid payment method");
        }
        if (reference == null || reference.isBlank()) {
            throw new IllegalArgumentException("Payment transaction reference is required");
        }
        order.setPaymentMethod(requestedMethod.code());
        order.setProvider(PaymentProvider.from(requestedMethod.code()).code());
        order.setProviderReference(reference.trim().toUpperCase());
        order.setPaymentNote(note == null || note.isBlank() ? null : note.trim());
        order.setSubmittedAt(OffsetDateTime.now());
        order.setReviewedAt(null);
        order.setReviewedBy(null);
        order.setRejectionReason(null);
        order.setStatus(PaymentStatus.SUBMITTED.code());
        return view(orders.save(order));
    }

    public Map<String, Object> checkout(UUID societyId, UUID orderId, String method) {
        var order =
                orders.findByIdAndSocietyId(orderId, societyId)
                        .orElseThrow(
                                () ->
                                        new ResourceNotFoundException(
                                                "Subscription invoice not found"));
        if (!Set.of(
                        PaymentStatus.DUE.code(),
                        PaymentStatus.REJECTED.code(),
                        PaymentStatus.PAYMENT_PENDING.code())
                .contains(order.getStatus())) {
            throw new IllegalStateException("This invoice cannot start a new payment");
        }
        var requestedMethod = PaymentMethod.from(method);
        if (!Set.of(PaymentMethod.UPI, PaymentMethod.CARD, PaymentMethod.NET_BANKING)
                .contains(requestedMethod)) {
            throw new IllegalArgumentException("Invalid Razorpay payment method");
        }
        if (!razorpay.configured()) throw new IllegalStateException("Razorpay is not configured");
        long amountPaise = order.getAmount().movePointRight(2).longValueExact();
        if (amountPaise < 100)
            throw new IllegalStateException("Invoice amount is too low for online payment");
        var providerOrder =
                razorpay.createOrder(
                        amountPaise,
                        order.getCurrency(),
                        order.getInvoiceNumber(),
                        Map.of(
                                "subscription_order_id",
                                order.getId().toString(),
                                "society_id",
                                societyId.toString()));
        if (providerOrder.amount() != amountPaise
                || !order.getCurrency().equals(providerOrder.currency())) {
            throw new IllegalStateException("Razorpay created an order with unexpected totals");
        }
        var now = OffsetDateTime.now();
        var attempt = new PlatformPaymentAttempt();
        attempt.setSubscriptionOrderId(order.getId());
        attempt.setProviderOrderId(providerOrder.id());
        attempt.setAmount(order.getAmount());
        attempt.setCurrency(order.getCurrency());
        attempt.setRequestedMethod(requestedMethod.code());
        attempt.setStatus(PaymentAttemptStatus.CREATED.code());
        attempt.setCreatedAt(now);
        attempt.setUpdatedAt(now);
        attempts.save(attempt);
        order.setProvider(PaymentProvider.RAZORPAY.code());
        order.setProviderReference(providerOrder.id());
        order.setPaymentMethod(requestedMethod.razorpayCode());
        order.setPaymentNote(null);
        order.setSubmittedAt(now);
        order.setReviewedAt(null);
        order.setRejectionReason(null);
        order.setPaidAt(null);
        order.setStatus(PaymentStatus.PAYMENT_PENDING.code());
        orders.save(order);
        var society = societies.findById(societyId).orElseThrow();
        var response = new LinkedHashMap<String, Object>();
        response.put("key_id", razorpay.keyId());
        response.put("gateway_mode", razorpay.mode());
        response.put("provider_order_id", providerOrder.id());
        response.put("amount_paise", amountPaise);
        response.put("currency", order.getCurrency());
        response.put("name", "SocietyHub");
        response.put("description", "Platform membership · " + order.getInvoiceNumber());
        response.put(
                "prefill",
                Map.of(
                        "name",
                        nullSafe(society.getContactPerson()),
                        "email",
                        nullSafe(society.getEmail()),
                        "contact",
                        nullSafe(society.getMobile())));
        return response;
    }

    public Map<String, Object> verifyCheckout(
            UUID societyId,
            UUID orderId,
            String providerOrderId,
            String paymentId,
            String signature) {
        var order =
                orders.findByIdAndSocietyId(orderId, societyId)
                        .orElseThrow(
                                () ->
                                        new ResourceNotFoundException(
                                                "Subscription invoice not found"));
        var attempt =
                attempts.findByProviderOrderId(providerOrderId)
                        .filter(value -> value.getSubscriptionOrderId().equals(orderId))
                        .orElseThrow(
                                () -> new ResourceNotFoundException("Payment attempt not found"));
        if (!razorpay.verifyPaymentSignature(attempt.getProviderOrderId(), paymentId, signature)) {
            throw new IllegalArgumentException("Razorpay payment signature is invalid");
        }
        return applyProviderPayment(order, attempt, razorpay.fetchPayment(paymentId));
    }

    public Map<String, Object> reconcile(UUID orderId) {
        var order =
                orders.findById(orderId)
                        .orElseThrow(
                                () ->
                                        new ResourceNotFoundException(
                                                "Subscription invoice not found"));
        var attempt =
                attempts.findBySubscriptionOrderIdOrderByCreatedAtDesc(orderId).stream()
                        .filter(value -> value.getProviderPaymentId() != null)
                        .findFirst()
                        .orElseThrow(
                                () ->
                                        new IllegalStateException(
                                                "No Razorpay payment is available to reconcile"));
        return applyProviderPayment(
                order, attempt, razorpay.fetchPayment(attempt.getProviderPaymentId()));
    }

    public Map<String, Object> cancel(UUID actorId, UUID orderId, String reason) {
        var order =
                orders.findById(orderId)
                        .orElseThrow(
                                () ->
                                        new ResourceNotFoundException(
                                                "Subscription invoice not found"));
        if (!PaymentStatus.DUE.matches(order.getStatus())) {
            throw new IllegalStateException(
                    "Only a due invoice with no payment in progress can be cancelled");
        }
        if (!attempts.findBySubscriptionOrderIdOrderByCreatedAtDesc(orderId).isEmpty()) {
            throw new IllegalStateException(
                    "This invoice has a Razorpay attempt; reconcile it before cancellation");
        }
        if (reason == null || reason.isBlank()) {
            throw new IllegalArgumentException("Cancellation reason is required");
        }
        order.setStatus(PaymentStatus.CANCELLED.code());
        order.setReviewedBy(actorId);
        order.setReviewedAt(OffsetDateTime.now());
        order.setRejectionReason(reason.trim());
        return view(orders.save(order));
    }

    public boolean processWebhook(String eventId, String signature, String rawBody) {
        if (eventId == null || eventId.isBlank())
            throw new IllegalArgumentException("Missing Razorpay event id");
        if (!razorpay.verifyWebhookSignature(rawBody, signature)) {
            throw new IllegalArgumentException("Razorpay webhook signature is invalid");
        }
        try {
            var root = json.readTree(rawBody);
            String eventType = root.path("event").asText("unknown");
            if (webhookEvents.claim(eventId, eventType) == 0) return false;
            var payment = root.path("payload").path("payment").path("entity");
            if (!payment.isMissingNode()
                    && payment.hasNonNull("id")
                    && payment.hasNonNull("order_id")) {
                var attempt =
                        attempts.findByProviderOrderId(payment.path("order_id").asText())
                                .orElse(null);
                if (attempt != null) {
                    var order = orders.findById(attempt.getSubscriptionOrderId()).orElseThrow();
                    applyProviderPayment(
                            order,
                            attempt,
                            new RazorpayGateway.ProviderPayment(
                                    payment.path("id").asText(),
                                    payment.path("order_id").asText(),
                                    payment.path("amount").asLong(),
                                    payment.path("currency").asText(),
                                    payment.path("status").asText(),
                                    payment.path("method").asText(null),
                                    payment.path("captured").asBoolean(false),
                                    payment.path("error_code").asText(null),
                                    payment.path("error_description").asText(null)));
                }
            }
            webhookEvents.markProcessed(eventId);
            return true;
        } catch (JsonCodecException exception) {
            throw new IllegalArgumentException("Razorpay webhook payload is invalid", exception);
        }
    }

    public Map<String, Object> gatewayStatus() {
        return Map.of(
                "provider",
                PaymentProvider.RAZORPAY.code(),
                "configured",
                razorpay.configured(),
                "mode",
                razorpay.mode());
    }

    private Map<String, Object> applyProviderPayment(
            SubscriptionOrder order,
            PlatformPaymentAttempt attempt,
            RazorpayGateway.ProviderPayment payment) {
        if (!attempt.getProviderOrderId().equals(payment.orderId())
                || !attempt.getCurrency().equals(payment.currency())
                || attempt.getAmount().movePointRight(2).longValueExact() != payment.amount()) {
            throw new IllegalArgumentException("Razorpay payment does not match this invoice");
        }
        var now = OffsetDateTime.now();
        attempt.setProviderPaymentId(payment.id());
        attempt.setUpdatedAt(now);
        attempt.setFailureCode(payment.errorCode());
        attempt.setFailureDescription(payment.errorDescription());
        if (payment.captured() && "captured".equalsIgnoreCase(payment.status())) {
            attempt.setStatus(PaymentStatus.CAPTURED.code());
            if (!PaymentStatus.PAID.matches(order.getStatus())) {
                order.setStatus(PaymentStatus.PAID.code());
                order.setProvider(PaymentProvider.RAZORPAY.code());
                order.setProviderReference(payment.id());
                order.setPaymentMethod(
                        payment.method() == null
                                ? order.getPaymentMethod()
                                : "RAZORPAY_" + payment.method().toUpperCase(Locale.ROOT));
                order.setPaidAt(now);
                order.setReviewedAt(now);
                activateMembership(order, now);
            }
        } else if ("failed".equalsIgnoreCase(payment.status())) {
            attempt.setStatus(PaymentStatus.FAILED.code());
            if (!PaymentStatus.PAID.matches(order.getStatus())) {
                order.setStatus(PaymentStatus.REJECTED.code());
                order.setRejectionReason(
                        payment.errorDescription() == null
                                ? "Razorpay payment failed"
                                : payment.errorDescription());
            }
        } else {
            attempt.setStatus(PaymentStatus.AUTHORIZED.code());
            if (!PaymentStatus.PAID.matches(order.getStatus()))
                order.setStatus(PaymentStatus.PAYMENT_PENDING.code());
        }
        attempts.save(attempt);
        return view(orders.save(order));
    }

    public byte[] societyInvoice(UUID societyId, UUID orderId) {
        var order =
                orders.findByIdAndSocietyId(orderId, societyId)
                        .orElseThrow(
                                () ->
                                        new ResourceNotFoundException(
                                                "Subscription invoice not found"));
        return invoicePdf(order);
    }

    public byte[] adminInvoice(UUID orderId) {
        var order =
                orders.findById(orderId)
                        .orElseThrow(
                                () ->
                                        new ResourceNotFoundException(
                                                "Subscription invoice not found"));
        return invoicePdf(order);
    }

    public Map<String, Object> review(
            UUID actorId, UUID orderId, String status, String rejectionReason) {
        var order =
                orders.findById(orderId)
                        .orElseThrow(
                                () ->
                                        new ResourceNotFoundException(
                                                "Subscription invoice not found"));
        if (!PaymentStatus.SUBMITTED.matches(order.getStatus())) {
            throw new IllegalStateException("Only submitted payments can be reviewed");
        }
        if (!Set.of(PaymentStatus.PAID.code(), PaymentStatus.REJECTED.code()).contains(status)) {
            throw new IllegalArgumentException("Review status must be PAID or REJECTED");
        }
        if (PaymentStatus.REJECTED.matches(status)
                && (rejectionReason == null || rejectionReason.isBlank())) {
            throw new IllegalArgumentException("Rejection reason is required");
        }
        order.setStatus(status);
        order.setReviewedBy(actorId);
        order.setReviewedAt(OffsetDateTime.now());
        order.setRejectionReason(
                PaymentStatus.REJECTED.matches(status) ? rejectionReason.trim() : null);
        if (PaymentStatus.PAID.code().equals(status)) {
            order.setPaidAt(OffsetDateTime.now());
            activateMembership(order, OffsetDateTime.now());
        }
        return view(orders.save(order));
    }

    private Map<String, Object> view(SubscriptionOrder order) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", order.getId());
        map.put("society_id", order.getSocietyId());
        map.put("invoice_number", order.getInvoiceNumber());
        map.put("billing_month", order.getBillingMonth());
        map.put("due_date", order.getDueDate());
        map.put("billing_cycle", order.getBillingCycle());
        map.put("period_start", order.getPeriodStart());
        map.put("period_end", order.getPeriodEnd());
        map.put("plan_code", order.getPlanCode());
        map.put("amount", order.getAmount());
        map.put("currency", order.getCurrency());
        map.put("status", order.getStatus());
        map.put("payment_method", order.getPaymentMethod());
        map.put("provider_reference", order.getProviderReference());
        map.put("payment_note", order.getPaymentNote());
        map.put("submitted_at", order.getSubmittedAt());
        map.put("paid_at", order.getPaidAt());
        map.put("reviewed_at", order.getReviewedAt());
        map.put("rejection_reason", order.getRejectionReason());
        map.put("created_at", order.getCreatedAt());
        map.put("pricing_breakdown", readBreakdown(order.getPricingBreakdown()));
        map.put(
                "overdue",
                !Set.of(PaymentStatus.PAID.code(), PaymentStatus.CANCELLED.code())
                                .contains(order.getStatus())
                        && order.getDueDate().isBefore(LocalDate.now()));
        var paymentAttempts =
                attempts.findBySubscriptionOrderIdOrderByCreatedAtDesc(order.getId()).stream()
                        .map(this::attemptView)
                        .toList();
        map.put("payment_attempts", paymentAttempts);
        map.put(
                "gateway_mode",
                PaymentProvider.RAZORPAY.matches(order.getProvider()) ? razorpay.mode() : null);
        return map;
    }

    private Map<String, Object> attemptView(PlatformPaymentAttempt attempt) {
        var map = new LinkedHashMap<String, Object>();
        map.put("provider_order_id", attempt.getProviderOrderId());
        map.put("provider_payment_id", attempt.getProviderPaymentId());
        map.put("amount", attempt.getAmount());
        map.put("currency", attempt.getCurrency());
        map.put("requested_method", attempt.getRequestedMethod());
        map.put("status", attempt.getStatus());
        map.put("failure_code", attempt.getFailureCode());
        map.put("failure_description", attempt.getFailureDescription());
        map.put("created_at", attempt.getCreatedAt());
        map.put("updated_at", attempt.getUpdatedAt());
        return map;
    }

    private void activateMembership(SubscriptionOrder order, OffsetDateTime now) {
        var society = societies.findById(order.getSocietyId()).orElseThrow();
        var base =
                society.getSubscriptionExpiresAt() != null
                                && society.getSubscriptionExpiresAt().isAfter(now)
                        ? society.getSubscriptionExpiresAt()
                        : now;
        society.setSubscriptionStatus(SubscriptionStatus.ACTIVE.code());
        society.setSubscriptionExpiresAt(base.plusMonths(cycleMonths(order.getBillingCycle())));
        society.setUpdatedAt(now);
        societies.save(society);
    }

    private byte[] invoicePdf(SubscriptionOrder order) {
        var society =
                societies
                        .findById(order.getSocietyId())
                        .orElseThrow(() -> new ResourceNotFoundException("Society not found"));
        return invoiceRenderer.render(order, society, readBreakdown(order.getPricingBreakdown()));
    }

    private String nullSafe(String value) {
        return value == null ? "" : value;
    }

    private String writeJson(Object value) {
        try {
            return json.write(value);
        } catch (JsonCodecException exception) {
            throw new IllegalStateException("Could not snapshot invoice pricing", exception);
        }
    }

    private List<Map<String, Object>> readBreakdown(String value) {
        try {
            return json.readObjectList(value == null ? "[]" : value);
        } catch (JsonCodecException exception) {
            throw new IllegalStateException("Invoice pricing snapshot is invalid", exception);
        }
    }

    private Map<String, Object> paymentSettingView(PlatformPaymentSetting setting) {
        var map = new LinkedHashMap<String, Object>();
        map.put("beneficiary_name", setting.getBeneficiaryName());
        map.put("bank_name", setting.getBankName());
        map.put("account_number", setting.getAccountNumber());
        map.put("ifsc_code", setting.getIfscCode());
        map.put("upi_id", setting.getUpiId());
        map.put("payment_instructions", setting.getPaymentInstructions());
        map.put("updated_at", setting.getUpdatedAt());
        return map;
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private int cycleMonths(String cycle) {
        return switch (BillingCycle.from(cycle == null ? BillingCycle.MONTHLY.code() : cycle)) {
            case QUARTERLY -> 3;
            case YEARLY -> 12;
            case MONTHLY -> 1;
        };
    }
}
