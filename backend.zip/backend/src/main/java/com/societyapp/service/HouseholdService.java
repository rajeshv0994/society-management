package com.societyapp.service;

import com.societyapp.application.exception.AuthorizationException;
import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.port.in.HouseholdUseCase;
import com.societyapp.domain.type.AccountStatus;
import com.societyapp.domain.type.ResidentType;
import com.societyapp.domain.type.StaffPermissionCode;
import com.societyapp.domain.type.UserRole;
import com.societyapp.domain.type.VerificationStatus;
import com.societyapp.entity.*;
import com.societyapp.repository.*;
import java.time.*;
import java.util.*;

public class HouseholdService implements HouseholdUseCase {
    private final UserAccountJpaRepository users;
    private final HouseholdMemberRepository members;
    private final HouseholdVehicleRepository vehicles;
    private final HouseholdEmergencyContactRepository contacts;
    private final FlatRepository flats;
    private final FloorRepository floors;
    private final BlockRepository blocks;
    private final StaffPermissionRepository permissions;

    public HouseholdService(
            UserAccountJpaRepository users,
            HouseholdMemberRepository members,
            HouseholdVehicleRepository vehicles,
            HouseholdEmergencyContactRepository contacts,
            FlatRepository flats,
            FloorRepository floors,
            BlockRepository blocks,
            StaffPermissionRepository permissions) {
        this.users = users;
        this.members = members;
        this.vehicles = vehicles;
        this.contacts = contacts;
        this.flats = flats;
        this.floors = floors;
        this.blocks = blocks;
        this.permissions = permissions;
    }

    public Map<String, Object> profile(UUID societyId, UUID userId) {
        return householdView(requireResident(societyId, userId));
    }

    public Map<String, Object> workspace(UUID societyId, UUID actorId, String role) {
        List<UserAccount> residents;
        if (UserRole.RESIDENT.matches(role)) {
            residents = List.of(requireResident(societyId, actorId));
        } else {
            requireManager(actorId, role);
            residents =
                    users
                            .findBySocietyIdAndRoleOrderByFullName(
                                    societyId, UserRole.RESIDENT.code())
                            .stream()
                            .filter(user -> AccountStatus.ACTIVE.matches(user.getStatus()))
                            .toList();
        }
        var households = residents.stream().map(this::householdView).toList();
        int memberCount =
                households.stream().mapToInt(row -> ((List<?>) row.get("household")).size()).sum();
        int vehicleCount =
                households.stream().mapToInt(row -> ((List<?>) row.get("vehicles")).size()).sum();
        long pending =
                households.stream()
                        .flatMap(row -> ((List<Map<String, Object>>) row.get("household")).stream())
                        .filter(
                                row ->
                                        VerificationStatus.PENDING.matches(
                                                (String) row.get("verification_status")))
                        .count();
        pending +=
                households.stream()
                        .flatMap(row -> ((List<Map<String, Object>>) row.get("vehicles")).stream())
                        .filter(
                                row ->
                                        VerificationStatus.PENDING.matches(
                                                (String) row.get("verification_status")))
                        .count();
        return Map.of(
                "households", households,
                "resident_count", households.size(),
                "member_count", memberCount,
                "vehicle_count", vehicleCount,
                "pending_verification", pending);
    }

    public Map<String, Object> add(
            UUID societyId,
            UUID residentId,
            String fullName,
            String relationship,
            String mobile,
            LocalDate dateOfBirth) {
        return addMember(
                societyId,
                residentId,
                UserRole.RESIDENT.code(),
                null,
                fullName,
                relationship,
                mobile,
                null,
                dateOfBirth,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null);
    }

    public Map<String, Object> addMember(
            UUID societyId,
            UUID actorId,
            String role,
            UUID requestedResidentId,
            String fullName,
            String relationship,
            String mobile,
            String email,
            LocalDate dateOfBirth,
            String gender,
            String bloodGroup,
            String occupation,
            String identityType,
            String identityLast4,
            String emergencyName,
            String emergencyMobile,
            Boolean accessEnabled) {
        UUID residentId = targetResident(societyId, actorId, role, requestedResidentId);
        var item = new HouseholdMember();
        item.setSocietyId(societyId);
        item.setPrimaryResidentId(residentId);
        item.setMemberCode(memberCode());
        item.setCreatedAt(OffsetDateTime.now());
        applyMember(
                item,
                fullName,
                relationship,
                mobile,
                email,
                dateOfBirth,
                gender,
                bloodGroup,
                occupation,
                identityType,
                identityLast4,
                emergencyName,
                emergencyMobile,
                accessEnabled);
        item.setVerificationStatus(VerificationStatus.PENDING.code());
        item.setActive(true);
        return memberView(members.save(item));
    }

    public Map<String, Object> updateMember(
            UUID societyId,
            UUID actorId,
            String role,
            UUID requestedResidentId,
            UUID memberId,
            String fullName,
            String relationship,
            String mobile,
            String email,
            LocalDate dateOfBirth,
            String gender,
            String bloodGroup,
            String occupation,
            String identityType,
            String identityLast4,
            String emergencyName,
            String emergencyMobile,
            Boolean accessEnabled) {
        UUID residentId = targetResident(societyId, actorId, role, requestedResidentId);
        var item = requireMember(societyId, residentId, memberId);
        applyMember(
                item,
                fullName,
                relationship,
                mobile,
                email,
                dateOfBirth,
                gender,
                bloodGroup,
                occupation,
                identityType,
                identityLast4,
                emergencyName,
                emergencyMobile,
                accessEnabled);
        if (UserRole.RESIDENT.matches(role)) {
            item.setVerificationStatus(VerificationStatus.PENDING.code());
            item.setVerificationNote(null);
            item.setReviewedBy(null);
            item.setReviewedAt(null);
        }
        return memberView(members.save(item));
    }

    public Map<String, Object> reviewMember(
            UUID societyId,
            UUID actorId,
            String role,
            UUID residentId,
            UUID memberId,
            String status,
            String note) {
        requireManager(actorId, role);
        requireResident(societyId, residentId);
        var item = requireMember(societyId, residentId, memberId);
        applyReview(item, actorId, status, note);
        return memberView(members.save(item));
    }

    public Map<String, Object> remove(UUID societyId, UUID residentId, UUID memberId) {
        return removeMember(societyId, residentId, UserRole.RESIDENT.code(), null, memberId);
    }

    public Map<String, Object> removeMember(
            UUID societyId, UUID actorId, String role, UUID requestedResidentId, UUID memberId) {
        UUID residentId = targetResident(societyId, actorId, role, requestedResidentId);
        var item = requireMember(societyId, residentId, memberId);
        item.setActive(false);
        item.setAccessEnabled(false);
        item.setUpdatedAt(OffsetDateTime.now());
        members.save(item);
        return Map.of("id", memberId, "active", false);
    }

    public Map<String, Object> addVehicle(
            UUID societyId,
            UUID actorId,
            String role,
            UUID requestedResidentId,
            String type,
            String registration,
            String make,
            String model,
            String color,
            String parkingSlot,
            String stickerNumber) {
        UUID residentId = targetResident(societyId, actorId, role, requestedResidentId);
        var item = new HouseholdVehicle();
        item.setSocietyId(societyId);
        item.setPrimaryResidentId(residentId);
        item.setCreatedAt(OffsetDateTime.now());
        applyVehicle(item, type, registration, make, model, color, parkingSlot, stickerNumber);
        item.setVerificationStatus(VerificationStatus.PENDING.code());
        item.setActive(true);
        return vehicleView(vehicles.save(item));
    }

    public Map<String, Object> updateVehicle(
            UUID societyId,
            UUID actorId,
            String role,
            UUID requestedResidentId,
            UUID vehicleId,
            String type,
            String registration,
            String make,
            String model,
            String color,
            String parkingSlot,
            String stickerNumber) {
        UUID residentId = targetResident(societyId, actorId, role, requestedResidentId);
        var item = requireVehicle(societyId, residentId, vehicleId);
        applyVehicle(item, type, registration, make, model, color, parkingSlot, stickerNumber);
        if (UserRole.RESIDENT.matches(role)) {
            item.setVerificationStatus(VerificationStatus.PENDING.code());
            item.setVerificationNote(null);
            item.setReviewedBy(null);
            item.setReviewedAt(null);
        }
        return vehicleView(vehicles.save(item));
    }

    public Map<String, Object> reviewVehicle(
            UUID societyId,
            UUID actorId,
            String role,
            UUID residentId,
            UUID vehicleId,
            String status,
            String note) {
        requireManager(actorId, role);
        requireResident(societyId, residentId);
        var item = requireVehicle(societyId, residentId, vehicleId);
        applyReview(item, actorId, status, note);
        return vehicleView(vehicles.save(item));
    }

    public Map<String, Object> removeVehicle(
            UUID societyId, UUID actorId, String role, UUID requestedResidentId, UUID vehicleId) {
        UUID residentId = targetResident(societyId, actorId, role, requestedResidentId);
        var item = requireVehicle(societyId, residentId, vehicleId);
        item.setActive(false);
        item.setUpdatedAt(OffsetDateTime.now());
        vehicles.save(item);
        return Map.of("id", vehicleId, "active", false);
    }

    public Map<String, Object> addContact(
            UUID societyId,
            UUID actorId,
            String role,
            UUID requestedResidentId,
            String fullName,
            String relationship,
            String mobile,
            String alternateMobile,
            int priority) {
        UUID residentId = targetResident(societyId, actorId, role, requestedResidentId);
        if (contacts.findBySocietyIdAndPrimaryResidentIdAndActiveTrueOrderByPriority(
                                societyId, residentId)
                        .size()
                >= 3) {
            throw new IllegalStateException("A household can have up to 3 emergency contacts");
        }
        var item = new HouseholdEmergencyContact();
        item.setSocietyId(societyId);
        item.setPrimaryResidentId(residentId);
        item.setCreatedAt(OffsetDateTime.now());
        item.setActive(true);
        applyContact(item, fullName, relationship, mobile, alternateMobile, priority);
        return contactView(contacts.save(item));
    }

    public Map<String, Object> updateContact(
            UUID societyId,
            UUID actorId,
            String role,
            UUID requestedResidentId,
            UUID contactId,
            String fullName,
            String relationship,
            String mobile,
            String alternateMobile,
            int priority) {
        UUID residentId = targetResident(societyId, actorId, role, requestedResidentId);
        var item = requireContact(societyId, residentId, contactId);
        applyContact(item, fullName, relationship, mobile, alternateMobile, priority);
        return contactView(contacts.save(item));
    }

    public Map<String, Object> removeContact(
            UUID societyId, UUID actorId, String role, UUID requestedResidentId, UUID contactId) {
        UUID residentId = targetResident(societyId, actorId, role, requestedResidentId);
        var item = requireContact(societyId, residentId, contactId);
        item.setActive(false);
        item.setUpdatedAt(OffsetDateTime.now());
        contacts.save(item);
        return Map.of("id", contactId, "active", false);
    }

    private UUID targetResident(
            UUID societyId, UUID actorId, String role, UUID requestedResidentId) {
        if (UserRole.RESIDENT.matches(role)) {
            if (requestedResidentId != null && !actorId.equals(requestedResidentId)) {
                throw new AuthorizationException("You can only manage your own household");
            }
            requireResident(societyId, actorId);
            return actorId;
        }
        requireManager(actorId, role);
        if (requestedResidentId == null) {
            throw new IllegalArgumentException("Resident is required");
        }
        requireResident(societyId, requestedResidentId);
        return requestedResidentId;
    }

    private void requireManager(UUID actorId, String role) {
        if (UserRole.SOCIETY_ADMIN.matches(role)) return;
        if (UserRole.STAFF.matches(role)
                && permissions.existsByStaffUserIdAndPermissionCode(
                        actorId, StaffPermissionCode.HOUSEHOLDS.code())) return;
        throw new AuthorizationException("Household management permission is required");
    }

    private UserAccount requireResident(UUID societyId, UUID residentId) {
        return users.findById(residentId)
                .filter(user -> societyId.equals(user.getSocietyId()))
                .filter(user -> UserRole.RESIDENT.matches(user.getRole()))
                .orElseThrow(() -> new ResourceNotFoundException("Resident not found"));
    }

    private HouseholdMember requireMember(UUID societyId, UUID residentId, UUID memberId) {
        return members.findByIdAndSocietyIdAndPrimaryResidentId(memberId, societyId, residentId)
                .filter(HouseholdMember::isActive)
                .orElseThrow(() -> new ResourceNotFoundException("Household member not found"));
    }

    private HouseholdVehicle requireVehicle(UUID societyId, UUID residentId, UUID vehicleId) {
        return vehicles.findByIdAndSocietyIdAndPrimaryResidentId(vehicleId, societyId, residentId)
                .filter(HouseholdVehicle::isActive)
                .orElseThrow(() -> new ResourceNotFoundException("Household vehicle not found"));
    }

    private HouseholdEmergencyContact requireContact(
            UUID societyId, UUID residentId, UUID contactId) {
        return contacts.findByIdAndSocietyIdAndPrimaryResidentId(contactId, societyId, residentId)
                .filter(HouseholdEmergencyContact::isActive)
                .orElseThrow(() -> new ResourceNotFoundException("Emergency contact not found"));
    }

    private void applyMember(
            HouseholdMember item,
            String fullName,
            String relationship,
            String mobile,
            String email,
            LocalDate dateOfBirth,
            String gender,
            String bloodGroup,
            String occupation,
            String identityType,
            String identityLast4,
            String emergencyName,
            String emergencyMobile,
            Boolean accessEnabled) {
        item.setFullName(fullName.trim());
        item.setRelationship(relationship.trim().toUpperCase(Locale.ROOT));
        item.setMobile(blankToNull(mobile));
        item.setEmail(blankToNull(email));
        item.setDateOfBirth(dateOfBirth);
        item.setGender(blankToNull(gender));
        item.setBloodGroup(blankToNull(bloodGroup));
        item.setOccupation(blankToNull(occupation));
        item.setIdentityType(blankToNull(identityType));
        item.setIdentityLast4(
                identityLast4 == null || identityLast4.isBlank()
                        ? null
                        : identityLast4.trim().toUpperCase(Locale.ROOT));
        item.setEmergencyContactName(blankToNull(emergencyName));
        item.setEmergencyContactMobile(blankToNull(emergencyMobile));
        item.setAccessEnabled(accessEnabled != null && accessEnabled);
        item.setUpdatedAt(OffsetDateTime.now());
    }

    private void applyVehicle(
            HouseholdVehicle item,
            String type,
            String registration,
            String make,
            String model,
            String color,
            String parkingSlot,
            String stickerNumber) {
        item.setVehicleType(type);
        item.setRegistrationNumber(registration.replaceAll("\\s+", "").toUpperCase(Locale.ROOT));
        item.setMake(blankToNull(make));
        item.setModel(blankToNull(model));
        item.setColor(blankToNull(color));
        item.setParkingSlot(blankToNull(parkingSlot));
        item.setStickerNumber(blankToNull(stickerNumber));
        item.setUpdatedAt(OffsetDateTime.now());
    }

    private void applyContact(
            HouseholdEmergencyContact item,
            String fullName,
            String relationship,
            String mobile,
            String alternateMobile,
            int priority) {
        item.setFullName(fullName.trim());
        item.setRelationship(relationship.trim().toUpperCase(Locale.ROOT));
        item.setMobile(mobile.trim());
        item.setAlternateMobile(blankToNull(alternateMobile));
        item.setPriority(priority);
        item.setUpdatedAt(OffsetDateTime.now());
    }

    private void applyReview(HouseholdMember item, UUID reviewerId, String status, String note) {
        var requestedStatus = reviewStatus(status);
        requireReviewNote(requestedStatus, note);
        item.setVerificationStatus(requestedStatus.code());
        item.setVerificationNote(blankToNull(note));
        item.setReviewedBy(reviewerId);
        item.setReviewedAt(OffsetDateTime.now());
        item.setUpdatedAt(OffsetDateTime.now());
    }

    private void applyReview(HouseholdVehicle item, UUID reviewerId, String status, String note) {
        var requestedStatus = reviewStatus(status);
        requireReviewNote(requestedStatus, note);
        item.setVerificationStatus(requestedStatus.code());
        item.setVerificationNote(blankToNull(note));
        item.setReviewedBy(reviewerId);
        item.setReviewedAt(OffsetDateTime.now());
        item.setUpdatedAt(OffsetDateTime.now());
    }

    private VerificationStatus reviewStatus(String status) {
        var requestedStatus = VerificationStatus.from(status);
        if (requestedStatus == VerificationStatus.PENDING) {
            throw new IllegalArgumentException("Review status must be VERIFIED or REJECTED");
        }
        return requestedStatus;
    }

    private void requireReviewNote(VerificationStatus status, String note) {
        if (status == VerificationStatus.REJECTED && (note == null || note.isBlank())) {
            throw new IllegalArgumentException("Rejection note is required");
        }
    }

    private Map<String, Object> householdView(UserAccount user) {
        UUID societyId = user.getSocietyId();
        UUID residentId = user.getId();
        var spaces =
                flats.findAll().stream()
                        .filter(
                                flat ->
                                        residentId.equals(flat.getActiveOwnerId())
                                                || residentId.equals(flat.getActiveTenantId()))
                        .map(flat -> flatView(flat, residentId))
                        .toList();
        var map = new LinkedHashMap<String, Object>();
        map.put("resident", userView(user));
        map.put("user", userView(user));
        map.put("spaces", spaces);
        map.put("units", spaces);
        map.put("flats", spaces);
        map.put(
                "household",
                members
                        .findBySocietyIdAndPrimaryResidentIdAndActiveTrue(societyId, residentId)
                        .stream()
                        .map(this::memberView)
                        .toList());
        map.put(
                "vehicles",
                vehicles
                        .findBySocietyIdAndPrimaryResidentIdAndActiveTrueOrderByRegistrationNumber(
                                societyId, residentId)
                        .stream()
                        .map(this::vehicleView)
                        .toList());
        map.put(
                "emergency_contacts",
                contacts
                        .findBySocietyIdAndPrimaryResidentIdAndActiveTrueOrderByPriority(
                                societyId, residentId)
                        .stream()
                        .map(this::contactView)
                        .toList());
        return map;
    }

    private Map<String, Object> userView(UserAccount user) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", user.getId());
        map.put("full_name", user.getFullName());
        map.put("email", user.getEmail());
        map.put("mobile", user.getMobile());
        map.put("email_verified", user.isEmailVerified());
        map.put("mobile_verified", user.isMobileVerified());
        map.put("status", user.getStatus());
        return map;
    }

    private Map<String, Object> flatView(Flat flat, UUID residentId) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", flat.getId());
        map.put("space_number", flat.getFlatNumber());
        map.put("unit_number", flat.getFlatNumber());
        map.put("flat_number", flat.getFlatNumber());
        map.put("occupancy_status", flat.getOccupancyStatus());
        map.put("area_sqft", flat.getAreaSqft());
        map.put(
                "resident_type",
                residentId.equals(flat.getActiveOwnerId())
                        ? ResidentType.OWNER.code()
                        : ResidentType.TENANT.code());
        floors.findById(flat.getFloorId())
                .ifPresent(
                        floor -> {
                            map.put("section", floor.getName());
                            map.put("floor", floor.getName());
                            blocks.findById(floor.getBlockId())
                                    .ifPresent(block -> map.put("block", block.getName()));
                        });
        return map;
    }

    private Map<String, Object> memberView(HouseholdMember item) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", item.getId());
        map.put("member_code", item.getMemberCode());
        map.put("resident_id", item.getPrimaryResidentId());
        map.put("full_name", item.getFullName());
        map.put("relationship", item.getRelationship());
        map.put("mobile", item.getMobile());
        map.put("email", item.getEmail());
        map.put("date_of_birth", item.getDateOfBirth());
        map.put("gender", item.getGender());
        map.put("blood_group", item.getBloodGroup());
        map.put("occupation", item.getOccupation());
        map.put("identity_type", item.getIdentityType());
        map.put("identity_last4", item.getIdentityLast4());
        map.put("emergency_contact_name", item.getEmergencyContactName());
        map.put("emergency_contact_mobile", item.getEmergencyContactMobile());
        map.put("access_enabled", item.isAccessEnabled());
        map.put("verification_status", item.getVerificationStatus());
        map.put("verification_note", item.getVerificationNote());
        map.put("active", item.isActive());
        return map;
    }

    private Map<String, Object> vehicleView(HouseholdVehicle item) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", item.getId());
        map.put("resident_id", item.getPrimaryResidentId());
        map.put("vehicle_type", item.getVehicleType());
        map.put("registration_number", item.getRegistrationNumber());
        map.put("make", item.getMake());
        map.put("model", item.getModel());
        map.put("color", item.getColor());
        map.put("parking_slot", item.getParkingSlot());
        map.put("sticker_number", item.getStickerNumber());
        map.put("verification_status", item.getVerificationStatus());
        map.put("verification_note", item.getVerificationNote());
        map.put("active", item.isActive());
        return map;
    }

    private Map<String, Object> contactView(HouseholdEmergencyContact item) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", item.getId());
        map.put("resident_id", item.getPrimaryResidentId());
        map.put("full_name", item.getFullName());
        map.put("relationship", item.getRelationship());
        map.put("mobile", item.getMobile());
        map.put("alternate_mobile", item.getAlternateMobile());
        map.put("priority", item.getPriority());
        map.put("active", item.isActive());
        return map;
    }

    private String memberCode() {
        return "HM-"
                + UUID.randomUUID()
                        .toString()
                        .replace("-", "")
                        .substring(0, 10)
                        .toUpperCase(Locale.ROOT);
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
