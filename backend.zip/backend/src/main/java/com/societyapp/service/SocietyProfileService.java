package com.societyapp.service;

import com.societyapp.application.model.SocietyProfileUpdate;
import com.societyapp.application.port.in.SocietyProfileUseCase;
import com.societyapp.application.port.out.DocumentStorage;
import com.societyapp.application.port.out.UploadedFile;
import com.societyapp.repository.SocietyProfileStore;
import java.util.Map;
import java.util.UUID;

public class SocietyProfileService implements SocietyProfileUseCase {
    private final SocietyProfileStore profiles;
    private final DocumentStorage storage;

    public SocietyProfileService(SocietyProfileStore profiles, DocumentStorage storage) {
        this.profiles = profiles;
        this.storage = storage;
    }

    public Map<String, Object> get(UUID societyId) {
        return profiles.findById(societyId);
    }

    public Map<String, Object> update(UUID societyId, SocietyProfileUpdate update) {
        profiles.update(societyId, update);
        return profiles.findById(societyId);
    }

    public Map<String, Object> uploadLogo(UUID societyId, UploadedFile file) {
        if (!profiles.exists(societyId)) throw new IllegalArgumentException("Society not found");
        String storageKey = storage.storeImage(societyId, file);
        profiles.updateLogo(societyId, storageKey, file.contentType());
        storage.attach(storageKey, "SOCIETY_LOGO", societyId, "Society logo");
        return Map.of(
                "societyId",
                societyId,
                "logoUrl",
                "/api/public/societies/" + societyId + "/logo",
                "updated",
                true);
    }

    public LogoContent getLogo(UUID societyId) {
        Map<String, Object> logo = profiles.findLogo(societyId);
        if (logo.isEmpty()) return null;
        return new LogoContent(
                storage.load((String) logo.get("logo_storage_key")),
                (String) logo.get("logo_content_type"));
    }
}
