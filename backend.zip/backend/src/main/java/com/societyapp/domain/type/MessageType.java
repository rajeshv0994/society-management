package com.societyapp.domain.type;

public enum MessageType implements DomainCode {
    TEXT;
}
