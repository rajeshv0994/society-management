package com.societyapp.domain.type;

public enum DeliveryDecision implements DomainCode {
    ACCEPTED,
    REJECTED;
}
