package com.societyapp.domain.type;

public enum PaymentChannel implements DomainCode {
    ONLINE,
    OFFLINE;
}
