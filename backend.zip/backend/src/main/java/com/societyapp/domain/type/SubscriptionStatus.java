package com.societyapp.domain.type;

public enum SubscriptionStatus implements DomainCode {
    TRIAL,
    ACTIVE,
    PENDING,
    PENDING_PAYMENT,
    PAYMENT_PENDING,
    DUE,
    SUSPENDED,
    EXPIRED,
    CANCELLED,
    REJECTED,
    CLOSED
}
