package com.societyapp.security;

import com.societyapp.application.policy.StaffPermissionCatalog;
import com.societyapp.application.port.in.SubscriptionAccessUseCase;
import com.societyapp.domain.type.UserRole;
import com.societyapp.repository.SocietyRepository;
import io.jsonwebtoken.Claims;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class ServiceEntitlementInterceptor implements HandlerInterceptor {
    private static final Map<String, String> ROUTES = routes();
    private final SocietyRepository societies;
    private final SubscriptionAccessUseCase subscriptions;

    public ServiceEntitlementInterceptor(
            SocietyRepository societies, SubscriptionAccessUseCase subscriptions) {
        this.societies = societies;
        this.subscriptions = subscriptions;
    }

    @Override
    public boolean preHandle(
            HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        var path = request.getRequestURI();
        if (path.startsWith("/api/public/")
                || path.startsWith("/api/auth/")
                || path.startsWith("/api/admin/platform/")) return true;
        var authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null
                && authentication.isAuthenticated()
                && authentication.getDetails() instanceof Claims) {
            var societyId = CurrentUser.societyId();
            if (societyId != null) {
                var decision = subscriptions.evaluate(societyId);
                var role = ((Claims) authentication.getDetails()).get("role", String.class);
                boolean paymentRecovery =
                        UserRole.SOCIETY_ADMIN.matches(role)
                                && (path.startsWith("/api/society/subscription")
                                        || ("GET".equals(request.getMethod())
                                                && path.equals("/api/society/profile")));
                if (!decision.allowed() && !paymentRecovery) {
                    response.setStatus(HttpServletResponse.SC_PAYMENT_REQUIRED);
                    response.setContentType("application/json");
                    response.getWriter().write("{\"message\":\"" + decision.reason() + "\"}");
                    return false;
                }
            }
        }
        if (path.startsWith("/api/society/staff/me")) return true;
        var required =
                ROUTES.entrySet().stream()
                        .filter(entry -> path.startsWith(entry.getKey()))
                        .map(Map.Entry::getValue)
                        .findFirst()
                        .orElse(null);
        if (required == null) return true;
        authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null
                || !authentication.isAuthenticated()
                || !(authentication.getDetails() instanceof Claims)) return true;
        var societyId = CurrentUser.societyId();
        if (societyId == null) return true;
        var society = societies.findById(societyId).orElse(null);
        if (society == null) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            return false;
        }
        if (!StaffPermissionCatalog.moduleEnabled(society.getEnabledModules(), required)) {
            // sendError dispatches through /error, where the security filter can replace the
            // intended entitlement response with 401. A direct status preserves the real result.
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            return false;
        }
        return true;
    }

    private static Map<String, String> routes() {
        var routes = new LinkedHashMap<String, String>();
        routes.put("/api/billing/expenses", "BILLING");
        routes.put("/api/billing/charge-settings", "BILLING");
        routes.put("/api/billing/finance-summary", "BILLING");
        routes.put("/api/billing/budget", "BILLING");
        routes.put("/api/billing/staff-salaries", "BILLING");
        routes.put("/api/billing", "PAYMENTS");
        routes.put("/api/activities", "ACTIVITIES_GALLERIES");
        routes.put("/api/amenities", "AMENITIES");
        routes.put("/api/complaints", "COMPLAINTS");
        routes.put("/api/deliveries", "DELIVERIES");
        routes.put("/api/emergencies", "EMERGENCY_INCIDENTS");
        routes.put("/api/households", "RESIDENTS");
        routes.put("/api/member/documents", "DOCUMENTS");
        routes.put("/api/member", "RESIDENTS");
        routes.put("/api/notices", "NOTICES");
        routes.put("/api/society/documents", "DOCUMENTS");
        routes.put("/api/society/staff", "STAFF");
        routes.put("/api/tasks", "STAFF");
        routes.put("/api/visitors", "VISITORS");
        return Collections.unmodifiableMap(routes);
    }
}
