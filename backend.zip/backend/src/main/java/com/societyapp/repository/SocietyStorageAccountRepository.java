package com.societyapp.repository;

import com.societyapp.entity.SocietyStorageAccount;
import java.util.Optional;
import java.util.UUID;

public interface SocietyStorageAccountRepository
        extends CrudRepositoryPort<SocietyStorageAccount, UUID> {
    Optional<SocietyStorageAccount> findForUpdate(UUID societyId);
}
