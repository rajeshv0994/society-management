package com.societyapp.repository;

import com.societyapp.entity.StaffSalaryPayment;
import java.time.LocalDate;
import java.util.*;

public interface StaffSalaryPaymentRepository extends CrudRepositoryPort<StaffSalaryPayment, UUID> {
    List<StaffSalaryPayment> findByStaffUserIdOrderBySalaryMonthDesc(UUID staffUserId);

    boolean existsByStaffUserIdAndSalaryMonth(UUID staffUserId, LocalDate salaryMonth);

    List<StaffSalaryPayment> findBySocietyIdAndPaidOnBetweenOrderByPaidOnDesc(
            UUID societyId, LocalDate from, LocalDate to);
}
