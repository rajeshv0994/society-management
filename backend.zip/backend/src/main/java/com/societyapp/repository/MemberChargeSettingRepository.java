package com.societyapp.repository;

import com.societyapp.entity.MemberChargeSetting;
import java.util.*;

public interface MemberChargeSettingRepository
        extends CrudRepositoryPort<MemberChargeSetting, UUID> {
    List<MemberChargeSetting> findBySocietyIdOrderByName(UUID societyId);
}
