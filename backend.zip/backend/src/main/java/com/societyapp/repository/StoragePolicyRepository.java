package com.societyapp.repository;

import com.societyapp.entity.StoragePolicy;

public interface StoragePolicyRepository extends CrudRepositoryPort<StoragePolicy, Short> {}
