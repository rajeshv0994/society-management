package com.societyapp.repository;

import com.societyapp.entity.RazorpayWebhookEvent;

public interface RazorpayWebhookEventRepository
        extends CrudRepositoryPort<RazorpayWebhookEvent, String> {
    int claim(String eventId, String eventType);

    void markProcessed(String eventId);
}
