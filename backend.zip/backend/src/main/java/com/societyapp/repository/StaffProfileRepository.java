package com.societyapp.repository;

import com.societyapp.entity.StaffProfile;
import java.util.UUID;

public interface StaffProfileRepository extends CrudRepositoryPort<StaffProfile, UUID> {}
