package com.societyapp.repository;

import com.societyapp.entity.StaffTask;
import java.util.*;

public interface StaffTaskRepository extends CrudRepositoryPort<StaffTask, UUID> {
    List<StaffTask> findBySocietyIdOrderByCreatedAtDesc(UUID societyId);

    Optional<StaffTask> findByIdAndSocietyId(UUID id, UUID societyId);
}
