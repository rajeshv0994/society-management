package com.societyapp.repository;

import com.societyapp.entity.SocietyExpense;
import java.util.*;

public interface SocietyExpenseRepository extends CrudRepositoryPort<SocietyExpense, UUID> {
    List<SocietyExpense> findBySocietyIdOrderByExpenseDateDescCreatedAtDesc(UUID societyId);
}
