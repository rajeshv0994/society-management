package com.societyapp.repository;

import com.societyapp.application.model.SocietyProfileUpdate;
import java.util.Map;
import java.util.UUID;

public interface SocietyProfileStore {
    Map<String, Object> findById(UUID id);

    void update(UUID id, SocietyProfileUpdate update);

    boolean exists(UUID id);

    void updateLogo(UUID id, String storageKey, String contentType);

    Map<String, Object> findLogo(UUID id);
}
