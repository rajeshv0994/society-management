package com.societyapp.repository;

import com.societyapp.entity.EmergencyIncidentEvent;
import java.util.*;

public interface EmergencyIncidentEventRepository
        extends CrudRepositoryPort<EmergencyIncidentEvent, UUID> {
    List<EmergencyIncidentEvent> findByIncidentIdOrderByOccurredAt(UUID incidentId);
}
