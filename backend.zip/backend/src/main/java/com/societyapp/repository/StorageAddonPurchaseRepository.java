package com.societyapp.repository;

import com.societyapp.entity.StorageAddonPurchase;
import java.util.*;

public interface StorageAddonPurchaseRepository
        extends CrudRepositoryPort<StorageAddonPurchase, UUID> {
    List<StorageAddonPurchase> findBySocietyIdOrderByCreatedAtDesc(UUID societyId);

    List<StorageAddonPurchase> findBySocietyIdAndStatus(UUID societyId, String status);
}
