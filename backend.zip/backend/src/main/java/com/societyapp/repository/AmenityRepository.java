package com.societyapp.repository;

import com.societyapp.entity.Amenity;
import java.util.*;

public interface AmenityRepository extends CrudRepositoryPort<Amenity, UUID> {
    List<Amenity> findBySocietyIdOrderByName(UUID societyId);

    Optional<Amenity> findByIdAndSocietyId(UUID id, UUID societyId);
}
