package com.societyapp.repository;

import com.societyapp.entity.SocietyPaymentSetting;
import java.util.*;

public interface SocietyPaymentSettingRepository
        extends CrudRepositoryPort<SocietyPaymentSetting, UUID> {
    Optional<SocietyPaymentSetting> findBySocietyId(UUID societyId);
}
