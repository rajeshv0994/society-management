package com.societyapp.repository;

import com.societyapp.entity.SubscriptionPlan;

public interface SubscriptionPlanRepository extends CrudRepositoryPort<SubscriptionPlan, String> {}
