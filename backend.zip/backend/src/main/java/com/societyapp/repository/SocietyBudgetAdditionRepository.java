package com.societyapp.repository;

import com.societyapp.entity.SocietyBudgetAddition;
import java.util.*;

public interface SocietyBudgetAdditionRepository
        extends CrudRepositoryPort<SocietyBudgetAddition, UUID> {
    List<SocietyBudgetAddition> findBySocietyIdAndBudgetYearOrderByAddedAtDesc(
            UUID societyId, int budgetYear);
}
