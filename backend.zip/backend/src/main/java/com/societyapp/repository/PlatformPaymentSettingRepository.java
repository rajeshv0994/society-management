package com.societyapp.repository;

import com.societyapp.entity.PlatformPaymentSetting;
import java.util.*;

public interface PlatformPaymentSettingRepository
        extends CrudRepositoryPort<PlatformPaymentSetting, UUID> {
    Optional<PlatformPaymentSetting> findFirstByOrderByUpdatedAtDesc();
}
