package com.societyapp.repository;

import com.societyapp.entity.*;
import java.util.*;

public interface NoticeReadRepository extends CrudRepositoryPort<NoticeRead, NoticeReadId> {
    Optional<NoticeRead> findByNoticeIdAndUserId(UUID noticeId, UUID userId);

    long countByNoticeId(UUID noticeId);

    long countByNoticeIdAndAcknowledgedAtIsNotNull(UUID noticeId);
}
