package com.societyapp.repository;

import com.societyapp.entity.ActivityGalleryPhoto;
import java.util.*;

public interface ActivityGalleryPhotoRepository
        extends CrudRepositoryPort<ActivityGalleryPhoto, UUID> {
    List<ActivityGalleryPhoto> findBySocietyIdOrderByCreatedAtDesc(UUID societyId);

    List<ActivityGalleryPhoto> findByActivityIdOrderByFeaturedDescCreatedAtDesc(UUID activityId);

    Optional<ActivityGalleryPhoto> findByIdAndSocietyId(UUID id, UUID societyId);

    long countBySocietyIdAndModerationStatus(UUID societyId, String status);
}
