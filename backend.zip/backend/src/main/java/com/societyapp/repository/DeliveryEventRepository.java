package com.societyapp.repository;

import com.societyapp.entity.DeliveryEvent;
import java.util.*;

public interface DeliveryEventRepository extends CrudRepositoryPort<DeliveryEvent, UUID> {
    List<DeliveryEvent> findByDeliveryIdOrderByOccurredAt(UUID deliveryId);
}
