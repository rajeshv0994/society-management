package com.societyapp.repository;

import com.societyapp.entity.ActivityEvent;
import java.util.*;

public interface ActivityEventRepository extends CrudRepositoryPort<ActivityEvent, UUID> {
    List<ActivityEvent> findByActivityIdOrderByOccurredAt(UUID activityId);
}
