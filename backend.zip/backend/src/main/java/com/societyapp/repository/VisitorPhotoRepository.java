package com.societyapp.repository;

import com.societyapp.entity.VisitorPhoto;
import java.util.*;

public interface VisitorPhotoRepository extends CrudRepositoryPort<VisitorPhoto, UUID> {
    List<VisitorPhoto> findByVisitorIdOrderByCreatedAt(UUID visitorId);

    long countByVisitorId(UUID visitorId);
}
