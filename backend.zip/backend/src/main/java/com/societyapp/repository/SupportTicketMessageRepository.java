package com.societyapp.repository;

import com.societyapp.entity.SupportTicketMessage;
import java.util.*;

public interface SupportTicketMessageRepository
        extends CrudRepositoryPort<SupportTicketMessage, UUID> {
    List<SupportTicketMessage> findByTicketIdOrderByCreatedAt(UUID ticketId);
}
