package com.societyapp.repository;

import com.societyapp.entity.StaffTaskUpdate;
import java.util.*;

public interface StaffTaskUpdateRepository extends CrudRepositoryPort<StaffTaskUpdate, UUID> {
    List<StaffTaskUpdate> findByTaskIdOrderByCreatedAt(UUID taskId);
}
