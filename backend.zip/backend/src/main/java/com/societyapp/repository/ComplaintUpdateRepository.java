package com.societyapp.repository;

import com.societyapp.entity.ComplaintUpdate;
import java.util.*;

public interface ComplaintUpdateRepository extends CrudRepositoryPort<ComplaintUpdate, UUID> {
    List<ComplaintUpdate> findByComplaintIdOrderByCreatedAt(UUID complaintId);
}
