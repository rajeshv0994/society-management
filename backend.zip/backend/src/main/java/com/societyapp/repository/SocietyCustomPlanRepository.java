package com.societyapp.repository;

import com.societyapp.entity.SocietyCustomPlan;
import java.util.*;

public interface SocietyCustomPlanRepository extends CrudRepositoryPort<SocietyCustomPlan, UUID> {
    List<SocietyCustomPlan> findAllByOrderByCreatedAtDesc();
}
