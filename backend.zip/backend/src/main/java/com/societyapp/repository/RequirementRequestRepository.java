package com.societyapp.repository;

import com.societyapp.entity.RequirementRequest;
import java.util.*;

public interface RequirementRequestRepository extends CrudRepositoryPort<RequirementRequest, UUID> {
    List<RequirementRequest> findAllByOrderByCreatedAtDesc();

    List<RequirementRequest> findBySocietyIdOrderByCreatedAtDesc(UUID societyId);
}
