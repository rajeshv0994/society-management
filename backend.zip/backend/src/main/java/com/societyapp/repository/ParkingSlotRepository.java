package com.societyapp.repository;

import com.societyapp.entity.ParkingSlot;
import java.util.*;

public interface ParkingSlotRepository extends CrudRepositoryPort<ParkingSlot, UUID> {
    List<ParkingSlot> findBySocietyIdOrderBySlotNumber(UUID societyId);

    Optional<ParkingSlot> findByIdAndSocietyId(UUID id, UUID societyId);

    boolean existsBySocietyIdAndSlotNumberIgnoreCase(UUID societyId, String slotNumber);

    boolean existsBySocietyIdAndSlotNumberIgnoreCaseAndIdNot(
            UUID societyId, String slotNumber, UUID id);
}
