package com.societyapp.repository;

import com.societyapp.entity.EmergencyDirectoryContact;
import java.util.*;

public interface EmergencyDirectoryContactRepository
        extends CrudRepositoryPort<EmergencyDirectoryContact, UUID> {
    List<EmergencyDirectoryContact> findBySocietyIdAndActiveTrueOrderByContactTypeAscPriorityAsc(
            UUID societyId);

    Optional<EmergencyDirectoryContact> findByIdAndSocietyId(UUID id, UUID societyId);
}
