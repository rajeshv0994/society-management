package com.societyapp.repository;

import com.societyapp.entity.HouseholdEmergencyContact;
import java.util.*;

public interface HouseholdEmergencyContactRepository
        extends CrudRepositoryPort<HouseholdEmergencyContact, UUID> {
    List<HouseholdEmergencyContact> findBySocietyIdAndPrimaryResidentIdAndActiveTrueOrderByPriority(
            UUID societyId, UUID primaryResidentId);

    Optional<HouseholdEmergencyContact> findByIdAndSocietyIdAndPrimaryResidentId(
            UUID id, UUID societyId, UUID primaryResidentId);

    long countBySocietyIdAndActiveTrue(UUID societyId);
}
