package com.societyapp.repository;

import com.societyapp.entity.Notice;
import java.util.*;

public interface NoticeRepository extends CrudRepositoryPort<Notice, UUID> {
    List<Notice> findBySocietyIdOrderByPublishedAtDesc(UUID societyId);
}
