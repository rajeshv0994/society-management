package com.societyapp.repository;

import com.societyapp.entity.ResidentRegistration;
import java.util.*;

public interface ResidentRegistrationRepository
        extends CrudRepositoryPort<ResidentRegistration, UUID> {
    List<ResidentRegistration> findBySocietyIdOrderBySubmittedAtDesc(UUID societyId);

    List<ResidentRegistration> findBySocietyIdAndStatusOrderBySubmittedAtDesc(
            UUID societyId, String status);

    Optional<ResidentRegistration> findByIdAndSocietyId(UUID id, UUID societyId);
}
