package com.societyapp.repository;

import com.societyapp.entity.*;
import java.util.*;

public interface StaffPermissionRepository
        extends CrudRepositoryPort<StaffPermission, StaffPermissionId> {
    List<StaffPermission> findByStaffUserId(UUID staffUserId);

    boolean existsByStaffUserIdAndPermissionCode(UUID staffUserId, String permissionCode);

    void deleteByStaffUserId(UUID staffUserId);
}
