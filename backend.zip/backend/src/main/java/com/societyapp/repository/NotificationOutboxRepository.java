package com.societyapp.repository;

import com.societyapp.entity.NotificationOutbox;
import java.util.*;

public interface NotificationOutboxRepository extends CrudRepositoryPort<NotificationOutbox, UUID> {
    List<NotificationOutbox> findAllByOrderByCreatedAtDesc();

    List<NotificationOutbox> findBySocietyIdOrderByCreatedAtDesc(UUID societyId);
}
