package com.societyapp.repository;

import com.societyapp.entity.PlatformServiceModule;
import java.util.List;

public interface PlatformServiceModuleRepository
        extends CrudRepositoryPort<PlatformServiceModule, String> {
    List<PlatformServiceModule> findAllByOrderBySortOrderAscNameAsc();

    List<PlatformServiceModule> findByStatusOrderBySortOrderAscNameAsc(String status);
}
