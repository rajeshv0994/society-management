package com.societyapp.repository;

import com.societyapp.entity.Flat;
import java.util.List;
import java.util.UUID;

public interface FlatRepository extends CrudRepositoryPort<Flat, UUID> {
    List<Flat> findByFloorIdOrderByFlatNumber(UUID floorId);
}
