package com.societyapp.repository;

import com.societyapp.entity.SetupCode;
import java.util.*;

public interface SetupCodeRepository extends CrudRepositoryPort<SetupCode, UUID> {
    List<SetupCode> findByStatusOrderByCreatedAtDesc(String status);
}
