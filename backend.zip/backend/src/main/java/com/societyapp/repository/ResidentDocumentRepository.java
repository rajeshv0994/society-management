package com.societyapp.repository;

import com.societyapp.entity.ResidentDocument;
import java.util.*;

public interface ResidentDocumentRepository extends CrudRepositoryPort<ResidentDocument, UUID> {
    List<ResidentDocument> findByRegistrationId(UUID registrationId);
}
