package com.societyapp.repository;

import com.societyapp.entity.SocietyBudget;
import java.util.*;

public interface SocietyBudgetRepository extends CrudRepositoryPort<SocietyBudget, UUID> {
    Optional<SocietyBudget> findBySocietyIdAndBudgetYear(UUID societyId, int budgetYear);
}
