package com.societyapp.repository;

import com.societyapp.entity.VerificationChallenge;
import java.util.UUID;

public interface VerificationChallengeRepository
        extends CrudRepositoryPort<VerificationChallenge, UUID> {}
