package com.societyapp.repository;

import com.societyapp.entity.StaffAttendance;
import java.time.LocalDate;
import java.util.*;

public interface StaffAttendanceRepository extends CrudRepositoryPort<StaffAttendance, UUID> {
    List<StaffAttendance> findByStaffUserIdOrderByAttendanceDateDesc(UUID staffUserId);

    Optional<StaffAttendance> findByStaffUserIdAndAttendanceDate(UUID staffUserId, LocalDate date);
}
