package com.societyapp.repository;

import com.societyapp.entity.SupportTicket;
import java.util.*;

public interface SupportTicketRepository extends CrudRepositoryPort<SupportTicket, UUID> {
    List<SupportTicket> findAllByOrderByCreatedAtDesc();

    List<SupportTicket> findBySocietyIdOrderByCreatedAtDesc(UUID societyId);

    Optional<SupportTicket> findByIdAndSocietyId(UUID id, UUID societyId);
}
