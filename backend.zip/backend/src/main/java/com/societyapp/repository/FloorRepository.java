package com.societyapp.repository;

import com.societyapp.entity.Floor;
import java.util.List;
import java.util.UUID;

public interface FloorRepository extends CrudRepositoryPort<Floor, UUID> {
    List<Floor> findByBlockIdOrderByFloorNumber(UUID blockId);
}
