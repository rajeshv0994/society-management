package com.societyapp.repository;

import com.societyapp.entity.Delivery;
import java.util.*;

public interface DeliveryRepository extends CrudRepositoryPort<Delivery, UUID> {
    List<Delivery> findBySocietyIdOrderByCreatedAtDesc(UUID societyId);

    List<Delivery> findBySocietyIdAndResidentIdOrderByCreatedAtDesc(
            UUID societyId, UUID residentId);

    Optional<Delivery> findByIdAndSocietyId(UUID id, UUID societyId);

    long countBySocietyId(UUID societyId);

    long countBySocietyIdAndStatusIn(UUID societyId, Collection<String> statuses);
}
