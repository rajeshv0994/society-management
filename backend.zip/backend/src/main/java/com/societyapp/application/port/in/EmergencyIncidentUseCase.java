package com.societyapp.application.port.in;

public interface EmergencyIncidentUseCase {
    java.util.Map<java.lang.String, java.lang.Object> workspace(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> history(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, java.util.UUID arg3);

    java.util.Map<java.lang.String, java.lang.Object> create(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.util.UUID arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7,
            java.lang.String arg8,
            java.lang.String arg9,
            java.math.BigDecimal arg10,
            java.math.BigDecimal arg11,
            int arg12,
            java.lang.String arg13,
            java.lang.String arg14,
            java.lang.String arg15);

    java.util.Map<java.lang.String, java.lang.Object> action(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.util.UUID arg6,
            java.lang.String arg7,
            java.lang.String arg8,
            java.lang.String arg9);

    java.util.Map<java.lang.String, java.lang.Object> saveDirectory(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7,
            java.lang.String arg8,
            boolean arg9,
            int arg10);

    void removeDirectory(java.util.UUID arg0, java.lang.String arg1, java.util.UUID arg2);
}
