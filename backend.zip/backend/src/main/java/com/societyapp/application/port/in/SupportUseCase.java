package com.societyapp.application.port.in;

public interface SupportUseCase {
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> tickets(java.util.UUID arg0);

    java.util.Map<java.lang.String, java.lang.Object> create(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> messages(
            java.util.UUID arg0, java.util.UUID arg1, java.util.UUID arg2, java.lang.String arg3);

    java.util.Map<java.lang.String, java.lang.Object> send(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.util.UUID arg2,
            java.lang.String arg3,
            java.lang.String arg4);
}
