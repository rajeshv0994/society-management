package com.societyapp.application.port.in;

public interface SocietyOnboardingUseCase {
    record Registration(
            String name,
            String societyType,
            int totalBlocks,
            int totalFlats,
            int plannedStaff,
            Integer approximateResidents,
            String address,
            String city,
            String state,
            String pinCode,
            String contactPerson,
            String email,
            String mobile,
            String planCode,
            java.util.List<String> enabledModules) {}

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> plans();

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> services();

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> activeSocieties();

    java.util.Map<java.lang.String, java.lang.Object> register(
            SocietyOnboardingUseCase.Registration arg0);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> pending();

    java.util.Map<java.lang.String, java.lang.Object> approve(java.util.UUID arg0);

    java.util.Map<java.lang.String, java.lang.Object> reject(
            java.util.UUID arg0, java.lang.String arg1);

    java.util.Map<java.lang.String, java.lang.Object> activate(
            java.lang.String arg0,
            java.lang.String arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4);
}
