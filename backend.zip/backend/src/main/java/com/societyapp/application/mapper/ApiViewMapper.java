package com.societyapp.application.mapper;

import com.societyapp.application.port.out.JsonCodec;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class ApiViewMapper {
    private final JsonCodec mapper;

    public ApiViewMapper(JsonCodec mapper) {
        this.mapper = mapper;
    }

    public Map<String, Object> toMap(Object value) {
        Map<String, Object> source = mapper.toMap(value);
        var result = new LinkedHashMap<String, Object>();
        source.forEach((key, item) -> result.put(toSnakeCase(key), item));
        addUnitAliases(result);
        return result;
    }

    private void addUnitAliases(Map<String, Object> result) {
        addAlias(result, "flat_id", "unit_id");
        addAlias(result, "flat_id", "space_id");
        addAlias(result, "flat_number", "unit_number");
        addAlias(result, "flat_number", "space_number");
        addAlias(result, "floor_id", "section_id");
        addAlias(result, "floor_number", "section_order");
        addAlias(result, "total_flats", "total_units");
        addAlias(result, "total_flats", "total_spaces");
        addAlias(result, "max_flats", "max_units");
        addAlias(result, "max_flats", "max_spaces");
        addAlias(result, "estimated_flats", "estimated_units");
        addAlias(result, "estimated_flats", "estimated_spaces");
        addAlias(result, "configured_flat_count", "configured_unit_count");
        addAlias(result, "configured_flat_count", "configured_space_count");
    }

    private void addAlias(Map<String, Object> result, String legacyKey, String unitKey) {
        if (result.containsKey(legacyKey)) {
            result.putIfAbsent(unitKey, result.get(legacyKey));
        }
    }

    private String toSnakeCase(String value) {
        return value.replaceAll("([a-z0-9])([A-Z])", "$1_$2").toLowerCase(Locale.ROOT);
    }
}
