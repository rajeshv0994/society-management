package com.societyapp.application.port.in;

public interface VisitorUseCase {
    record PhotoContent(
            com.societyapp.application.model.BinaryContent content, String contentType) {}

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> list(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.Map<java.lang.String, java.lang.Object> permissions(
            java.util.UUID arg0, java.lang.String arg1);

    java.util.Map<java.lang.String, java.lang.Object> memberOptions(
            java.util.UUID arg0, java.util.UUID arg1);

    void requireGate(java.util.UUID arg0, java.lang.String arg1);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> hosts(java.util.UUID arg0);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> targets(java.util.UUID arg0);

    java.util.Map<java.lang.String, java.lang.Object> create(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.util.UUID arg4,
            java.lang.String arg5,
            java.util.UUID arg6,
            java.lang.String arg7,
            java.lang.String arg8,
            java.lang.String arg9,
            java.lang.String arg10,
            java.lang.String arg11,
            java.time.OffsetDateTime arg12,
            int arg13);

    java.util.Map<java.lang.String, java.lang.Object> uploadPhoto(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            com.societyapp.application.port.out.UploadedFile arg4);

    VisitorUseCase.PhotoContent photo(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, java.util.UUID arg3);

    java.util.Map<java.lang.String, java.lang.Object> residentDecision(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.util.UUID arg2,
            java.lang.String arg3,
            java.lang.String arg4);

    java.util.Map<java.lang.String, java.lang.Object> residentCancel(
            java.util.UUID arg0, java.util.UUID arg1, java.util.UUID arg2, java.lang.String arg3);

    java.util.Map<java.lang.String, java.lang.Object> staffApproval(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4);

    java.util.Map<java.lang.String, java.lang.Object> targetStaffDecision(
            java.util.UUID arg0, java.util.UUID arg1, java.util.UUID arg2, java.lang.String arg3);

    java.util.Map<java.lang.String, java.lang.Object> updateStatus(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4);
}
