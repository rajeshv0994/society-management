package com.societyapp.application.port.in;

public interface StructureUseCase {
    java.util.Map<java.lang.String, java.lang.Object> get(java.util.UUID arg0);

    java.util.Map<java.lang.String, java.lang.Object> addBlock(
            java.util.UUID arg0, java.lang.String arg1);

    java.util.Map<java.lang.String, java.lang.Object> updateBlock(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.Map<java.lang.String, java.lang.Object> deleteBlock(
            java.util.UUID arg0, java.util.UUID arg1);

    java.util.Map<java.lang.String, java.lang.Object> addFloor(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, int arg3);

    java.util.Map<java.lang.String, java.lang.Object> updateFloor(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, int arg3);

    java.util.Map<java.lang.String, java.lang.Object> deleteFloor(
            java.util.UUID arg0, java.util.UUID arg1);

    java.util.Map<java.lang.String, java.lang.Object> addFlat(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.math.BigDecimal arg3);

    java.util.Map<java.lang.String, java.lang.Object> addSpace(
            java.util.UUID arg0, java.lang.String arg1, java.math.BigDecimal arg2);

    java.util.Map<java.lang.String, java.lang.Object> updateFlat(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.math.BigDecimal arg3);

    java.util.Map<java.lang.String, java.lang.Object> deleteFlat(
            java.util.UUID arg0, java.util.UUID arg1);
}
