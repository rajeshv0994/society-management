package com.societyapp.application.port.in;

public interface DeliveryUseCase {
    java.util.Map<java.lang.String, java.lang.Object> workspace(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> history(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, java.util.UUID arg3);

    java.util.Map<java.lang.String, java.lang.Object> create(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.util.UUID arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7,
            java.lang.String arg8,
            java.lang.String arg9,
            java.lang.String arg10,
            int arg11,
            java.lang.String arg12,
            boolean arg13,
            java.lang.String arg14,
            java.time.OffsetDateTime arg15,
            java.lang.String arg16,
            java.math.BigDecimal arg17,
            boolean arg18);

    java.util.Map<java.lang.String, java.lang.Object> action(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7);

    java.util.Map<java.lang.String, java.lang.Object> checkout(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4);

    java.util.Map<java.lang.String, java.lang.Object> recordCod(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4);
}
