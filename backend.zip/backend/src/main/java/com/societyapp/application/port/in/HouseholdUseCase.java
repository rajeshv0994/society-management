package com.societyapp.application.port.in;

public interface HouseholdUseCase {
    java.util.Map<java.lang.String, java.lang.Object> profile(
            java.util.UUID arg0, java.util.UUID arg1);

    java.util.Map<java.lang.String, java.lang.Object> workspace(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.Map<java.lang.String, java.lang.Object> add(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.time.LocalDate arg5);

    java.util.Map<java.lang.String, java.lang.Object> addMember(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7,
            java.time.LocalDate arg8,
            java.lang.String arg9,
            java.lang.String arg10,
            java.lang.String arg11,
            java.lang.String arg12,
            java.lang.String arg13,
            java.lang.String arg14,
            java.lang.String arg15,
            java.lang.Boolean arg16);

    java.util.Map<java.lang.String, java.lang.Object> updateMember(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.util.UUID arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7,
            java.lang.String arg8,
            java.time.LocalDate arg9,
            java.lang.String arg10,
            java.lang.String arg11,
            java.lang.String arg12,
            java.lang.String arg13,
            java.lang.String arg14,
            java.lang.String arg15,
            java.lang.String arg16,
            java.lang.Boolean arg17);

    java.util.Map<java.lang.String, java.lang.Object> reviewMember(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.util.UUID arg4,
            java.lang.String arg5,
            java.lang.String arg6);

    java.util.Map<java.lang.String, java.lang.Object> remove(
            java.util.UUID arg0, java.util.UUID arg1, java.util.UUID arg2);

    java.util.Map<java.lang.String, java.lang.Object> removeMember(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.util.UUID arg4);

    java.util.Map<java.lang.String, java.lang.Object> addVehicle(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7,
            java.lang.String arg8,
            java.lang.String arg9,
            java.lang.String arg10);

    java.util.Map<java.lang.String, java.lang.Object> updateVehicle(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.util.UUID arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7,
            java.lang.String arg8,
            java.lang.String arg9,
            java.lang.String arg10,
            java.lang.String arg11);

    java.util.Map<java.lang.String, java.lang.Object> reviewVehicle(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.util.UUID arg4,
            java.lang.String arg5,
            java.lang.String arg6);

    java.util.Map<java.lang.String, java.lang.Object> removeVehicle(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.util.UUID arg4);

    java.util.Map<java.lang.String, java.lang.Object> addContact(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7,
            int arg8);

    java.util.Map<java.lang.String, java.lang.Object> updateContact(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.util.UUID arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7,
            java.lang.String arg8,
            int arg9);

    java.util.Map<java.lang.String, java.lang.Object> removeContact(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.util.UUID arg4);
}
