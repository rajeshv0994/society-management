package com.societyapp.application.port.in;

public interface DashboardUseCase {
    java.util.Map<java.lang.String, java.lang.Object> platform();

    java.util.Map<java.lang.String, java.lang.Object> society(java.util.UUID arg0);
}
