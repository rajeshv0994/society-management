package com.societyapp.application.port.in;

public interface ActivityUseCase {
    record PhotoContent(
            com.societyapp.application.model.BinaryContent content, String contentType) {}

    java.util.Map<java.lang.String, java.lang.Object> workspace(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.Map<java.lang.String, java.lang.Object> create(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.time.OffsetDateTime arg7,
            java.time.OffsetDateTime arg8,
            java.time.OffsetDateTime arg9,
            java.time.OffsetDateTime arg10,
            java.lang.Integer arg11,
            java.math.BigDecimal arg12,
            boolean arg13,
            int arg14,
            java.lang.String arg15,
            java.lang.String arg16,
            java.lang.String arg17,
            java.lang.String arg18,
            boolean arg19);

    java.util.Map<java.lang.String, java.lang.Object> update(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7,
            java.time.OffsetDateTime arg8,
            java.time.OffsetDateTime arg9,
            java.time.OffsetDateTime arg10,
            java.time.OffsetDateTime arg11,
            java.lang.Integer arg12,
            java.math.BigDecimal arg13,
            boolean arg14,
            int arg15,
            java.lang.String arg16,
            java.lang.String arg17,
            java.lang.String arg18,
            java.lang.String arg19);

    java.util.Map<java.lang.String, java.lang.Object> activityAction(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4,
            java.lang.String arg5);

    java.util.Map<java.lang.String, java.lang.Object> join(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            int arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7);

    java.util.Map<java.lang.String, java.lang.Object> checkout(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4);

    java.util.Map<java.lang.String, java.lang.Object> recordCash(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, java.util.UUID arg3);

    java.util.Map<java.lang.String, java.lang.Object> participationAction(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4,
            java.lang.String arg5);

    java.util.Map<java.lang.String, java.lang.Object> uploadPhoto(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4,
            com.societyapp.application.port.out.UploadedFile arg5);

    ActivityUseCase.PhotoContent photo(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, java.util.UUID arg3);

    java.util.Map<java.lang.String, java.lang.Object> photoAction(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4,
            java.lang.String arg5);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> history(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, java.util.UUID arg3);
}
