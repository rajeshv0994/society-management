package com.societyapp.application.port.in;

public interface RequirementUseCase {
    java.util.Map<java.lang.String, java.lang.Object> submit(
            java.util.UUID arg0,
            java.lang.String arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.Integer arg6,
            java.lang.Integer arg7,
            java.util.List<java.lang.String> arg8,
            java.lang.String arg9,
            java.math.BigDecimal arg10);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> list();

    java.util.Map<java.lang.String, java.lang.Object> review(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, java.lang.String arg3);

    java.util.Map<java.lang.String, java.lang.Object> createPlan(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.util.UUID arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.util.List<java.lang.String> arg5,
            java.lang.Integer arg6,
            java.lang.Integer arg7,
            java.lang.Integer arg8,
            java.math.BigDecimal arg9,
            java.math.BigDecimal arg10,
            java.math.BigDecimal arg11,
            java.math.BigDecimal arg12,
            java.lang.String arg13,
            java.time.LocalDate arg14,
            java.time.LocalDate arg15,
            java.lang.String arg16);

    java.util.Map<java.lang.String, java.lang.Object> updatePlan(
            java.util.UUID arg0,
            java.lang.String arg1,
            java.lang.String arg2,
            java.util.List<java.lang.String> arg3,
            java.lang.Integer arg4,
            java.lang.Integer arg5,
            java.lang.Integer arg6,
            java.math.BigDecimal arg7,
            java.math.BigDecimal arg8,
            java.math.BigDecimal arg9,
            java.math.BigDecimal arg10,
            java.lang.String arg11,
            java.time.LocalDate arg12,
            java.time.LocalDate arg13,
            java.lang.String arg14);

    java.util.Map<java.lang.String, java.lang.Object> cancelPlan(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> plans();
}
