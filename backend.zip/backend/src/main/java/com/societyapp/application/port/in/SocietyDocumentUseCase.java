package com.societyapp.application.port.in;

public interface SocietyDocumentUseCase {
    java.util.Map<java.lang.String, java.lang.Object> upload(
            java.util.UUID arg0,
            java.lang.String arg1,
            java.lang.String arg2,
            com.societyapp.application.port.out.UploadedFile arg3);

    java.util.Map<java.lang.String, java.lang.Object> uploadAuthenticated(
            java.util.UUID arg0,
            java.lang.String arg1,
            com.societyapp.application.port.out.UploadedFile arg2);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> list(java.util.UUID arg0);

    java.util.Map<java.lang.String, java.lang.Object> verify(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);
}
