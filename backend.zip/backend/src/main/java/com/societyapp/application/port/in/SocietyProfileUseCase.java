package com.societyapp.application.port.in;

public interface SocietyProfileUseCase {
    record LogoContent(
            com.societyapp.application.model.BinaryContent content, String contentType) {}

    java.util.Map<java.lang.String, java.lang.Object> get(java.util.UUID arg0);

    java.util.Map<java.lang.String, java.lang.Object> update(
            java.util.UUID arg0, com.societyapp.application.model.SocietyProfileUpdate arg1);

    java.util.Map<java.lang.String, java.lang.Object> uploadLogo(
            java.util.UUID arg0, com.societyapp.application.port.out.UploadedFile arg1);

    SocietyProfileUseCase.LogoContent getLogo(java.util.UUID arg0);
}
