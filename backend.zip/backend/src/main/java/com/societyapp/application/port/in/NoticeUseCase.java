package com.societyapp.application.port.in;

public interface NoticeUseCase {
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> list(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.Map<java.lang.String, java.lang.Object> options(
            java.util.UUID arg0, java.lang.String arg1);

    java.util.Map<java.lang.String, java.lang.Object> create(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            boolean arg7,
            boolean arg8,
            java.lang.String arg9,
            java.time.OffsetDateTime arg10);

    java.util.Map<java.lang.String, java.lang.Object> update(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7,
            boolean arg8,
            boolean arg9,
            java.lang.String arg10,
            java.time.OffsetDateTime arg11);

    java.util.Map<java.lang.String, java.lang.Object> markRead(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, java.util.UUID arg3);

    java.util.Map<java.lang.String, java.lang.Object> acknowledge(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, java.util.UUID arg3);
}
