package com.societyapp.application.port.in;

import com.societyapp.entity.Flat;
import java.util.UUID;

public interface StructureAccessUseCase {
    boolean belongsToSociety(UUID flatId, UUID societyId);

    boolean occupiedBy(UUID flatId, UUID userId);

    Flat requireFlat(UUID flatId, UUID societyId);
}
