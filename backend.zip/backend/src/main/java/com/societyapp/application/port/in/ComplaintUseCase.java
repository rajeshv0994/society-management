package com.societyapp.application.port.in;

public interface ComplaintUseCase {
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> list(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.Map<java.lang.String, java.lang.Object> options(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.Map<java.lang.String, java.lang.Object> detail(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, java.util.UUID arg3);

    java.util.Map<java.lang.String, java.lang.Object> create(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.util.UUID arg4,
            java.util.UUID arg5,
            java.util.UUID arg6,
            java.lang.String arg7,
            java.lang.String arg8,
            java.lang.String arg9);

    java.util.Map<java.lang.String, java.lang.Object> update(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4,
            java.util.UUID arg5,
            java.lang.String arg6,
            java.lang.String arg7);

    java.util.Map<java.lang.String, java.lang.Object> comment(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4);
}
