package com.societyapp.application.port.in;

public interface StaffUseCase {
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> list(java.util.UUID arg0);

    java.util.Map<java.lang.String, java.lang.Object> detail(
            java.util.UUID arg0, java.util.UUID arg1);

    java.util.Map<java.lang.String, java.lang.Object> updateEmployment(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.time.LocalDate arg2,
            java.time.LocalDate arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7,
            java.lang.String arg8,
            java.lang.String arg9,
            java.lang.String arg10,
            java.math.BigDecimal arg11,
            java.lang.String arg12,
            java.lang.String arg13,
            java.lang.String arg14,
            java.lang.String arg15);

    java.util.Map<java.lang.String, java.lang.Object> markAttendance(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.util.UUID arg2,
            java.time.LocalDate arg3,
            java.lang.String arg4,
            java.time.LocalTime arg5,
            java.time.LocalTime arg6,
            java.lang.String arg7);

    java.util.Map<java.lang.String, java.lang.Object> ownAttendance(
            java.util.UUID arg0, java.util.UUID arg1);

    java.util.Map<java.lang.String, java.lang.Object> clockIn(
            java.util.UUID arg0, java.util.UUID arg1);

    java.util.Map<java.lang.String, java.lang.Object> clockOut(
            java.util.UUID arg0, java.util.UUID arg1);

    java.util.Map<java.lang.String, java.lang.Object> recordSalaryPayment(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.util.UUID arg2,
            java.time.LocalDate arg3,
            java.math.BigDecimal arg4,
            java.time.LocalDate arg5,
            java.lang.String arg6,
            java.lang.String arg7,
            java.lang.String arg8);

    java.util.Map<java.lang.String, java.lang.Object> create(
            java.util.UUID arg0,
            java.lang.String arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7,
            java.lang.String arg8);

    java.util.Map<java.lang.String, java.lang.Object> update(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7,
            java.lang.String arg8);

    java.util.Map<java.lang.String, java.lang.Object> setStatus(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.Map<java.lang.String, java.lang.Object> resetPassword(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.Map<java.lang.String, java.lang.Object> setPermissions(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.util.UUID arg2,
            java.util.Set<java.lang.String> arg3);
}
