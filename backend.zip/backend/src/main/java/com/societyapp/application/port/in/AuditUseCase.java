package com.societyapp.application.port.in;

public interface AuditUseCase {
    void record(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.util.Map<java.lang.String, ?> arg5);

    void record(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            boolean arg5,
            java.util.Map<java.lang.String, ?> arg6);

    java.util.Map<java.lang.String, java.lang.Object> search(
            int arg0,
            int arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.util.UUID arg4,
            java.util.UUID arg5,
            java.time.OffsetDateTime arg6,
            java.time.OffsetDateTime arg7,
            java.lang.String arg8);

    java.util.Map<java.lang.String, java.lang.Object> search(
            int arg0,
            int arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.util.UUID arg4,
            java.util.UUID arg5,
            java.time.OffsetDateTime arg6,
            java.time.OffsetDateTime arg7,
            java.lang.String arg8,
            java.lang.Boolean arg9);
}
