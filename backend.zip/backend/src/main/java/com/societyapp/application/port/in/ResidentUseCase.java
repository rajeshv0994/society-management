package com.societyapp.application.port.in;

public interface ResidentUseCase {
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> flats(java.util.UUID arg0);

    java.util.Map<java.lang.String, java.lang.Object> register(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.time.LocalDate arg6,
            java.lang.String arg7,
            java.lang.String arg8,
            java.time.LocalDate arg9,
            java.time.LocalDate arg10);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> pending(java.util.UUID arg0);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> residents(
            java.util.UUID arg0);

    java.util.Map<java.lang.String, java.lang.Object> createResident(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.util.UUID arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.time.LocalDate arg7,
            java.lang.String arg8,
            java.lang.String arg9,
            java.time.LocalDate arg10,
            java.time.LocalDate arg11,
            java.lang.String arg12);

    java.util.Map<java.lang.String, java.lang.Object> resident(
            java.util.UUID arg0, java.util.UUID arg1);

    java.util.Map<java.lang.String, java.lang.Object> addHouseholdMember(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.time.LocalDate arg5);

    java.util.Map<java.lang.String, java.lang.Object> removeHouseholdMember(
            java.util.UUID arg0, java.util.UUID arg1, java.util.UUID arg2);

    java.util.Map<java.lang.String, java.lang.Object> review(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.util.UUID arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.lang.String arg5);
}
