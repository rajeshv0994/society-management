package com.societyapp.application.port.in;

public interface PlatformAdminUseCase {
    record CreateSociety(
            String name,
            String societyType,
            int totalBlocks,
            int totalFlats,
            int plannedStaff,
            String address,
            String city,
            String state,
            String pinCode,
            String contactPerson,
            String email,
            String mobile,
            String planCode,
            java.util.List<String> enabledModules) {}

    record UpdateSociety(
            String name,
            String description,
            String website,
            String contactPerson,
            String email,
            String mobile,
            String address,
            String city,
            String state,
            String pinCode,
            String planCode,
            int plannedStaff,
            String status,
            java.util.List<String> enabledModules) {}

    java.util.Map<java.lang.String, java.lang.Object> dashboard();

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> societies(
            java.lang.String arg0, java.lang.String arg1);

    java.util.Map<java.lang.String, java.lang.Object> createSociety(
            java.util.UUID arg0, PlatformAdminUseCase.CreateSociety arg1);

    java.util.Map<java.lang.String, java.lang.Object> society(java.util.UUID arg0);

    java.util.Map<java.lang.String, java.lang.Object> updateSociety(
            java.util.UUID arg0, java.util.UUID arg1, PlatformAdminUseCase.UpdateSociety arg2);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> plans();

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> services();

    java.util.Map<java.lang.String, java.lang.Object> createService(
            java.util.UUID arg0,
            java.lang.String arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            int arg5,
            java.lang.String arg6,
            java.math.BigDecimal arg7);

    java.util.Map<java.lang.String, java.lang.Object> updateService(
            java.util.UUID arg0,
            java.lang.String arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            int arg5,
            java.lang.String arg6,
            java.math.BigDecimal arg7);

    java.util.Map<java.lang.String, java.lang.Object> updatePlan(
            java.util.UUID arg0,
            java.lang.String arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.Integer arg4,
            java.math.BigDecimal arg5,
            java.lang.Integer arg6,
            java.math.BigDecimal arg7,
            java.lang.Integer arg8,
            java.lang.String arg9,
            java.lang.Integer arg10);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> orders();

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> notifications(
            java.lang.String arg0);

    java.util.Map<java.lang.String, java.lang.Object> retry(java.util.UUID arg0);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> audit();

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> tickets();

    java.util.Map<java.lang.String, java.lang.Object> updateTicket(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, java.lang.String arg3);
}
