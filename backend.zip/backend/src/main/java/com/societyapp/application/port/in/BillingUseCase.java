package com.societyapp.application.port.in;

public interface BillingUseCase {
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> list(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> payments(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> invoicePayments(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, java.util.UUID arg3);

    java.util.Map<java.lang.String, java.lang.Object> options(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.Map<java.lang.String, java.lang.Object> create(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.time.LocalDate arg3,
            java.time.LocalDate arg4,
            java.math.BigDecimal arg5,
            java.math.BigDecimal arg6,
            java.lang.String arg7,
            java.math.BigDecimal arg8);

    java.util.Map<java.lang.String, java.lang.Object> pay(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.math.BigDecimal arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7);

    java.util.Map<java.lang.String, java.lang.Object> checkout(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.math.BigDecimal arg4,
            java.lang.String arg5);

    java.util.Map<java.lang.String, java.lang.Object> updatePaymentSettings(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7,
            boolean arg8);

    java.util.Map<java.lang.String, java.lang.Object> receipt(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, java.util.UUID arg3);

    byte[] receiptPdf(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, java.util.UUID arg3);
}
