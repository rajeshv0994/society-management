package com.societyapp.application.port.in;

public interface StorageCleanupUseCase {
    java.util.Map<java.lang.String, java.lang.Object> delete(
            java.util.UUID societyId, java.util.UUID actorId, java.util.UUID objectId);
}
