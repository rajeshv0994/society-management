package com.societyapp.application.port.in;

public interface PlatformMembershipBillingUseCase {
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> societyOrders(
            java.util.UUID arg0);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> allOrders();

    java.util.Map<java.lang.String, java.lang.Object> paymentSettings();

    java.util.Map<java.lang.String, java.lang.Object> updatePaymentSettings(
            java.util.UUID arg0,
            java.lang.String arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.String arg6);

    java.util.Map<java.lang.String, java.lang.Object> issue(
            java.util.UUID arg0, java.time.LocalDate arg1, java.time.LocalDate arg2);

    java.util.Map<java.lang.String, java.lang.Object> submit(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4);

    java.util.Map<java.lang.String, java.lang.Object> checkout(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.Map<java.lang.String, java.lang.Object> verifyCheckout(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4);

    java.util.Map<java.lang.String, java.lang.Object> reconcile(java.util.UUID arg0);

    java.util.Map<java.lang.String, java.lang.Object> cancel(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    boolean processWebhook(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2);

    java.util.Map<java.lang.String, java.lang.Object> gatewayStatus();

    byte[] societyInvoice(java.util.UUID arg0, java.util.UUID arg1);

    byte[] adminInvoice(java.util.UUID arg0);

    java.util.Map<java.lang.String, java.lang.Object> review(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, java.lang.String arg3);
}
