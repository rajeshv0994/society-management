package com.societyapp.application.port.in;

public interface TaskUseCase {
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> list(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.Map<java.lang.String, java.lang.Object> options(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.Map<java.lang.String, java.lang.Object> detail(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, java.util.UUID arg3);

    java.util.Map<java.lang.String, java.lang.Object> create(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.util.UUID arg4,
            java.time.OffsetDateTime arg5,
            java.lang.String arg6);

    java.util.Map<java.lang.String, java.lang.Object> edit(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.util.UUID arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.util.UUID arg5,
            java.time.OffsetDateTime arg6,
            java.lang.String arg7);

    java.util.Map<java.lang.String, java.lang.Object> progress(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4,
            java.lang.String arg5);

    java.util.Map<java.lang.String, java.lang.Object> comment(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4);

    java.util.Map<java.lang.String, java.lang.Object> complete(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4);
}
