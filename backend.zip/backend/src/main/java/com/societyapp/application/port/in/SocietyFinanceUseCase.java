package com.societyapp.application.port.in;

public interface SocietyFinanceUseCase {
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> expenses(java.util.UUID arg0);

    java.util.Map<java.lang.String, java.lang.Object> createExpense(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.math.BigDecimal arg5,
            java.time.LocalDate arg6,
            java.lang.String arg7,
            java.lang.String arg8);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> chargeSettings(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.Map<java.lang.String, java.lang.Object> createChargeSetting(
            java.util.UUID arg0,
            java.lang.String arg1,
            java.lang.String arg2,
            java.math.BigDecimal arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.util.UUID arg6);

    java.util.Map<java.lang.String, java.lang.Object> financeSummary(java.util.UUID arg0, int arg1);

    java.util.Map<java.lang.String, java.lang.Object> addBudget(
            java.util.UUID arg0,
            java.util.UUID arg1,
            int arg2,
            java.math.BigDecimal arg3,
            java.lang.String arg4);

    java.util.Map<java.lang.String, java.lang.Object> setBudget(
            java.util.UUID arg0, java.util.UUID arg1, int arg2, java.math.BigDecimal arg3);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> staffSalaries(
            java.util.UUID arg0);
}
