package com.societyapp.application.port.in;

public interface SubscriptionQuantityUseCase {
    java.util.Map<java.lang.String, java.lang.Object> get(java.util.UUID arg0);

    java.util.Map<java.lang.String, java.lang.Object> update(
            java.util.UUID arg0, int arg1, int arg2, java.lang.String arg3);

    java.util.Map<java.lang.String, java.lang.Object> update(
            java.util.UUID arg0,
            int arg1,
            int arg2,
            java.lang.String arg3,
            java.util.List<java.lang.String> arg4);
}
