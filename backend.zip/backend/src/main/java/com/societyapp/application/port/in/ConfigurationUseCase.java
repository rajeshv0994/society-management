package com.societyapp.application.port.in;

public interface ConfigurationUseCase {
    java.util.Map<java.lang.String, java.lang.Object> get(java.util.UUID arg0);

    java.util.Map<java.lang.String, java.lang.Object> reference(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.Map<java.lang.String, java.lang.Object> addParking(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, java.lang.String arg3);

    java.util.Map<java.lang.String, java.lang.Object> updateParking(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.util.UUID arg2,
            java.lang.String arg3,
            java.lang.String arg4);

    java.util.Map<java.lang.String, java.lang.Object> parkingAction(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.util.UUID arg2,
            java.lang.String arg3,
            java.util.UUID arg4,
            java.lang.String arg5);

    java.util.Map<java.lang.String, java.lang.Object> addVendor(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7);

    java.util.Map<java.lang.String, java.lang.Object> updateVendor(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.util.UUID arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.String arg7,
            java.lang.String arg8);

    java.util.Map<java.lang.String, java.lang.Object> setVendorStatus(
            java.util.UUID arg0, java.util.UUID arg1, java.util.UUID arg2, java.lang.String arg3);

    java.util.Map<java.lang.String, java.lang.Object> addCategory(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, int arg3);

    java.util.Map<java.lang.String, java.lang.Object> updateCategory(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.util.UUID arg2,
            java.lang.String arg3,
            int arg4);

    java.util.Map<java.lang.String, java.lang.Object> setCategoryStatus(
            java.util.UUID arg0, java.util.UUID arg1, java.util.UUID arg2, boolean arg3);

    java.util.Map<java.lang.String, java.lang.Object> addCharge(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.math.BigDecimal arg4,
            java.lang.String arg5,
            java.time.LocalDate arg6,
            java.time.LocalDate arg7);

    java.util.Map<java.lang.String, java.lang.Object> updateCharge(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.util.UUID arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.math.BigDecimal arg5,
            java.lang.String arg6,
            java.time.LocalDate arg7,
            java.time.LocalDate arg8);

    java.util.Map<java.lang.String, java.lang.Object> setChargeStatus(
            java.util.UUID arg0, java.util.UUID arg1, java.util.UUID arg2, boolean arg3);

    java.util.Map<java.lang.String, java.lang.Object> setPermissions(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.util.UUID arg2,
            java.util.Set<java.lang.String> arg3);

    java.util.Map<java.lang.String, java.lang.Object> complete(
            java.util.UUID arg0, java.util.UUID arg1);
}
