package com.societyapp.application.port.in;

public interface AmenityUseCase {
    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> list(
            java.util.UUID arg0, java.lang.String arg1);

    java.util.List<java.util.Map<java.lang.String, java.lang.Object>> bookings(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2);

    java.util.Map<java.lang.String, java.lang.Object> create(
            java.util.UUID arg0,
            java.lang.String arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.Integer arg6,
            java.math.BigDecimal arg7,
            java.lang.String arg8,
            java.math.BigDecimal arg9,
            java.math.BigDecimal arg10,
            java.time.LocalTime arg11,
            java.time.LocalTime arg12,
            boolean arg13,
            int arg14,
            int arg15,
            int arg16,
            java.lang.String arg17);

    java.util.Map<java.lang.String, java.lang.Object> update(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            java.lang.String arg5,
            java.lang.String arg6,
            java.lang.Integer arg7,
            java.math.BigDecimal arg8,
            java.lang.String arg9,
            java.math.BigDecimal arg10,
            java.math.BigDecimal arg11,
            java.time.LocalTime arg12,
            java.time.LocalTime arg13,
            boolean arg14,
            int arg15,
            int arg16,
            int arg17,
            java.lang.String arg18,
            boolean arg19);

    java.util.Map<java.lang.String, java.lang.Object> book(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.util.UUID arg2,
            java.time.OffsetDateTime arg3,
            java.time.OffsetDateTime arg4,
            int arg5,
            java.lang.String arg6);

    java.util.Map<java.lang.String, java.lang.Object> checkout(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4);

    java.util.Map<java.lang.String, java.lang.Object> recordCash(
            java.util.UUID arg0, java.util.UUID arg1, java.lang.String arg2, java.util.UUID arg3);

    java.util.Map<java.lang.String, java.lang.Object> action(
            java.util.UUID arg0,
            java.util.UUID arg1,
            java.lang.String arg2,
            java.util.UUID arg3,
            java.lang.String arg4,
            java.lang.String arg5);
}
