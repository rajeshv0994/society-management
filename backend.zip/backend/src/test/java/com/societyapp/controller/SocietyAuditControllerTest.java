package com.societyapp.controller;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import com.societyapp.security.JwtService;
import com.societyapp.service.AuditService;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

class SocietyAuditControllerTest {
    private final AuditService audits = mock(AuditService.class);
    private final SocietyAuditController controller = new SocietyAuditController(audits);

    @AfterEach
    void clearSecurity() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void alwaysScopesSensitiveHistoryToAuthenticatedSociety() {
        var societyId = UUID.randomUUID();
        var userId = UUID.randomUUID();
        var jwt = new JwtService("test-secret-key-that-is-long-enough-for-hmac", 900_000);
        var claims = jwt.parse(jwt.issue(userId, "admin@example.com", "SOCIETY_ADMIN", societyId));
        var authentication =
                new UsernamePasswordAuthenticationToken(
                        userId, null, List.of(new SimpleGrantedAuthority("ROLE_SOCIETY_ADMIN")));
        authentication.setDetails(claims);
        SecurityContextHolder.getContext().setAuthentication(authentication);

        controller.audit(0, 50, true, null, null, null, null, null, null);

        verify(audits)
                .search(
                        eq(0),
                        eq(50),
                        isNull(),
                        isNull(),
                        eq(societyId),
                        isNull(),
                        isNull(),
                        isNull(),
                        isNull(),
                        eq(true));
    }
}
