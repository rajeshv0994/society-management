package com.societyapp.service;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.societyapp.application.mapper.ApiViewMapper;
import com.societyapp.entity.SocietyCustomPlan;
import com.societyapp.infrastructure.serialization.JacksonJsonCodec;
import com.societyapp.repository.RequirementRequestRepository;
import com.societyapp.repository.SocietyCustomPlanRepository;
import com.societyapp.repository.SocietyRepository;
import com.societyapp.repository.UserAccountJpaRepository;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

class RequirementServiceTest {
    private final UUID planId = UUID.randomUUID();
    private final UUID societyId = UUID.randomUUID();
    private SocietyCustomPlanRepository customPlans;
    private RequirementService service;
    private SocietyCustomPlan plan;

    @BeforeEach
    void setUp() {
        customPlans = mock(SocietyCustomPlanRepository.class);
        service =
                new RequirementService(
                        mock(RequirementRequestRepository.class),
                        customPlans,
                        mock(SocietyRepository.class),
                        mock(UserAccountJpaRepository.class),
                        new JacksonJsonCodec(new ObjectMapper()),
                        mock(ApiViewMapper.class));
        plan = new SocietyCustomPlan();
        ReflectionTestUtils.setField(plan, "id", planId);
        plan.setSocietyId(societyId);
        plan.setStatus("DRAFT");
        when(customPlans.findById(planId)).thenReturn(Optional.of(plan));
    }

    @Test
    void draftCanBeUpdatedAndActivatedWithFixedMonthlyPricing() {
        var previous = new SocietyCustomPlan();
        previous.setSocietyId(societyId);
        previous.setStatus("ACTIVE");
        when(customPlans.findAll()).thenReturn(List.of(plan, previous));

        service.updatePlan(
                planId,
                "Updated contract",
                "Fixed commercial agreement",
                List.of("RESIDENTS", "BILLING"),
                100,
                25,
                50,
                BigDecimal.ZERO,
                BigDecimal.ZERO,
                new BigDecimal("8500"),
                BigDecimal.ZERO,
                "MONTHLY",
                LocalDate.now(),
                null,
                "ACTIVE");

        assertThat(plan.getPlanName()).isEqualTo("Updated contract");
        assertThat(plan.getPriceMonthly()).isEqualByComparingTo("8500");
        assertThat(plan.getStatus()).isEqualTo("ACTIVE");
        assertThat(plan.getActivatedAt()).isNotNull();
        assertThat(previous.getStatus()).isEqualTo("REPLACED");
        verify(customPlans).save(previous);
        verify(customPlans).save(plan);
    }

    @Test
    void activePlanCannotBeReturnedToDraft() {
        plan.setStatus("ACTIVE");

        assertThatThrownBy(
                        () ->
                                service.updatePlan(
                                        planId,
                                        "Plan",
                                        null,
                                        List.of("RESIDENTS"),
                                        100,
                                        25,
                                        50,
                                        new BigDecimal("10"),
                                        new BigDecimal("50"),
                                        BigDecimal.ZERO,
                                        BigDecimal.ZERO,
                                        "MONTHLY",
                                        LocalDate.now(),
                                        null,
                                        "DRAFT"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("cannot return to draft");
    }

    @Test
    void fixedAndUsagePricesCannotBeMixed() {
        assertThatThrownBy(
                        () ->
                                service.updatePlan(
                                        planId,
                                        "Plan",
                                        null,
                                        List.of("RESIDENTS"),
                                        100,
                                        25,
                                        50,
                                        BigDecimal.TEN,
                                        BigDecimal.ZERO,
                                        new BigDecimal("8500"),
                                        BigDecimal.ZERO,
                                        "MONTHLY",
                                        LocalDate.now(),
                                        null,
                                        "DRAFT"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("either a fixed monthly price");
    }

    @Test
    void activePlanCanBeCancelledButRemainsAuditable() {
        var actorId = UUID.randomUUID();
        plan.setStatus("ACTIVE");

        service.cancelPlan(planId, actorId, "Commercial agreement ended");

        assertThat(plan.getStatus()).isEqualTo("CANCELLED");
        assertThat(plan.getCancelledBy()).isEqualTo(actorId);
        assertThat(plan.getCancelledAt()).isNotNull();
        assertThat(plan.getCancellationReason()).isEqualTo("Commercial agreement ended");
        verify(customPlans).save(plan);
    }
}
