package com.societyapp.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.societyapp.application.exception.ConflictException;
import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.mapper.ApiViewMapper;
import com.societyapp.entity.*;
import com.societyapp.infrastructure.serialization.JacksonJsonCodec;
import com.societyapp.repository.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ConfigurationServiceTest {
    private final ParkingSlotRepository parking = mock(ParkingSlotRepository.class);
    private final VendorRepository vendors = mock(VendorRepository.class);
    private final ComplaintCategoryRepository categories = mock(ComplaintCategoryRepository.class);
    private final MaintenanceChargeRuleRepository charges =
            mock(MaintenanceChargeRuleRepository.class);
    private final StaffPermissionRepository permissions = mock(StaffPermissionRepository.class);
    private final UserAccountJpaRepository users = mock(UserAccountJpaRepository.class);
    private final BlockRepository blocks = mock(BlockRepository.class);
    private final FloorRepository floors = mock(FloorRepository.class);
    private final FlatRepository flats = mock(FlatRepository.class);
    private final SocietyRepository societies = mock(SocietyRepository.class);
    private final AuditEventRepository audits = mock(AuditEventRepository.class);
    private final StructureAccessService structure = mock(StructureAccessService.class);
    private final com.societyapp.application.port.out.JsonCodec json =
            new JacksonJsonCodec(new ObjectMapper().findAndRegisterModules());
    private final ConfigurationService service =
            new ConfigurationService(
                    parking,
                    vendors,
                    categories,
                    charges,
                    permissions,
                    users,
                    blocks,
                    floors,
                    flats,
                    societies,
                    audits,
                    structure,
                    new ApiViewMapper(json),
                    json);

    private final UUID societyId = UUID.randomUUID();
    private final UUID otherSocietyId = UUID.randomUUID();
    private final UUID adminId = UUID.randomUUID();
    private final UUID staffId = UUID.randomUUID();
    private final UUID itemId = UUID.randomUUID();
    private final UUID flatId = UUID.randomUUID();
    private Society society;

    @BeforeEach
    void defaults() {
        society = new Society();
        society.setEnabledModules(
                "[\"RESIDENTS\",\"STAFF\",\"PARKING\",\"VENDORS\",\"COMPLAINTS\",\"BILLING\",\"PAYMENTS\",\"VISITORS\",\"NOTICES\",\"AMENITIES\",\"DELIVERIES\",\"EMERGENCY_INCIDENTS\",\"ACTIVITIES_GALLERIES\"]");
        when(societies.findById(societyId)).thenReturn(Optional.of(society));
        when(societies.findById(otherSocietyId)).thenReturn(Optional.empty());
        when(parking.save(any(ParkingSlot.class))).thenAnswer(call -> call.getArgument(0));
        when(vendors.save(any(Vendor.class))).thenAnswer(call -> call.getArgument(0));
        when(categories.save(any(ComplaintCategory.class))).thenAnswer(call -> call.getArgument(0));
        when(charges.save(any(MaintenanceChargeRule.class)))
                .thenAnswer(call -> call.getArgument(0));
        when(audits.save(any(AuditEvent.class))).thenAnswer(call -> call.getArgument(0));
        when(parking.findBySocietyIdOrderBySlotNumber(societyId)).thenReturn(List.of());
        when(vendors.findBySocietyIdOrderByName(societyId)).thenReturn(List.of());
        when(categories.findBySocietyIdOrderByName(societyId)).thenReturn(List.of());
        when(charges.findBySocietyIdOrderByName(societyId)).thenReturn(List.of());
        when(blocks.findBySocietyIdOrderByName(societyId)).thenReturn(List.of());
    }

    @Test
    void workspaceReturnsAllConfigurationAreasSummaryReadinessAndPermissionCatalog() {
        var slot = slot("AVAILABLE");
        var vendor = vendor("ACTIVE");
        var category = category(true);
        var charge = charge(true, LocalDate.now().minusDays(1), null);
        when(parking.findBySocietyIdOrderBySlotNumber(societyId)).thenReturn(List.of(slot));
        when(vendors.findBySocietyIdOrderByName(societyId)).thenReturn(List.of(vendor));
        when(categories.findBySocietyIdOrderByName(societyId)).thenReturn(List.of(category));
        when(charges.findBySocietyIdOrderByName(societyId)).thenReturn(List.of(charge));

        var result = service.get(societyId);

        assertThat(result.keySet())
                .contains(
                        "parking",
                        "vendors",
                        "complaintCategories",
                        "chargeRules",
                        "summary",
                        "setup",
                        "staff_permission_options");
        @SuppressWarnings("unchecked")
        var summary = (Map<String, Object>) result.get("summary");
        assertThat(summary)
                .containsEntry("parking_available", 1L)
                .containsEntry("active_vendors", 1L)
                .containsEntry("active_categories", 1L)
                .containsEntry("active_charge_rules", 1L);
        assertThat((List<?>) result.get("staff_permission_options")).hasSize(10);
    }

    @Test
    void createsNormalizedParkingAndRejectsCaseInsensitiveDuplicate() {
        var created = service.addParking(societyId, adminId, " p-01 ", "CAR");
        assertThat(created)
                .containsEntry("slot_number", "P-01")
                .containsEntry("status", "AVAILABLE");
        verify(audits).save(any(AuditEvent.class));

        when(parking.existsBySocietyIdAndSlotNumberIgnoreCase(societyId, "P-01")).thenReturn(true);
        assertThatThrownBy(() -> service.addParking(societyId, adminId, "p-01", "CAR"))
                .isInstanceOf(ConflictException.class)
                .hasMessageContaining("already exists");
    }

    @Test
    void parkingSupportsAllocationReleaseMaintenanceAndTenantIsolation() {
        var slot = slot("AVAILABLE");
        when(parking.findByIdAndSocietyId(itemId, societyId)).thenReturn(Optional.of(slot));
        when(structure.requireFlat(flatId, societyId)).thenReturn(new Flat());

        var allocated =
                service.parkingAction(
                        societyId, adminId, itemId, "ALLOCATE", flatId, "mh 12 ab 1234");
        assertThat(allocated)
                .containsEntry("status", "ALLOCATED")
                .containsEntry("flat_id", flatId.toString())
                .containsEntry("vehicle_number", "MH 12 AB 1234");

        var released = service.parkingAction(societyId, adminId, itemId, "RELEASE", null, null);
        assertThat(released).containsEntry("status", "AVAILABLE").containsEntry("flat_id", null);

        var maintenance =
                service.parkingAction(societyId, adminId, itemId, "MAINTENANCE", null, null);
        assertThat(maintenance).containsEntry("status", "MAINTENANCE");

        when(parking.findByIdAndSocietyId(itemId, otherSocietyId)).thenReturn(Optional.empty());
        assertThatThrownBy(
                        () ->
                                service.parkingAction(
                                        otherSocietyId, adminId, itemId, "RELEASE", null, null))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    void parkingAllocationRequiresAValidSpaceAndVehicle() {
        var slot = slot("AVAILABLE");
        when(parking.findByIdAndSocietyId(itemId, societyId)).thenReturn(Optional.of(slot));

        assertThatThrownBy(
                        () ->
                                service.parkingAction(
                                        societyId, adminId, itemId, "ALLOCATE", null, "MH12"))
                .hasMessageContaining("Space");
        assertThatThrownBy(
                        () ->
                                service.parkingAction(
                                        societyId, adminId, itemId, "ALLOCATE", flatId, " "))
                .hasMessageContaining("Vehicle");
    }

    @Test
    void vendorSupportsCompleteCreateUpdateAndStatusLifecycle() {
        var created =
                service.addVendor(
                        societyId,
                        adminId,
                        " Lift Care ",
                        " Elevator ",
                        " Priya ",
                        "+91 90000 00000",
                        "HELP@EXAMPLE.COM",
                        "27abcde1234f1z5");
        assertThat(created)
                .containsEntry("name", "Lift Care")
                .containsEntry("mobile", "+91 90000 00000")
                .containsEntry("email", "help@example.com")
                .containsEntry("gst_number", "27ABCDE1234F1Z5");

        var row = vendor("ACTIVE");
        when(vendors.findByIdAndSocietyId(itemId, societyId)).thenReturn(Optional.of(row));
        var updated =
                service.updateVendor(
                        societyId,
                        adminId,
                        itemId,
                        "Lift Care 2",
                        "Elevator",
                        "Asha",
                        "9000000001",
                        "asha@example.com",
                        null);
        assertThat(updated).containsEntry("name", "Lift Care 2");
        assertThat(service.setVendorStatus(societyId, adminId, itemId, "INACTIVE"))
                .containsEntry("status", "INACTIVE");
    }

    @Test
    void duplicateVendorCombinationIsRejected() {
        when(vendors.existsBySocietyIdAndNameIgnoreCaseAndServiceTypeIgnoreCase(
                        societyId, "Lift Care", "Elevator"))
                .thenReturn(true);
        assertThatThrownBy(
                        () ->
                                service.addVendor(
                                        societyId,
                                        adminId,
                                        "Lift Care",
                                        "Elevator",
                                        null,
                                        "9000000000",
                                        null,
                                        null))
                .isInstanceOf(ConflictException.class);
    }

    @Test
    void complaintCategorySupportsSlaEditAndDeactivate() {
        var created = service.addCategory(societyId, adminId, " Plumbing ", 24);
        assertThat(created).containsEntry("name", "Plumbing").containsEntry("active", true);

        var row = category(true);
        when(categories.findByIdAndSocietyId(itemId, societyId)).thenReturn(Optional.of(row));
        assertThat(service.updateCategory(societyId, adminId, itemId, "Urgent plumbing", 6))
                .containsEntry("sla_hours", 6);
        assertThat(service.setCategoryStatus(societyId, adminId, itemId, false))
                .containsEntry("active", false);
    }

    @Test
    void categoryRejectsDuplicateAndInvalidSla() {
        when(categories.existsBySocietyIdAndNameIgnoreCase(societyId, "Plumbing")).thenReturn(true);
        assertThatThrownBy(() -> service.addCategory(societyId, adminId, "Plumbing", 24))
                .isInstanceOf(ConflictException.class);
        assertThatThrownBy(() -> service.addCategory(societyId, adminId, "Other", 0))
                .hasMessageContaining("SLA");
    }

    @Test
    void chargeRuleSupportsAllFieldsEditAndLifecycle() {
        var from = LocalDate.now();
        var to = from.plusYears(1);
        var created =
                service.addCharge(
                        societyId,
                        adminId,
                        "Area charge",
                        "PER_SQFT",
                        new BigDecimal("2.50"),
                        "MONTHLY",
                        from,
                        to);
        assertThat(created)
                .containsEntry("calculation_type", "PER_SQFT")
                .containsEntry("active", true);
        assertThat(created.get("effective_to").toString())
                .contains(
                        String.valueOf(to.getYear()),
                        String.valueOf(to.getMonthValue()),
                        String.valueOf(to.getDayOfMonth()));

        var row = charge(true, from, to);
        when(charges.findByIdAndSocietyId(itemId, societyId)).thenReturn(Optional.of(row));
        assertThat(
                        service.updateCharge(
                                societyId,
                                adminId,
                                itemId,
                                "Area charge",
                                "FIXED",
                                new BigDecimal("500"),
                                "QUARTERLY",
                                from,
                                null))
                .containsEntry("frequency", "QUARTERLY");
        assertThat(service.setChargeStatus(societyId, adminId, itemId, false))
                .containsEntry("active", false);
    }

    @Test
    void chargeRejectsInvalidPercentageDateRangeAndDuplicateEffectiveVersion() {
        var from = LocalDate.now();
        assertThatThrownBy(
                        () ->
                                service.addCharge(
                                        societyId,
                                        adminId,
                                        "Penalty",
                                        "PERCENTAGE",
                                        new BigDecimal("101"),
                                        "MONTHLY",
                                        from,
                                        null))
                .hasMessageContaining("100");
        assertThatThrownBy(
                        () ->
                                service.addCharge(
                                        societyId,
                                        adminId,
                                        "Charge",
                                        "FIXED",
                                        BigDecimal.TEN,
                                        "MONTHLY",
                                        from,
                                        from.minusDays(1)))
                .hasMessageContaining("end date");
        when(charges.existsBySocietyIdAndNameIgnoreCaseAndEffectiveFrom(societyId, "Charge", from))
                .thenReturn(true);
        assertThatThrownBy(
                        () ->
                                service.addCharge(
                                        societyId,
                                        adminId,
                                        "Charge",
                                        "FIXED",
                                        BigDecimal.TEN,
                                        "MONTHLY",
                                        from,
                                        null))
                .isInstanceOf(ConflictException.class);
    }

    @Test
    void referenceReturnsOnlyActiveAndCurrentlyEffectiveConfiguration() {
        var available = slot("AVAILABLE");
        var inactiveSlot = slot("INACTIVE");
        var activeVendor = vendor("ACTIVE");
        var inactiveVendor = vendor("INACTIVE");
        var activeCategory = category(true);
        var inactiveCategory = category(false);
        var current = charge(true, LocalDate.now().minusDays(1), LocalDate.now().plusDays(1));
        var future = charge(true, LocalDate.now().plusDays(1), null);
        when(parking.findBySocietyIdOrderBySlotNumber(societyId))
                .thenReturn(List.of(available, inactiveSlot));
        when(vendors.findBySocietyIdOrderByName(societyId))
                .thenReturn(List.of(activeVendor, inactiveVendor));
        when(categories.findBySocietyIdOrderByName(societyId))
                .thenReturn(List.of(activeCategory, inactiveCategory));
        when(charges.findBySocietyIdOrderByName(societyId)).thenReturn(List.of(current, future));

        var result = service.reference(societyId, staffId, "STAFF");

        assertThat((List<?>) result.get("parking")).hasSize(1);
        assertThat((List<?>) result.get("vendors")).hasSize(1);
        assertThat((List<?>) result.get("complaint_categories")).hasSize(1);
        assertThat((List<?>) result.get("charge_rules")).hasSize(1);
    }

    @Test
    void permissionsRejectUnknownOrDisabledCodesAndReplaceValidSet() {
        var staff = new UserAccount();
        staff.setSocietyId(societyId);
        staff.setRole("STAFF");
        when(users.findById(staffId)).thenReturn(Optional.of(staff));

        assertThatThrownBy(
                        () ->
                                service.setPermissions(
                                        societyId, adminId, staffId, Set.of("UNKNOWN")))
                .hasMessageContaining("Unknown or disabled");

        society.setEnabledModules("[\"STAFF\"]");
        assertThatThrownBy(
                        () ->
                                service.setPermissions(
                                        societyId, adminId, staffId, Set.of("VISITORS")))
                .hasMessageContaining("disabled");

        var result = service.setPermissions(societyId, adminId, staffId, Set.of("TASKS"));
        assertThat(result).containsEntry("permissions", Set.of("TASKS"));
        verify(permissions, atLeastOnce()).deleteByStaffUserId(staffId);
        verify(permissions).save(any(StaffPermission.class));
    }

    @Test
    void disabledConfigurationModuleRejectsMutation() {
        society.setEnabledModules("[\"STAFF\"]");
        assertThatThrownBy(() -> service.addParking(societyId, adminId, "P1", "CAR"))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("not enabled");
    }

    @Test
    void setupCompletionRequiresStructureAndThenPersistsCompletion() {
        assertThatThrownBy(() -> service.complete(societyId, adminId))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("property group");

        var block = new Block();
        block.setSocietyId(societyId);
        var floor = new Floor();
        var flat = new Flat();
        when(blocks.findBySocietyIdOrderByName(societyId)).thenReturn(List.of(block));
        when(floors.findByBlockIdOrderByFloorNumber(nullable(UUID.class)))
                .thenReturn(List.of(floor));
        when(flats.findByFloorIdOrderByFlatNumber(nullable(UUID.class))).thenReturn(List.of(flat));

        var result = service.complete(societyId, adminId);

        assertThat(result).containsEntry("setup_completed", true);
        assertThat(society.isSetupCompleted()).isTrue();
        verify(societies).save(society);
    }

    private ParkingSlot slot(String status) {
        var row = new ParkingSlot();
        row.setSocietyId(societyId);
        row.setSlotNumber("P-01");
        row.setSlotType("CAR");
        row.setStatus(status);
        row.setCreatedAt(OffsetDateTime.now());
        row.setUpdatedAt(OffsetDateTime.now());
        return row;
    }

    private Vendor vendor(String status) {
        var row = new Vendor();
        row.setSocietyId(societyId);
        row.setName("Lift Care");
        row.setServiceType("Elevator");
        row.setMobile("9000000000");
        row.setStatus(status);
        row.setCreatedAt(OffsetDateTime.now());
        row.setUpdatedAt(OffsetDateTime.now());
        return row;
    }

    private ComplaintCategory category(boolean active) {
        var row = new ComplaintCategory();
        row.setSocietyId(societyId);
        row.setName("Plumbing");
        row.setSlaHours(24);
        row.setActive(active);
        row.setCreatedAt(OffsetDateTime.now());
        row.setUpdatedAt(OffsetDateTime.now());
        return row;
    }

    private MaintenanceChargeRule charge(
            boolean active, LocalDate effectiveFrom, LocalDate effectiveTo) {
        var row = new MaintenanceChargeRule();
        row.setSocietyId(societyId);
        row.setName("Maintenance");
        row.setCalculationType("FIXED");
        row.setAmount(BigDecimal.TEN);
        row.setFrequency("MONTHLY");
        row.setEffectiveFrom(effectiveFrom);
        row.setEffectiveTo(effectiveTo);
        row.setActive(active);
        row.setCreatedAt(OffsetDateTime.now());
        row.setUpdatedAt(OffsetDateTime.now());
        return row;
    }
}
