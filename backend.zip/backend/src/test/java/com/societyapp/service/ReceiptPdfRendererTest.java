package com.societyapp.service;

import static org.assertj.core.api.Assertions.assertThat;

import com.societyapp.infrastructure.documents.ReceiptPdfRenderer;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.LinkedHashMap;
import org.junit.jupiter.api.Test;

class ReceiptPdfRendererTest {
    @Test
    void rendersAValidPaymentReceiptPdf() {
        var receipt = new LinkedHashMap<String, Object>();
        receipt.put("society_name", "Green Valley Society");
        receipt.put("society_registration", "REG-101");
        receipt.put("amount", new BigDecimal("1250.00"));
        receipt.put("receipt_number", "RCP-2026-0001");
        receipt.put("invoice_number", "INV-2026-0001");
        receipt.put("payer_name", "Resident One");
        receipt.put("block", "A");
        receipt.put("floor_number", "2");
        receipt.put("flat_number", "201");
        receipt.put("payment_method", "NET_BANKING");
        receipt.put("payment_channel", "ONLINE");
        receipt.put("provider_reference", "PAY-101");
        receipt.put("paid_at", OffsetDateTime.parse("2026-07-28T10:00:00+05:30"));
        receipt.put("recorded_by_name", "Resident One");

        var pdf = new ReceiptPdfRenderer().render(receipt);

        assertThat(pdf).hasSizeGreaterThan(1_000);
        assertThat(new String(pdf, 0, 4, java.nio.charset.StandardCharsets.US_ASCII))
                .isEqualTo("%PDF");
    }
}
