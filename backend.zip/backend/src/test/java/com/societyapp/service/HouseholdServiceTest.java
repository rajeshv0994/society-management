package com.societyapp.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.societyapp.application.exception.AuthorizationException;
import com.societyapp.entity.*;
import com.societyapp.repository.*;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class HouseholdServiceTest {
    private final UserAccountJpaRepository users = mock(UserAccountJpaRepository.class);
    private final HouseholdMemberRepository members = mock(HouseholdMemberRepository.class);
    private final HouseholdVehicleRepository vehicles = mock(HouseholdVehicleRepository.class);
    private final HouseholdEmergencyContactRepository contacts =
            mock(HouseholdEmergencyContactRepository.class);
    private final FlatRepository flats = mock(FlatRepository.class);
    private final FloorRepository floors = mock(FloorRepository.class);
    private final BlockRepository blocks = mock(BlockRepository.class);
    private final StaffPermissionRepository permissions = mock(StaffPermissionRepository.class);
    private final HouseholdService service =
            new HouseholdService(
                    users, members, vehicles, contacts, flats, floors, blocks, permissions);

    private final UUID societyId = UUID.randomUUID();
    private final UUID residentId = UUID.randomUUID();
    private final UUID staffId = UUID.randomUUID();
    private final UUID recordId = UUID.randomUUID();

    @BeforeEach
    void defaults() {
        when(members.save(any(HouseholdMember.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));
        when(vehicles.save(any(HouseholdVehicle.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));
        when(contacts.save(any(HouseholdEmergencyContact.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));
        when(flats.findAll()).thenReturn(List.of());
        when(members.findBySocietyIdAndPrimaryResidentIdAndActiveTrue(societyId, residentId))
                .thenReturn(List.of());
        when(vehicles.findBySocietyIdAndPrimaryResidentIdAndActiveTrueOrderByRegistrationNumber(
                        societyId, residentId))
                .thenReturn(List.of());
        when(contacts.findBySocietyIdAndPrimaryResidentIdAndActiveTrueOrderByPriority(
                        societyId, residentId))
                .thenReturn(List.of());
        when(users.findById(residentId)).thenReturn(Optional.of(resident()));
    }

    @Test
    void residentWorkspaceOnlyReturnsOwnHousehold() {
        var result = service.workspace(societyId, residentId, "RESIDENT");

        assertThat((List<?>) result.get("households")).hasSize(1);
        assertThat(result)
                .containsEntry("resident_count", 1)
                .containsEntry("member_count", 0)
                .containsEntry("vehicle_count", 0)
                .containsEntry("pending_verification", 0L);
    }

    @Test
    void staffRequiresExplicitHouseholdPermission() {
        assertThatThrownBy(() -> service.workspace(societyId, staffId, "STAFF"))
                .isInstanceOf(AuthorizationException.class);

        when(permissions.existsByStaffUserIdAndPermissionCode(staffId, "HOUSEHOLDS"))
                .thenReturn(true);
        when(users.findBySocietyIdAndRoleOrderByFullName(societyId, "RESIDENT"))
                .thenReturn(List.of(resident()));
        assertThat((List<?>) service.workspace(societyId, staffId, "STAFF").get("households"))
                .hasSize(1);
    }

    @Test
    void residentCannotManageAnotherResidentsHousehold() {
        assertThatThrownBy(
                        () ->
                                service.addMember(
                                        societyId,
                                        residentId,
                                        "RESIDENT",
                                        UUID.randomUUID(),
                                        "Family Member",
                                        "SPOUSE",
                                        null,
                                        null,
                                        null,
                                        null,
                                        null,
                                        null,
                                        null,
                                        null,
                                        null,
                                        null,
                                        false))
                .isInstanceOf(AuthorizationException.class);
    }

    @Test
    void newMemberReceivesCodePendingVerificationAndNormalizedIdentity() {
        var result =
                service.addMember(
                        societyId,
                        residentId,
                        "RESIDENT",
                        null,
                        " Family Member ",
                        "spouse",
                        "9000012345",
                        "family@example.com",
                        LocalDate.of(1990, 1, 1),
                        "FEMALE",
                        "B+",
                        "Designer",
                        "AADHAAR",
                        "ab12",
                        "Emergency",
                        "9111111111",
                        true);

        assertThat(result.get("member_code").toString()).startsWith("HM-");
        assertThat(result)
                .containsEntry("full_name", "Family Member")
                .containsEntry("relationship", "SPOUSE")
                .containsEntry("identity_last4", "AB12")
                .containsEntry("access_enabled", true)
                .containsEntry("verification_status", "PENDING");
    }

    @Test
    void residentEditResetsPreviouslyVerifiedMemberToPending() {
        HouseholdMember member = member("VERIFIED");
        when(members.findByIdAndSocietyIdAndPrimaryResidentId(recordId, societyId, residentId))
                .thenReturn(Optional.of(member));

        var result =
                service.updateMember(
                        societyId,
                        residentId,
                        "RESIDENT",
                        null,
                        recordId,
                        "Family Member",
                        "SPOUSE",
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        false);

        assertThat(result).containsEntry("verification_status", "PENDING");
        assertThat(member.getReviewedBy()).isNull();
        assertThat(member.getReviewedAt()).isNull();
    }

    @Test
    void managerVerificationRequiresRejectionNote() {
        HouseholdMember member = member("PENDING");
        when(members.findByIdAndSocietyIdAndPrimaryResidentId(recordId, societyId, residentId))
                .thenReturn(Optional.of(member));

        assertThatThrownBy(
                        () ->
                                service.reviewMember(
                                        societyId,
                                        staffId,
                                        "SOCIETY_ADMIN",
                                        residentId,
                                        recordId,
                                        "REJECTED",
                                        " "))
                .hasMessageContaining("Rejection note");

        var result =
                service.reviewMember(
                        societyId,
                        staffId,
                        "SOCIETY_ADMIN",
                        residentId,
                        recordId,
                        "VERIFIED",
                        null);
        assertThat(result).containsEntry("verification_status", "VERIFIED");
        assertThat(member.getReviewedBy()).isEqualTo(staffId);
    }

    @Test
    void vehicleRegistrationIsNormalizedAndResidentEditResetsVerification() {
        var created =
                service.addVehicle(
                        societyId,
                        residentId,
                        "RESIDENT",
                        null,
                        "CAR",
                        "mh 12 ab 1234",
                        "Tata",
                        "Nexon",
                        "Blue",
                        "P-12",
                        "ST-12");
        assertThat(created)
                .containsEntry("registration_number", "MH12AB1234")
                .containsEntry("verification_status", "PENDING");

        HouseholdVehicle vehicle = vehicle("VERIFIED");
        when(vehicles.findByIdAndSocietyIdAndPrimaryResidentId(recordId, societyId, residentId))
                .thenReturn(Optional.of(vehicle));
        var updated =
                service.updateVehicle(
                        societyId,
                        residentId,
                        "RESIDENT",
                        null,
                        recordId,
                        "CAR",
                        "MH12AB1234",
                        "Tata",
                        "Nexon",
                        "Blue",
                        "P-12",
                        "ST-12");
        assertThat(updated).containsEntry("verification_status", "PENDING");
    }

    @Test
    void emergencyContactsAreLimitedToThreeAndRemovalIsSoft() {
        when(contacts.findBySocietyIdAndPrimaryResidentIdAndActiveTrueOrderByPriority(
                        societyId, residentId))
                .thenReturn(List.of(contact(), contact(), contact()));
        assertThatThrownBy(
                        () ->
                                service.addContact(
                                        societyId,
                                        residentId,
                                        "RESIDENT",
                                        null,
                                        "Emergency",
                                        "BROTHER",
                                        "9111111111",
                                        null,
                                        1))
                .hasMessageContaining("up to 3");

        HouseholdEmergencyContact contact = contact();
        when(contacts.findByIdAndSocietyIdAndPrimaryResidentId(recordId, societyId, residentId))
                .thenReturn(Optional.of(contact));
        assertThat(service.removeContact(societyId, residentId, "RESIDENT", null, recordId))
                .containsEntry("active", false);
        assertThat(contact.isActive()).isFalse();
    }

    @Test
    void deletingMemberDisablesSocietyAccess() {
        HouseholdMember member = member("VERIFIED");
        member.setAccessEnabled(true);
        when(members.findByIdAndSocietyIdAndPrimaryResidentId(recordId, societyId, residentId))
                .thenReturn(Optional.of(member));

        service.removeMember(societyId, residentId, "RESIDENT", null, recordId);

        assertThat(member.isActive()).isFalse();
        assertThat(member.isAccessEnabled()).isFalse();
    }

    private UserAccount resident() {
        UserAccount user = new UserAccount();
        user.setSocietyId(societyId);
        user.setFullName("Resident");
        user.setEmail("resident@example.com");
        user.setMobile("9000000000");
        user.setRole("RESIDENT");
        user.setStatus("ACTIVE");
        return user;
    }

    private HouseholdMember member(String status) {
        HouseholdMember member = new HouseholdMember();
        member.setSocietyId(societyId);
        member.setPrimaryResidentId(residentId);
        member.setMemberCode("HM-TEST00001");
        member.setFullName("Family Member");
        member.setRelationship("SPOUSE");
        member.setVerificationStatus(status);
        member.setActive(true);
        member.setCreatedAt(OffsetDateTime.now());
        member.setUpdatedAt(OffsetDateTime.now());
        return member;
    }

    private HouseholdVehicle vehicle(String status) {
        HouseholdVehicle vehicle = new HouseholdVehicle();
        vehicle.setSocietyId(societyId);
        vehicle.setPrimaryResidentId(residentId);
        vehicle.setVehicleType("CAR");
        vehicle.setRegistrationNumber("MH12AB1234");
        vehicle.setVerificationStatus(status);
        vehicle.setActive(true);
        vehicle.setCreatedAt(OffsetDateTime.now());
        vehicle.setUpdatedAt(OffsetDateTime.now());
        return vehicle;
    }

    private HouseholdEmergencyContact contact() {
        HouseholdEmergencyContact contact = new HouseholdEmergencyContact();
        contact.setSocietyId(societyId);
        contact.setPrimaryResidentId(residentId);
        contact.setFullName("Emergency");
        contact.setRelationship("BROTHER");
        contact.setMobile("9111111111");
        contact.setPriority(1);
        contact.setActive(true);
        contact.setCreatedAt(OffsetDateTime.now());
        contact.setUpdatedAt(OffsetDateTime.now());
        return contact;
    }
}
