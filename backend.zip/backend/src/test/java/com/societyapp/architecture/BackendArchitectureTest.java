package com.societyapp.architecture;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClasses;

import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.junit.*;
import com.tngtech.archunit.lang.ArchRule;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RestController;

@AnalyzeClasses(packages = "com.societyapp", importOptions = ImportOption.DoNotIncludeTests.class)
class BackendArchitectureTest {

    @ArchTest
    static final ArchRule controllersLiveAtTheHttpBoundary =
            classes()
                    .that()
                    .areAnnotatedWith(RestController.class)
                    .should()
                    .resideInAPackage("..controller..");

    @ArchTest
    static final ArchRule controllersDoNotAccessPersistence =
            noClasses()
                    .that()
                    .resideInAPackage("..controller..")
                    .should()
                    .dependOnClassesThat()
                    .resideInAnyPackage(
                            "..repository..",
                            "..entity..",
                            "org.springframework.jdbc..",
                            "jakarta.persistence..");

    @ArchTest
    static final ArchRule repositoriesDoNotDependOnWebOrServices =
            noClasses()
                    .that()
                    .resideInAPackage("..repository..")
                    .should()
                    .dependOnClassesThat()
                    .resideInAnyPackage("..controller..", "..service..");

    @ArchTest
    static final ArchRule servicesDoNotDependOnControllers =
            noClasses()
                    .that()
                    .areAnnotatedWith(Service.class)
                    .should()
                    .dependOnClassesThat()
                    .resideInAPackage("..controller..");

    @ArchTest
    static final ArchRule springDataRepositoriesUseTheRepositoryLayer =
            classes()
                    .that()
                    .areInterfaces()
                    .and()
                    .haveSimpleNameEndingWith("Repository")
                    .and()
                    .areNotAnnotatedWith(Repository.class)
                    .should()
                    .resideInAnyPackage("..repository..", "..application.port.out..");
}
