package com.societyapp.architecture;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClasses;

import com.societyapp.domain.type.DomainCode;
import com.tngtech.archunit.core.domain.JavaClass;
import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchCondition;
import com.tngtech.archunit.lang.ArchRule;
import com.tngtech.archunit.lang.ConditionEvents;
import com.tngtech.archunit.lang.SimpleConditionEvent;

@AnalyzeClasses(packages = "com.societyapp", importOptions = ImportOption.DoNotIncludeTests.class)
class StrictCleanArchitectureTest {
    private static final String[] FRAMEWORKS = {
        "org.springframework..",
        "jakarta..",
        "org.hibernate..",
        "com.fasterxml..",
        "com.lowagie..",
        "io.jsonwebtoken..",
        "lombok.."
    };

    private static final ArchCondition<JavaClass> NOT_DEPEND_ON_OTHER_INTERACTORS =
            new ArchCondition<>("depend only on ports when collaborating with other interactors") {
                @Override
                public void check(JavaClass item, ConditionEvents events) {
                    item.getDirectDependenciesFromSelf().stream()
                            .filter(
                                    dependency ->
                                            dependency
                                                    .getTargetClass()
                                                    .getPackageName()
                                                    .startsWith("com.societyapp.service"))
                            .filter(
                                    dependency ->
                                            !topLevelName(dependency.getTargetClass().getName())
                                                    .equals(topLevelName(item.getName())))
                            .forEach(
                                    dependency ->
                                            events.add(
                                                    SimpleConditionEvent.violated(
                                                            item, dependency.getDescription())));
                }
            };

    @ArchTest
    static final ArchRule domainModelsArePlainJava =
            noClasses()
                    .that()
                    .resideInAnyPackage("com.societyapp.entity..", "com.societyapp.domain..")
                    .should()
                    .dependOnClassesThat()
                    .resideInAnyPackage(FRAMEWORKS);

    @ArchTest
    static final ArchRule domainEnumsUseTheSharedBoundaryContract =
            classes()
                    .that()
                    .areEnums()
                    .and()
                    .resideInAPackage("com.societyapp.domain.type..")
                    .should()
                    .implement(DomainCode.class);

    @ArchTest
    static final ArchRule applicationServicesAreFrameworkFree =
            noClasses()
                    .that()
                    .resideInAPackage("com.societyapp.service..")
                    .should()
                    .dependOnClassesThat()
                    .resideInAnyPackage(FRAMEWORKS);

    @ArchTest
    static final ArchRule applicationPortsAreFrameworkFree =
            noClasses()
                    .that()
                    .resideInAnyPackage(
                            "com.societyapp.repository..", "com.societyapp.application.port..")
                    .should()
                    .dependOnClassesThat()
                    .resideInAnyPackage(FRAMEWORKS);

    @ArchTest
    static final ArchRule applicationDoesNotDependOnOuterAdapters =
            noClasses()
                    .that()
                    .resideInAnyPackage(
                            "com.societyapp.service..",
                            "com.societyapp.entity..",
                            "com.societyapp.domain..",
                            "com.societyapp.repository..",
                            "com.societyapp.application..")
                    .should()
                    .dependOnClassesThat()
                    .resideInAnyPackage(
                            "com.societyapp.controller..",
                            "com.societyapp.infrastructure..",
                            "com.societyapp.documents..",
                            "com.societyapp.security..",
                            "com.societyapp.config..");

    @ArchTest
    static final ArchRule springDataLivesOnlyInPersistenceAdapters =
            noClasses()
                    .that()
                    .resideOutsideOfPackage("..infrastructure..")
                    .should()
                    .dependOnClassesThat()
                    .resideInAPackage("org.springframework.data..");

    @ArchTest
    static final ArchRule adaptersUseInputPortsInsteadOfInteractorImplementations =
            noClasses()
                    .that()
                    .resideOutsideOfPackages(
                            "com.societyapp.service..", "com.societyapp.application..")
                    .should()
                    .dependOnClassesThat()
                    .resideInAPackage("com.societyapp.service..");

    @ArchTest
    static final ArchRule inputPortsDoNotDependOnInteractorImplementations =
            noClasses()
                    .that()
                    .resideInAPackage("com.societyapp.application.port.in..")
                    .should()
                    .dependOnClassesThat()
                    .resideInAPackage("com.societyapp.service..");

    @ArchTest
    static final ArchRule interactorsDependOnPortsInsteadOfOtherInteractors =
            classes()
                    .that()
                    .resideInAPackage("com.societyapp.service..")
                    .should(NOT_DEPEND_ON_OTHER_INTERACTORS);

    @ArchTest
    static final ArchRule coreDoesNotDependOnHttpCommonPackage =
            noClasses()
                    .that()
                    .resideInAnyPackage(
                            "com.societyapp.entity..",
                            "com.societyapp.domain..",
                            "com.societyapp.service..",
                            "com.societyapp.repository..",
                            "com.societyapp.application..")
                    .should()
                    .dependOnClassesThat()
                    .resideInAPackage("com.societyapp.common..");

    @ArchTest
    static final ArchRule applicationBoundariesDoNotExposeFilesystemPaths =
            noClasses()
                    .that()
                    .resideInAPackage("com.societyapp.application.port..")
                    .should()
                    .dependOnClassesThat()
                    .resideInAPackage("java.nio.file..");

    private static String topLevelName(String className) {
        int nestedClass = className.indexOf('$');
        return nestedClass < 0 ? className : className.substring(0, nestedClass);
    }
}
