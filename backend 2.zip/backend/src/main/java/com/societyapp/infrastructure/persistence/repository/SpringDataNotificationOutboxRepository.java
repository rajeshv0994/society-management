package com.societyapp.infrastructure.persistence.repository;

import com.societyapp.domain.model.NotificationOutbox;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpringDataNotificationOutboxRepository
        extends JpaRepository<NotificationOutbox, UUID>,
                com.societyapp.application.port.out.persistence.NotificationOutboxRepository {
    List<NotificationOutbox> findAllByOrderByCreatedAtDesc();

    List<NotificationOutbox> findBySocietyIdOrderByCreatedAtDesc(UUID societyId);
}
