package com.societyapp.application.usecase;

import com.societyapp.application.port.in.SocietyFinanceUseCase;
import com.societyapp.application.port.in.StructureAccessUseCase;
import com.societyapp.application.port.out.persistence.*;
import com.societyapp.domain.model.*;
import com.societyapp.domain.type.ExpenseCategory;
import com.societyapp.domain.type.FinanceFrequency;
import com.societyapp.domain.type.MemberChargeType;
import com.societyapp.domain.type.PaymentMethod;
import com.societyapp.domain.type.PaymentStatus;
import com.societyapp.domain.type.UserRole;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;

public class SocietyFinanceService implements SocietyFinanceUseCase {
    private static final Set<PaymentMethod> PAYMENT_METHODS =
            Set.of(
                    PaymentMethod.CASH,
                    PaymentMethod.CHEQUE,
                    PaymentMethod.BANK_TRANSFER,
                    PaymentMethod.UPI,
                    PaymentMethod.CARD);

    private final SocietyExpenseRepository expenses;
    private final MemberChargeSettingRepository settings;
    private final SocietyBudgetRepository budgets;
    private final SocietyBudgetAdditionRepository budgetAdditions;
    private final PaymentRepository memberPayments;
    private final StaffSalaryPaymentRepository salaryPayments;
    private final StaffProfileRepository staffProfiles;
    private final UserAccountJpaRepository users;
    private final FlatRepository flats;
    private final StructureAccessUseCase access;

    public SocietyFinanceService(
            SocietyExpenseRepository expenses,
            MemberChargeSettingRepository settings,
            SocietyBudgetRepository budgets,
            SocietyBudgetAdditionRepository budgetAdditions,
            PaymentRepository memberPayments,
            StaffSalaryPaymentRepository salaryPayments,
            StaffProfileRepository staffProfiles,
            UserAccountJpaRepository users,
            FlatRepository flats,
            StructureAccessUseCase access) {
        this.expenses = expenses;
        this.settings = settings;
        this.budgets = budgets;
        this.budgetAdditions = budgetAdditions;
        this.memberPayments = memberPayments;
        this.salaryPayments = salaryPayments;
        this.staffProfiles = staffProfiles;
        this.users = users;
        this.flats = flats;
        this.access = access;
    }

    public List<Map<String, Object>> expenses(UUID societyId) {
        return expenses.findBySocietyIdOrderByExpenseDateDescCreatedAtDesc(societyId).stream()
                .map(this::expenseView)
                .toList();
    }

    public Map<String, Object> createExpense(
            UUID societyId,
            UUID actorId,
            String category,
            String vendor,
            String description,
            BigDecimal amount,
            LocalDate expenseDate,
            String paymentMethod,
            String reference) {
        var requestedCategory = ExpenseCategory.from(category);
        var requestedMethod = PaymentMethod.from(paymentMethod);
        if (!PAYMENT_METHODS.contains(requestedMethod))
            throw new IllegalArgumentException("Invalid payment method");
        if (Set.of(PaymentMethod.CHEQUE, PaymentMethod.BANK_TRANSFER).contains(requestedMethod)
                && (reference == null || reference.isBlank())) {
            throw new IllegalArgumentException("Payment reference is required");
        }
        var item = new SocietyExpense();
        item.setSocietyId(societyId);
        item.setCategory(requestedCategory.code());
        item.setVendor(blankToNull(vendor));
        item.setDescription(description.trim());
        item.setAmount(amount);
        item.setExpenseDate(expenseDate);
        item.setPaymentMethod(requestedMethod.code());
        item.setPaymentReference(blankToNull(reference));
        item.setCreatedBy(actorId);
        item.setCreatedAt(OffsetDateTime.now());
        item = expenses.save(item);
        return Map.of("id", item.getId(), "amount", item.getAmount());
    }

    public List<Map<String, Object>> chargeSettings(UUID societyId, UUID userId, String role) {
        return settings.findBySocietyIdOrderByName(societyId).stream()
                .filter(MemberChargeSetting::isActive)
                .filter(
                        item ->
                                !UserRole.RESIDENT.matches(role)
                                        || item.getFlatId() == null
                                        || access.occupiedBy(item.getFlatId(), userId))
                .map(this::settingView)
                .toList();
    }

    public Map<String, Object> createChargeSetting(
            UUID societyId,
            String name,
            String chargeType,
            BigDecimal amount,
            String frequency,
            String description,
            UUID flatId) {
        var requestedChargeType = MemberChargeType.from(chargeType);
        var requestedFrequency = FinanceFrequency.from(frequency);
        if (flatId != null) access.requireFlat(flatId, societyId);
        var item = new MemberChargeSetting();
        item.setSocietyId(societyId);
        item.setFlatId(flatId);
        item.setName(name.trim());
        item.setChargeType(requestedChargeType.code());
        item.setAmount(amount);
        item.setFrequency(requestedFrequency.code());
        item.setDescription(blankToNull(description));
        item.setActive(true);
        item.setCreatedAt(OffsetDateTime.now());
        item = settings.save(item);
        return Map.of("id", item.getId(), "name", item.getName());
    }

    public Map<String, Object> financeSummary(UUID societyId, int year) {
        LocalDate from = LocalDate.of(year, 1, 1);
        LocalDate to = LocalDate.of(year, 12, 31);
        BigDecimal expenseTotal =
                expenses.findBySocietyIdOrderByExpenseDateDescCreatedAtDesc(societyId).stream()
                        .filter(
                                item ->
                                        !item.getExpenseDate().isBefore(from)
                                                && !item.getExpenseDate().isAfter(to))
                        .map(SocietyExpense::getAmount)
                        .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal salaryTotal =
                salaryPayments
                        .findBySocietyIdAndPaidOnBetweenOrderByPaidOnDesc(societyId, from, to)
                        .stream()
                        .map(StaffSalaryPayment::getAmount)
                        .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal received =
                memberPayments.findBySocietyIdOrderByPaidAtDesc(societyId).stream()
                        .filter(
                                payment ->
                                        !payment.getPaidAt().toLocalDate().isBefore(from)
                                                && !payment.getPaidAt().toLocalDate().isAfter(to)
                                                && PaymentStatus.SUCCESS.matches(
                                                        payment.getStatus()))
                        .map(Payment::getAmount)
                        .reduce(BigDecimal.ZERO, BigDecimal::add);
        var additions =
                budgetAdditions.findBySocietyIdAndBudgetYearOrderByAddedAtDesc(societyId, year);
        BigDecimal manualBudget =
                additions.stream()
                        .map(SocietyBudgetAddition::getAmount)
                        .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal budget = received.add(manualBudget);
        BigDecimal spent = expenseTotal.add(salaryTotal);
        var result = new LinkedHashMap<String, Object>();
        result.put("year", year);
        result.put("total_budget", budget);
        result.put("received_payments", received);
        result.put("manual_budget", manualBudget);
        result.put("expense_spent", expenseTotal);
        result.put("salary_spent", salaryTotal);
        result.put("total_spent", spent);
        BigDecimal balance = budget.subtract(spent);
        result.put("remaining", balance.max(BigDecimal.ZERO));
        result.put("over_budget", balance.signum() < 0 ? balance.abs() : BigDecimal.ZERO);
        result.put(
                "budget_additions",
                additions.stream()
                        .map(
                                item -> {
                                    var row = new LinkedHashMap<String, Object>();
                                    row.put("id", item.getId());
                                    row.put("amount", item.getAmount());
                                    row.put("note", item.getNote());
                                    row.put("added_at", item.getAddedAt());
                                    return (Map<String, Object>) row;
                                })
                        .toList());
        return result;
    }

    public Map<String, Object> addBudget(
            UUID societyId, UUID actorId, int year, BigDecimal amount, String note) {
        var addition = new SocietyBudgetAddition();
        addition.setSocietyId(societyId);
        addition.setBudgetYear(year);
        addition.setAmount(amount);
        addition.setNote(blankToNull(note));
        addition.setAddedBy(actorId);
        addition.setAddedAt(OffsetDateTime.now());
        addition = budgetAdditions.save(addition);
        return Map.of("id", addition.getId(), "amount", addition.getAmount());
    }

    public Map<String, Object> setBudget(
            UUID societyId, UUID actorId, int year, BigDecimal amount) {
        var budget =
                budgets.findBySocietyIdAndBudgetYear(societyId, year).orElseGet(SocietyBudget::new);
        if (budget.getId() == null) {
            budget.setSocietyId(societyId);
            budget.setBudgetYear(year);
        }
        budget.setAmount(amount);
        budget.setUpdatedBy(actorId);
        budget.setUpdatedAt(OffsetDateTime.now());
        budget = budgets.save(budget);
        return Map.of("year", year, "amount", budget.getAmount());
    }

    public List<Map<String, Object>> staffSalaries(UUID societyId) {
        return users
                .findBySocietyIdAndRoleOrderByFullName(societyId, UserRole.STAFF.code())
                .stream()
                .map(
                        user -> {
                            var map = new LinkedHashMap<String, Object>();
                            map.put("staff_id", user.getId());
                            map.put("staff_name", user.getFullName());
                            staffProfiles
                                    .findById(user.getId())
                                    .ifPresent(
                                            profile -> {
                                                map.put("staff_type", profile.getStaffType());
                                                map.put(
                                                        "monthly_salary",
                                                        profile.getMonthlySalary());
                                            });
                            var history =
                                    salaryPayments
                                            .findByStaffUserIdOrderBySalaryMonthDesc(user.getId())
                                            .stream()
                                            .map(
                                                    payment -> {
                                                        var row =
                                                                new LinkedHashMap<String, Object>();
                                                        row.put("id", payment.getId());
                                                        row.put(
                                                                "salary_month",
                                                                payment.getSalaryMonth());
                                                        row.put("amount", payment.getAmount());
                                                        row.put("paid_on", payment.getPaidOn());
                                                        row.put(
                                                                "payment_method",
                                                                payment.getPaymentMethod());
                                                        row.put(
                                                                "reference_number",
                                                                payment.getReferenceNumber());
                                                        return (Map<String, Object>) row;
                                                    })
                                            .toList();
                            map.put("payments", history);
                            return (Map<String, Object>) map;
                        })
                .toList();
    }

    private Map<String, Object> expenseView(SocietyExpense item) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", item.getId());
        map.put("category", item.getCategory());
        map.put("vendor", item.getVendor());
        map.put("description", item.getDescription());
        map.put("amount", item.getAmount());
        map.put("expense_date", item.getExpenseDate());
        map.put("payment_method", item.getPaymentMethod());
        map.put("payment_reference", item.getPaymentReference());
        map.put("created_at", item.getCreatedAt());
        return map;
    }

    private Map<String, Object> settingView(MemberChargeSetting item) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", item.getId());
        map.put("flat_id", item.getFlatId());
        map.put("name", item.getName());
        map.put("charge_type", item.getChargeType());
        map.put("amount", item.getAmount());
        map.put("frequency", item.getFrequency());
        map.put("description", item.getDescription());
        if (item.getFlatId() != null) {
            flats.findById(item.getFlatId())
                    .ifPresent(
                            flat -> {
                                map.put("space_number", flat.getFlatNumber());
                                UUID residentId =
                                        flat.getActiveTenantId() != null
                                                ? flat.getActiveTenantId()
                                                : flat.getActiveOwnerId();
                                if (residentId != null)
                                    users.findById(residentId)
                                            .ifPresent(
                                                    user ->
                                                            map.put(
                                                                    "resident_name",
                                                                    user.getFullName()));
                            });
        }
        return map;
    }

    private String normalized(String value) {
        return value == null ? "" : value.trim().toUpperCase();
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
