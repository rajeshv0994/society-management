package com.societyapp.application.usecase;

import com.societyapp.application.exception.AuthorizationException;
import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.port.in.DeliveryUseCase;
import com.societyapp.application.port.in.StructureAccessUseCase;
import com.societyapp.application.port.out.persistence.*;
import com.societyapp.domain.model.*;
import com.societyapp.domain.type.AccountStatus;
import com.societyapp.domain.type.DeliveryAction;
import com.societyapp.domain.type.DeliveryDecision;
import com.societyapp.domain.type.DeliveryStatus;
import com.societyapp.domain.type.NotificationStatus;
import com.societyapp.domain.type.PaymentMethod;
import com.societyapp.domain.type.PaymentStatus;
import com.societyapp.domain.type.StaffPermissionCode;
import com.societyapp.domain.type.UserRole;
import java.math.BigDecimal;
import java.security.SecureRandom;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class DeliveryService implements DeliveryUseCase {
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final Set<String> OPEN_STATUSES =
            Set.of(
                    DeliveryStatus.EXPECTED.code(),
                    DeliveryStatus.RECEIVED.code(),
                    DeliveryStatus.READY_FOR_PICKUP.code(),
                    DeliveryStatus.OUT_FOR_DELIVERY.code(),
                    DeliveryStatus.REJECTED.code(),
                    DeliveryStatus.DAMAGED.code());
    private static final Set<PaymentMethod> ONLINE_METHODS =
            Set.of(PaymentMethod.UPI, PaymentMethod.CARD, PaymentMethod.NET_BANKING);

    private final DeliveryRepository deliveries;
    private final DeliveryEventRepository events;
    private final UserAccountJpaRepository users;
    private final FlatRepository flats;
    private final FloorRepository floors;
    private final BlockRepository blocks;
    private final StructureAccessUseCase access;
    private final StaffPermissionRepository permissions;
    private final SocietyPaymentSettingRepository paymentSettings;
    private final NotificationOutboxRepository notifications;

    public DeliveryService(
            DeliveryRepository deliveries,
            DeliveryEventRepository events,
            UserAccountJpaRepository users,
            FlatRepository flats,
            FloorRepository floors,
            BlockRepository blocks,
            StructureAccessUseCase access,
            StaffPermissionRepository permissions,
            SocietyPaymentSettingRepository paymentSettings,
            NotificationOutboxRepository notifications) {
        this.deliveries = deliveries;
        this.events = events;
        this.users = users;
        this.flats = flats;
        this.floors = floors;
        this.blocks = blocks;
        this.access = access;
        this.permissions = permissions;
        this.paymentSettings = paymentSettings;
        this.notifications = notifications;
    }

    public Map<String, Object> workspace(UUID societyId, UUID actorId, String role) {
        if (UserRole.STAFF.matches(role)) requireManager(actorId, role);
        var rows =
                UserRole.RESIDENT.matches(role)
                        ? deliveries.findBySocietyIdAndResidentIdOrderByCreatedAtDesc(
                                societyId, actorId)
                        : deliveries.findBySocietyIdOrderByCreatedAtDesc(societyId);
        var result = new LinkedHashMap<String, Object>();
        result.put("deliveries", rows.stream().map(item -> view(item, role)).toList());
        result.put("options", options(societyId, actorId, role));
        result.put("total", rows.size());
        result.put(
                "awaiting_action",
                rows.stream().filter(item -> OPEN_STATUSES.contains(item.getStatus())).count());
        result.put(
                "ready_for_pickup",
                rows.stream()
                        .filter(item -> DeliveryStatus.READY_FOR_PICKUP.matches(item.getStatus()))
                        .count());
        result.put(
                "completed",
                rows.stream()
                        .filter(
                                item ->
                                        Set.of(
                                                        DeliveryStatus.COLLECTED.code(),
                                                        DeliveryStatus.DELIVERED.code())
                                                .contains(item.getStatus()))
                        .count());
        result.put(
                "pending_cod",
                rows.stream()
                        .filter(item -> PaymentStatus.PENDING.matches(item.getCodPaymentStatus()))
                        .count());
        return result;
    }

    public List<Map<String, Object>> history(
            UUID societyId, UUID actorId, String role, UUID deliveryId) {
        if (UserRole.STAFF.matches(role)) requireManager(actorId, role);
        var delivery = requireDelivery(societyId, deliveryId);
        requireOwnerOrManager(delivery, actorId, role);
        return events.findByDeliveryIdOrderByOccurredAt(deliveryId).stream()
                .map(this::eventView)
                .toList();
    }

    public Map<String, Object> create(
            UUID societyId,
            UUID actorId,
            String role,
            UUID requestedResidentId,
            UUID flatId,
            String trackingNumber,
            String provider,
            String senderName,
            String deliveryPersonName,
            String deliveryPersonMobile,
            String parcelType,
            int packageCount,
            String parcelSize,
            boolean fragile,
            String storageLocation,
            OffsetDateTime expectedAt,
            String notes,
            BigDecimal codAmount,
            boolean receivedNow) {
        UUID residentId;
        if (UserRole.RESIDENT.matches(role)) {
            residentId = actorId;
            receivedNow = false;
        } else {
            requireManager(actorId, role);
            if (requestedResidentId == null) {
                throw new IllegalArgumentException("Resident is required");
            }
            residentId = requestedResidentId;
        }
        var resident = requireResident(societyId, residentId);
        access.requireFlat(flatId, societyId);
        if (!access.occupiedBy(flatId, residentId)) {
            throw new IllegalArgumentException("Resident does not occupy the selected space");
        }
        if (!receivedNow
                && expectedAt != null
                && expectedAt.isBefore(OffsetDateTime.now().minusMinutes(5))) {
            throw new IllegalArgumentException("Expected delivery time cannot be in the past");
        }
        var item = new Delivery();
        item.setSocietyId(societyId);
        item.setFlatId(flatId);
        item.setResidentId(residentId);
        item.setDeliveryNumber(deliveryNumber());
        item.setTrackingNumber(normalizeTracking(trackingNumber));
        item.setProvider(provider.trim());
        item.setSenderName(blankToNull(senderName));
        item.setDeliveryPersonName(blankToNull(deliveryPersonName));
        item.setDeliveryPersonMobile(blankToNull(deliveryPersonMobile));
        item.setParcelType(parcelType);
        item.setPackageCount(packageCount);
        item.setParcelSize(parcelSize);
        item.setFragile(fragile);
        item.setStorageLocation(blankToNull(storageLocation));
        item.setExpectedAt(expectedAt);
        item.setNotes(blankToNull(notes));
        item.setCodAmount(codAmount == null ? BigDecimal.ZERO : codAmount);
        item.setCodPaymentStatus(
                item.getCodAmount().signum() > 0
                        ? PaymentStatus.PENDING.code()
                        : PaymentStatus.NOT_REQUIRED.code());
        item.setStatus(
                receivedNow ? DeliveryStatus.RECEIVED.code() : DeliveryStatus.EXPECTED.code());
        item.setCreatedBy(actorId);
        item.setCreatedAt(OffsetDateTime.now());
        item.setUpdatedAt(OffsetDateTime.now());
        if (receivedNow) {
            item.setReceivedBy(actorId);
            item.setReceivedAt(OffsetDateTime.now());
            item.setPickupCode(pickupCode());
        }
        item = deliveries.save(item);
        addEvent(item, actorId, role, "CREATED", null, item.getStatus(), notes);
        if (receivedNow) notifyResident(resident, item, "DELIVERY_RECEIVED");
        return view(item, role);
    }

    public Map<String, Object> action(
            UUID societyId,
            UUID actorId,
            String role,
            UUID deliveryId,
            String action,
            String note,
            String collectorName,
            String pickupCode) {
        var item = requireDelivery(societyId, deliveryId);
        String oldStatus = item.getStatus();
        var requestedAction = DeliveryAction.from(action);
        switch (requestedAction) {
            case ACCEPT -> {
                requireResidentOwner(item, actorId, role);
                requireStatus(item, DeliveryStatus.RECEIVED);
                item.setResidentDecision(DeliveryDecision.ACCEPTED.code());
                item.setResidentDecisionAt(OffsetDateTime.now());
                item.setStatus(DeliveryStatus.READY_FOR_PICKUP.code());
            }
            case REJECT -> {
                requireResidentOwner(item, actorId, role);
                if (!Set.of(DeliveryStatus.RECEIVED.code(), DeliveryStatus.READY_FOR_PICKUP.code())
                        .contains(item.getStatus())) {
                    throw new IllegalStateException("Only a received delivery can be rejected");
                }
                requireNote(note, "Rejection reason is required");
                item.setResidentDecision(DeliveryDecision.REJECTED.code());
                item.setResidentDecisionAt(OffsetDateTime.now());
                item.setClosedReason(note.trim());
                item.setStatus(DeliveryStatus.REJECTED.code());
            }
            case AUTHORIZE -> {
                requireResidentOwner(item, actorId, role);
                if (!Set.of(DeliveryStatus.RECEIVED.code(), DeliveryStatus.READY_FOR_PICKUP.code())
                        .contains(item.getStatus())) {
                    throw new IllegalStateException("Delivery is not available for authorization");
                }
                if (collectorName == null || collectorName.isBlank()) {
                    throw new IllegalArgumentException("Authorized collector name is required");
                }
                item.setAuthorizedCollector(collectorName.trim());
                item.setResidentDecision(DeliveryDecision.ACCEPTED.code());
                item.setResidentDecisionAt(OffsetDateTime.now());
                item.setStatus(DeliveryStatus.READY_FOR_PICKUP.code());
            }
            case CANCEL -> {
                requireResidentOwner(item, actorId, role);
                requireStatus(item, DeliveryStatus.EXPECTED);
                item.setStatus(DeliveryStatus.CANCELLED.code());
                item.setClosedReason(blankToNull(note));
            }
            case RECEIVE -> {
                requireManager(actorId, role);
                requireStatus(item, DeliveryStatus.EXPECTED);
                item.setStatus(DeliveryStatus.RECEIVED.code());
                item.setReceivedBy(actorId);
                item.setReceivedAt(OffsetDateTime.now());
                item.setPickupCode(pickupCode());
                notifyResident(
                        requireResident(societyId, item.getResidentId()),
                        item,
                        "DELIVERY_RECEIVED");
            }
            case MARK_READY -> {
                requireManager(actorId, role);
                requireStatus(item, DeliveryStatus.RECEIVED);
                item.setStatus(DeliveryStatus.READY_FOR_PICKUP.code());
                notifyResident(
                        requireResident(societyId, item.getResidentId()), item, "DELIVERY_READY");
            }
            case OUT_FOR_DELIVERY -> {
                requireManager(actorId, role);
                requireAvailable(item);
                requireCodPaid(item);
                item.setStatus(DeliveryStatus.OUT_FOR_DELIVERY.code());
            }
            case HANDOVER -> {
                requireManager(actorId, role);
                if (!Set.of(DeliveryStatus.RECEIVED.code(), DeliveryStatus.READY_FOR_PICKUP.code())
                        .contains(item.getStatus())) {
                    throw new IllegalStateException("Delivery is not ready for handover");
                }
                requireCodPaid(item);
                if (pickupCode == null || !pickupCode.equals(item.getPickupCode())) {
                    throw new IllegalArgumentException("Invalid pickup code");
                }
                item.setCollectedByName(
                        collectorName == null || collectorName.isBlank()
                                ? requireResident(societyId, item.getResidentId()).getFullName()
                                : collectorName.trim());
                item.setHandedOverBy(actorId);
                item.setCollectedAt(OffsetDateTime.now());
                item.setStatus(DeliveryStatus.COLLECTED.code());
            }
            case DELIVER -> {
                requireManager(actorId, role);
                if (!Set.of(
                                DeliveryStatus.RECEIVED.code(),
                                DeliveryStatus.READY_FOR_PICKUP.code(),
                                DeliveryStatus.OUT_FOR_DELIVERY.code())
                        .contains(item.getStatus())) {
                    throw new IllegalStateException(
                            "Delivery cannot be delivered in its current state");
                }
                requireCodPaid(item);
                item.setHandedOverBy(actorId);
                item.setCollectedByName(blankToNull(collectorName));
                item.setDeliveredAt(OffsetDateTime.now());
                item.setStatus(DeliveryStatus.DELIVERED.code());
            }
            case RETURN -> {
                requireManager(actorId, role);
                if (!Set.of(
                                DeliveryStatus.RECEIVED.code(),
                                DeliveryStatus.READY_FOR_PICKUP.code(),
                                DeliveryStatus.REJECTED.code(),
                                DeliveryStatus.DAMAGED.code())
                        .contains(item.getStatus())) {
                    throw new IllegalStateException(
                            "Delivery cannot be returned in its current state");
                }
                requireNote(note, "Return reason is required");
                item.setClosedReason(note.trim());
                item.setReturnedAt(OffsetDateTime.now());
                item.setStatus(DeliveryStatus.RETURNED.code());
            }
            case DAMAGED -> {
                requireManager(actorId, role);
                requireAvailable(item);
                requireNote(note, "Damage details are required");
                item.setClosedReason(note.trim());
                item.setStatus(DeliveryStatus.DAMAGED.code());
            }
            case LOST -> {
                requireManager(actorId, role);
                requireAvailable(item);
                requireNote(note, "Loss details are required");
                item.setClosedReason(note.trim());
                item.setStatus(DeliveryStatus.LOST.code());
            }
        }
        item.setUpdatedAt(OffsetDateTime.now());
        item = deliveries.save(item);
        addEvent(item, actorId, role, requestedAction.code(), oldStatus, item.getStatus(), note);
        return view(item, role);
    }

    public Map<String, Object> checkout(
            UUID societyId, UUID actorId, String role, UUID deliveryId, String method) {
        var requestedMethod = PaymentMethod.from(method);
        if (!ONLINE_METHODS.contains(requestedMethod)) {
            throw new IllegalArgumentException("Invalid Razorpay payment method");
        }
        var item = requireDelivery(societyId, deliveryId);
        requireOwnerOrManager(item, actorId, role);
        requirePendingCod(item);
        var setting =
                paymentSettings
                        .findBySocietyId(societyId)
                        .orElseThrow(
                                () ->
                                        new IllegalStateException(
                                                "Society online payment account is not configured"));
        if (!setting.isTestMode()) {
            throw new IllegalStateException("Live Razorpay delivery payments are not enabled yet");
        }
        item.setCodPaymentStatus(PaymentStatus.PAID.code());
        item.setCodPaymentMethod("RAZORPAY_" + requestedMethod.code());
        item.setCodPaymentReference(
                "pay_delivery_test_"
                        + UUID.randomUUID().toString().replace("-", "").substring(0, 18));
        item.setCodPaidAt(OffsetDateTime.now());
        item.setUpdatedAt(OffsetDateTime.now());
        item = deliveries.save(item);
        addEvent(item, actorId, role, "COD_PAID_ONLINE", item.getStatus(), item.getStatus(), null);
        return view(item, role);
    }

    public Map<String, Object> recordCod(
            UUID societyId, UUID actorId, String role, UUID deliveryId, String method) {
        requireManager(actorId, role);
        var requestedMethod = PaymentMethod.from(method);
        if (!Set.of(PaymentMethod.CASH, PaymentMethod.UPI, PaymentMethod.CARD)
                .contains(requestedMethod)) {
            throw new IllegalArgumentException("Invalid COD collection method");
        }
        var item = requireDelivery(societyId, deliveryId);
        requirePendingCod(item);
        item.setCodPaymentStatus(PaymentStatus.PAID.code());
        item.setCodPaymentMethod(requestedMethod.code());
        item.setCodPaymentReference(
                "COD-"
                        + UUID.randomUUID()
                                .toString()
                                .replace("-", "")
                                .substring(0, 12)
                                .toUpperCase());
        item.setCodPaidAt(OffsetDateTime.now());
        item.setUpdatedAt(OffsetDateTime.now());
        item = deliveries.save(item);
        addEvent(
                item,
                actorId,
                role,
                "COD_RECORDED",
                item.getStatus(),
                item.getStatus(),
                requestedMethod.code());
        return view(item, role);
    }

    private List<Map<String, Object>> options(UUID societyId, UUID actorId, String role) {
        var result = new ArrayList<Map<String, Object>>();
        var residents =
                UserRole.RESIDENT.matches(role)
                        ? List.of(requireResident(societyId, actorId))
                        : users
                                .findBySocietyIdAndRoleOrderByFullName(
                                        societyId, UserRole.RESIDENT.code())
                                .stream()
                                .filter(user -> AccountStatus.ACTIVE.matches(user.getStatus()))
                                .toList();
        for (var resident : residents) {
            for (var flat : flats.findAll()) {
                if (!access.belongsToSociety(flat.getId(), societyId)
                        || !access.occupiedBy(flat.getId(), resident.getId())) continue;
                var row = new LinkedHashMap<String, Object>();
                row.put("resident_id", resident.getId());
                row.put("resident_name", resident.getFullName());
                row.put("resident_mobile", resident.getMobile());
                row.put("flat_id", flat.getId());
                row.put("space_number", flat.getFlatNumber());
                floors.findById(flat.getFloorId())
                        .flatMap(floor -> blocks.findById(floor.getBlockId()))
                        .ifPresent(block -> row.put("block", block.getName()));
                result.add(row);
            }
        }
        return result;
    }

    private void requireOwnerOrManager(Delivery item, UUID actorId, String role) {
        if (UserRole.RESIDENT.matches(role)) {
            requireResidentOwner(item, actorId, role);
        } else {
            requireManager(actorId, role);
        }
    }

    private void requireResidentOwner(Delivery item, UUID actorId, String role) {
        if (!UserRole.RESIDENT.matches(role) || !actorId.equals(item.getResidentId())) {
            throw new AuthorizationException("You can only manage your own deliveries");
        }
    }

    private void requireManager(UUID actorId, String role) {
        if (UserRole.SOCIETY_ADMIN.matches(role)) return;
        if (UserRole.STAFF.matches(role)
                && permissions.existsByStaffUserIdAndPermissionCode(
                        actorId, StaffPermissionCode.DELIVERIES.code())) return;
        throw new AuthorizationException("Deliveries permission is required");
    }

    private UserAccount requireResident(UUID societyId, UUID residentId) {
        return users.findById(residentId)
                .filter(user -> societyId.equals(user.getSocietyId()))
                .filter(user -> UserRole.RESIDENT.matches(user.getRole()))
                .orElseThrow(() -> new ResourceNotFoundException("Resident not found"));
    }

    private Delivery requireDelivery(UUID societyId, UUID deliveryId) {
        return deliveries
                .findByIdAndSocietyId(deliveryId, societyId)
                .orElseThrow(() -> new ResourceNotFoundException("Delivery not found"));
    }

    private void requireStatus(Delivery item, DeliveryStatus status) {
        if (!status.matches(item.getStatus())) {
            throw new IllegalStateException(
                    "Delivery must be " + status.code().toLowerCase(Locale.ROOT));
        }
    }

    private void requireAvailable(Delivery item) {
        if (!Set.of(
                        DeliveryStatus.RECEIVED.code(),
                        DeliveryStatus.READY_FOR_PICKUP.code(),
                        DeliveryStatus.OUT_FOR_DELIVERY.code())
                .contains(item.getStatus())) {
            throw new IllegalStateException("Delivery is not available");
        }
    }

    private void requirePendingCod(Delivery item) {
        if (!PaymentStatus.PENDING.matches(item.getCodPaymentStatus())) {
            throw new IllegalStateException("Delivery does not have a pending COD payment");
        }
    }

    private void requireCodPaid(Delivery item) {
        if (item.getCodAmount().signum() > 0
                && !PaymentStatus.PAID.matches(item.getCodPaymentStatus())) {
            throw new IllegalStateException("COD payment must be completed before handover");
        }
    }

    private void requireNote(String note, String message) {
        if (note == null || note.isBlank()) throw new IllegalArgumentException(message);
    }

    private void notifyResident(UserAccount resident, Delivery item, String template) {
        if (resident.getEmail() == null || resident.getEmail().isBlank()) return;
        var notification = new NotificationOutbox();
        notification.setSocietyId(item.getSocietyId());
        notification.setChannel("EMAIL");
        notification.setDestination(resident.getEmail());
        notification.setTemplateCode(template);
        notification.setPayload(
                "{\"deliveryNumber\":\""
                        + item.getDeliveryNumber()
                        + "\",\"provider\":\""
                        + item.getProvider().replace("\"", "")
                        + "\"}");
        notification.setStatus(NotificationStatus.PENDING.code());
        notification.setAttempts(0);
        notification.setCreatedAt(OffsetDateTime.now());
        notifications.save(notification);
    }

    private void addEvent(
            Delivery item,
            UUID actorId,
            String role,
            String eventType,
            String fromStatus,
            String toStatus,
            String note) {
        var event = new DeliveryEvent();
        event.setDeliveryId(item.getId());
        event.setSocietyId(item.getSocietyId());
        event.setEventType(eventType);
        event.setFromStatus(fromStatus);
        event.setToStatus(toStatus);
        event.setNote(blankToNull(note));
        event.setActorId(actorId);
        event.setActorRole(role);
        event.setOccurredAt(OffsetDateTime.now());
        events.save(event);
    }

    private Map<String, Object> view(Delivery item, String role) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", item.getId());
        map.put("delivery_number", item.getDeliveryNumber());
        map.put("tracking_number", item.getTrackingNumber());
        map.put("provider", item.getProvider());
        map.put("sender_name", item.getSenderName());
        map.put("delivery_person_name", item.getDeliveryPersonName());
        map.put("delivery_person_mobile", item.getDeliveryPersonMobile());
        map.put("parcel_type", item.getParcelType());
        map.put("package_count", item.getPackageCount());
        map.put("parcel_size", item.getParcelSize());
        map.put("fragile", item.isFragile());
        map.put("storage_location", item.getStorageLocation());
        map.put("expected_at", item.getExpectedAt());
        map.put("notes", item.getNotes());
        map.put("status", item.getStatus());
        map.put("resident_decision", item.getResidentDecision());
        map.put("authorized_collector", item.getAuthorizedCollector());
        map.put("pickup_code", UserRole.RESIDENT.matches(role) ? item.getPickupCode() : null);
        map.put("pickup_code_issued", item.getPickupCode() != null);
        map.put("cod_amount", item.getCodAmount());
        map.put("cod_payment_status", item.getCodPaymentStatus());
        map.put("cod_payment_method", item.getCodPaymentMethod());
        map.put("cod_payment_reference", item.getCodPaymentReference());
        map.put("received_at", item.getReceivedAt());
        map.put("collected_by_name", item.getCollectedByName());
        map.put("collected_at", item.getCollectedAt());
        map.put("delivered_at", item.getDeliveredAt());
        map.put("returned_at", item.getReturnedAt());
        map.put("closed_reason", item.getClosedReason());
        map.put("created_at", item.getCreatedAt());
        map.put("resident_id", item.getResidentId());
        users.findById(item.getResidentId())
                .ifPresent(
                        user -> {
                            map.put("resident_name", user.getFullName());
                            map.put("resident_mobile", user.getMobile());
                        });
        map.put("flat_id", item.getFlatId());
        flats.findById(item.getFlatId())
                .ifPresent(
                        flat -> {
                            map.put("space_number", flat.getFlatNumber());
                            floors.findById(flat.getFloorId())
                                    .flatMap(floor -> blocks.findById(floor.getBlockId()))
                                    .ifPresent(block -> map.put("block", block.getName()));
                        });
        return map;
    }

    private Map<String, Object> eventView(DeliveryEvent item) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", item.getId());
        map.put("event_type", item.getEventType());
        map.put("from_status", item.getFromStatus());
        map.put("to_status", item.getToStatus());
        map.put("note", item.getNote());
        map.put("actor_role", item.getActorRole());
        map.put("occurred_at", item.getOccurredAt());
        users.findById(item.getActorId())
                .ifPresent(user -> map.put("actor_name", user.getFullName()));
        return map;
    }

    private String deliveryNumber() {
        return "DLV-"
                + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMM"))
                + "-"
                + UUID.randomUUID().toString().replace("-", "").substring(0, 10).toUpperCase();
    }

    private String pickupCode() {
        return String.format("%06d", RANDOM.nextInt(1_000_000));
    }

    private String normalizeTracking(String value) {
        return value == null || value.isBlank()
                ? null
                : value.replaceAll("\\s+", "").toUpperCase(Locale.ROOT);
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
