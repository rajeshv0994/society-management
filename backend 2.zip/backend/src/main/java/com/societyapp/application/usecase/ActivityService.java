package com.societyapp.application.usecase;

import com.societyapp.application.exception.AuthorizationException;
import com.societyapp.application.exception.ConflictException;
import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.port.in.ActivityUseCase;
import com.societyapp.application.port.out.DocumentStorage;
import com.societyapp.application.port.out.UploadedFile;
import com.societyapp.application.port.out.persistence.*;
import com.societyapp.domain.model.*;
import com.societyapp.domain.type.AccountStatus;
import com.societyapp.domain.type.ActivityAction;
import com.societyapp.domain.type.ActivityStatus;
import com.societyapp.domain.type.ModerationStatus;
import com.societyapp.domain.type.NotificationStatus;
import com.societyapp.domain.type.ParticipationAction;
import com.societyapp.domain.type.ParticipationStatus;
import com.societyapp.domain.type.PaymentMethod;
import com.societyapp.domain.type.PaymentStatus;
import com.societyapp.domain.type.PhotoAction;
import com.societyapp.domain.type.StaffPermissionCode;
import com.societyapp.domain.type.UserRole;
import java.math.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class ActivityService implements ActivityUseCase {
    private static final Set<String> CAPACITY_STATUSES =
            Set.of(
                    PaymentStatus.PENDING_PAYMENT.code(),
                    ParticipationStatus.PENDING_APPROVAL.code(),
                    ParticipationStatus.CONFIRMED.code(),
                    ParticipationStatus.CHECKED_IN.code(),
                    ParticipationStatus.ATTENDED.code());
    private static final Set<PaymentMethod> ONLINE_METHODS =
            Set.of(PaymentMethod.UPI, PaymentMethod.CARD, PaymentMethod.NET_BANKING);

    private final SocietyActivityRepository activities;
    private final ActivityParticipationRepository participations;
    private final ActivityGalleryPhotoRepository photos;
    private final ActivityEventRepository events;
    private final UserAccountJpaRepository users;
    private final StaffPermissionRepository permissions;
    private final SocietyPaymentSettingRepository paymentSettings;
    private final NotificationOutboxRepository notifications;
    private final DocumentStorage storage;

    public ActivityService(
            SocietyActivityRepository activities,
            ActivityParticipationRepository participations,
            ActivityGalleryPhotoRepository photos,
            ActivityEventRepository events,
            UserAccountJpaRepository users,
            StaffPermissionRepository permissions,
            SocietyPaymentSettingRepository paymentSettings,
            NotificationOutboxRepository notifications,
            DocumentStorage storage) {
        this.activities = activities;
        this.participations = participations;
        this.photos = photos;
        this.events = events;
        this.users = users;
        this.permissions = permissions;
        this.paymentSettings = paymentSettings;
        this.notifications = notifications;
        this.storage = storage;
    }

    public Map<String, Object> workspace(UUID societyId, UUID actorId, String role) {
        if (UserRole.STAFF.matches(role)) requireManager(actorId, role);
        var activityRows =
                activities.findBySocietyIdOrderByStartsAtDesc(societyId).stream()
                        .filter(
                                item ->
                                        !UserRole.RESIDENT.matches(role)
                                                || Set.of(
                                                                ActivityStatus.PUBLISHED.code(),
                                                                ActivityStatus.COMPLETED.code(),
                                                                ActivityStatus.CANCELLED.code())
                                                        .contains(item.getStatus()))
                        .toList();
        var participationRows =
                UserRole.RESIDENT.matches(role)
                        ? participations.findBySocietyIdAndParticipantIdOrderByCreatedAtDesc(
                                societyId, actorId)
                        : participations.findBySocietyIdOrderByCreatedAtDesc(societyId);
        var photoRows =
                photos.findBySocietyIdOrderByCreatedAtDesc(societyId).stream()
                        .filter(
                                item ->
                                        !UserRole.RESIDENT.matches(role)
                                                || ModerationStatus.PUBLISHED.matches(
                                                        item.getModerationStatus())
                                                || actorId.equals(item.getSubmittedBy()))
                        .toList();
        var result = new LinkedHashMap<String, Object>();
        result.put(
                "activities",
                activityRows.stream().map(item -> activityView(item, actorId)).toList());
        result.put(
                "participations", participationRows.stream().map(this::participationView).toList());
        result.put("photos", photoRows.stream().map(this::photoView).toList());
        result.put("total_activities", activityRows.size());
        result.put(
                "upcoming",
                activityRows.stream()
                        .filter(item -> ActivityStatus.PUBLISHED.matches(item.getStatus()))
                        .filter(item -> item.getStartsAt().isAfter(OffsetDateTime.now()))
                        .count());
        result.put(
                "my_registrations",
                participationRows.stream()
                        .filter(item -> actorId.equals(item.getParticipantId()))
                        .filter(item -> CAPACITY_STATUSES.contains(item.getStatus()))
                        .count());
        result.put(
                "pending_payments",
                participationRows.stream()
                        .filter(item -> PaymentStatus.PENDING.matches(item.getPaymentStatus()))
                        .count());
        result.put(
                "pending_approvals",
                participationRows.stream()
                        .filter(
                                item ->
                                        ParticipationStatus.PENDING_APPROVAL.matches(
                                                item.getStatus()))
                        .count());
        result.put(
                "pending_photos",
                photoRows.stream()
                        .filter(
                                item ->
                                        ModerationStatus.PENDING.matches(
                                                item.getModerationStatus()))
                        .count());
        return result;
    }

    public Map<String, Object> create(
            UUID societyId,
            UUID actorId,
            String role,
            String title,
            String category,
            String description,
            String venue,
            OffsetDateTime startsAt,
            OffsetDateTime endsAt,
            OffsetDateTime registrationOpensAt,
            OffsetDateTime registrationClosesAt,
            Integer capacity,
            BigDecimal feePerPerson,
            boolean approvalRequired,
            int cancellationHours,
            String audience,
            String organizerName,
            String organizerMobile,
            String instructions,
            boolean publishNow) {
        requireAdmin(role);
        validateSchedule(startsAt, endsAt, registrationOpensAt, registrationClosesAt, capacity);
        var item = new SocietyActivity();
        item.setSocietyId(societyId);
        item.setActivityCode(activityCode());
        item.setCreatedBy(actorId);
        item.setCreatedAt(OffsetDateTime.now());
        apply(
                item,
                title,
                category,
                description,
                venue,
                startsAt,
                endsAt,
                registrationOpensAt,
                registrationClosesAt,
                capacity,
                feePerPerson,
                approvalRequired,
                cancellationHours,
                audience,
                organizerName,
                organizerMobile,
                instructions);
        item.setStatus(publishNow ? ActivityStatus.PUBLISHED.code() : ActivityStatus.DRAFT.code());
        if (publishNow) item.setPublishedAt(OffsetDateTime.now());
        item = activities.save(item);
        addEvent(item, null, actorId, role, publishNow ? "CREATED_AND_PUBLISHED" : "CREATED", null);
        if (publishNow) notifyResidents(societyId, item, "ACTIVITY_PUBLISHED");
        return activityView(item, actorId);
    }

    public Map<String, Object> update(
            UUID societyId,
            UUID actorId,
            String role,
            UUID activityId,
            String title,
            String category,
            String description,
            String venue,
            OffsetDateTime startsAt,
            OffsetDateTime endsAt,
            OffsetDateTime registrationOpensAt,
            OffsetDateTime registrationClosesAt,
            Integer capacity,
            BigDecimal feePerPerson,
            boolean approvalRequired,
            int cancellationHours,
            String audience,
            String organizerName,
            String organizerMobile,
            String instructions) {
        requireAdmin(role);
        var item = requireActivity(societyId, activityId);
        if (!Set.of(ActivityStatus.DRAFT.code(), ActivityStatus.PUBLISHED.code())
                .contains(item.getStatus())) {
            throw new IllegalStateException("Only draft or published activities can be edited");
        }
        validateSchedule(startsAt, endsAt, registrationOpensAt, registrationClosesAt, capacity);
        int registered = registeredCount(activityId);
        if (capacity != null && capacity < registered) {
            throw new IllegalArgumentException(
                    "Capacity cannot be below " + registered + " registered participants");
        }
        if (participations.findByActivityId(activityId).stream()
                        .anyMatch(row -> CAPACITY_STATUSES.contains(row.getStatus()))
                && item.getFeePerPerson().compareTo(feePerPerson) != 0) {
            throw new IllegalStateException("Fee cannot change after registrations exist");
        }
        apply(
                item,
                title,
                category,
                description,
                venue,
                startsAt,
                endsAt,
                registrationOpensAt,
                registrationClosesAt,
                capacity,
                feePerPerson,
                approvalRequired,
                cancellationHours,
                audience,
                organizerName,
                organizerMobile,
                instructions);
        item = activities.save(item);
        addEvent(item, null, actorId, role, "UPDATED", null);
        return activityView(item, actorId);
    }

    public Map<String, Object> activityAction(
            UUID societyId,
            UUID actorId,
            String role,
            UUID activityId,
            String action,
            String reason) {
        requireAdmin(role);
        var item = requireActivity(societyId, activityId);
        var requestedAction = ActivityAction.from(action);
        switch (requestedAction) {
            case PUBLISH -> {
                requireActivityStatus(item, ActivityStatus.DRAFT);
                if (!item.getStartsAt().isAfter(OffsetDateTime.now())) {
                    throw new IllegalStateException("A past activity cannot be published");
                }
                item.setStatus(ActivityStatus.PUBLISHED.code());
                item.setPublishedAt(OffsetDateTime.now());
                notifyResidents(societyId, item, "ACTIVITY_PUBLISHED");
            }
            case CANCEL -> {
                if (!Set.of(ActivityStatus.DRAFT.code(), ActivityStatus.PUBLISHED.code())
                        .contains(item.getStatus())) {
                    throw new IllegalStateException("Activity cannot be cancelled");
                }
                requireReason(reason, "Cancellation reason is required");
                item.setStatus(ActivityStatus.CANCELLED.code());
                item.setCancellationReason(reason.trim());
                for (var row : participations.findByActivityId(activityId)) {
                    if (!CAPACITY_STATUSES.contains(row.getStatus())) continue;
                    row.setStatus(ParticipationStatus.CANCELLED.code());
                    row.setCancelledAt(OffsetDateTime.now());
                    if (PaymentStatus.PAID.matches(row.getPaymentStatus())) {
                        row.setPaymentStatus(PaymentStatus.REFUND_PENDING.code());
                    }
                    row.setUpdatedAt(OffsetDateTime.now());
                    participations.save(row);
                    notifyUser(row.getParticipantId(), item, "ACTIVITY_CANCELLED");
                }
            }
            case COMPLETE -> {
                requireActivityStatus(item, ActivityStatus.PUBLISHED);
                if (OffsetDateTime.now().isBefore(item.getStartsAt())) {
                    throw new IllegalStateException("Activity has not started yet");
                }
                item.setStatus(ActivityStatus.COMPLETED.code());
                item.setCompletedAt(OffsetDateTime.now());
            }
            case ARCHIVE -> {
                if (!Set.of(ActivityStatus.COMPLETED.code(), ActivityStatus.CANCELLED.code())
                        .contains(item.getStatus())) {
                    throw new IllegalStateException(
                            "Only completed or cancelled activities can be archived");
                }
                item.setStatus(ActivityStatus.ARCHIVED.code());
            }
        }
        item.setUpdatedAt(OffsetDateTime.now());
        item = activities.save(item);
        addEvent(item, null, actorId, role, requestedAction.code(), reason);
        return activityView(item, actorId);
    }

    public Map<String, Object> join(
            UUID societyId,
            UUID actorId,
            String role,
            UUID activityId,
            int count,
            String names,
            String mobile,
            String notes) {
        if (!UserRole.RESIDENT.matches(role)) {
            throw new AuthorizationException("Only members can register for activities");
        }
        var item = requireActivity(societyId, activityId);
        requireActivityStatus(item, ActivityStatus.PUBLISHED);
        var now = OffsetDateTime.now();
        if (now.isBefore(item.getRegistrationOpensAt())
                || now.isAfter(item.getRegistrationClosesAt())) {
            throw new IllegalStateException("Activity registration is not open");
        }
        if (participations.findByActivityIdAndParticipantId(activityId, actorId).isPresent()) {
            throw new ConflictException("You already registered for this activity");
        }
        int registered = registeredCount(activityId);
        if (item.getCapacity() != null && registered + count > item.getCapacity()) {
            throw new ConflictException(
                    "Only " + Math.max(0, item.getCapacity() - registered) + " places remain");
        }
        var row = new ActivityParticipation();
        row.setSocietyId(societyId);
        row.setActivityId(activityId);
        row.setParticipantId(actorId);
        row.setParticipantCount(count);
        row.setParticipantNames(blankToNull(names));
        row.setContactMobile(blankToNull(mobile));
        row.setNotes(blankToNull(notes));
        row.setAmount(item.getFeePerPerson().multiply(BigDecimal.valueOf(count)));
        row.setPaymentStatus(
                row.getAmount().signum() == 0
                        ? PaymentStatus.FREE.code()
                        : PaymentStatus.PENDING.code());
        row.setStatus(
                row.getAmount().signum() > 0
                        ? PaymentStatus.PENDING_PAYMENT.code()
                        : item.isApprovalRequired()
                                ? ParticipationStatus.PENDING_APPROVAL.code()
                                : ParticipationStatus.CONFIRMED.code());
        row.setCreatedAt(now);
        row.setUpdatedAt(now);
        row = participations.save(row);
        addEvent(item, row, actorId, role, "REGISTERED", notes);
        notifyUser(actorId, item, "ACTIVITY_REGISTRATION_CREATED");
        return participationView(row);
    }

    public Map<String, Object> checkout(
            UUID societyId, UUID actorId, String role, UUID participationId, String method) {
        var requestedMethod = PaymentMethod.from(method);
        if (!ONLINE_METHODS.contains(requestedMethod)) {
            throw new IllegalArgumentException("Invalid Razorpay payment method");
        }
        var row = requireParticipation(societyId, participationId);
        requireOwnerOrManager(row, actorId, role);
        requirePendingPayment(row);
        var setting =
                paymentSettings
                        .findBySocietyId(societyId)
                        .orElseThrow(
                                () ->
                                        new IllegalStateException(
                                                "Society online payment account is not configured"));
        if (!setting.isTestMode()) {
            throw new IllegalStateException("Live Razorpay activity payments are not enabled yet");
        }
        row.setPaymentStatus(PaymentStatus.PAID.code());
        row.setPaymentMethod(requestedMethod.razorpayCode());
        row.setPaymentReference(
                "pay_activity_test_"
                        + UUID.randomUUID().toString().replace("-", "").substring(0, 18));
        row.setPaidAt(OffsetDateTime.now());
        moveAfterPayment(row);
        row.setUpdatedAt(OffsetDateTime.now());
        row = participations.save(row);
        var activity = requireActivity(societyId, row.getActivityId());
        addEvent(activity, row, actorId, role, "PAYMENT_COMPLETED", requestedMethod.code());
        return participationView(row);
    }

    public Map<String, Object> recordCash(
            UUID societyId, UUID actorId, String role, UUID participationId) {
        requireManager(actorId, role);
        var row = requireParticipation(societyId, participationId);
        requirePendingPayment(row);
        row.setPaymentStatus(PaymentStatus.PAID.code());
        row.setPaymentMethod(PaymentMethod.CASH.code());
        row.setPaymentReference(
                "ACT-CASH-"
                        + UUID.randomUUID()
                                .toString()
                                .replace("-", "")
                                .substring(0, 12)
                                .toUpperCase());
        row.setPaidAt(OffsetDateTime.now());
        moveAfterPayment(row);
        row.setUpdatedAt(OffsetDateTime.now());
        row = participations.save(row);
        addEvent(
                requireActivity(societyId, row.getActivityId()),
                row,
                actorId,
                role,
                "CASH_RECORDED",
                null);
        return participationView(row);
    }

    public Map<String, Object> participationAction(
            UUID societyId,
            UUID actorId,
            String role,
            UUID participationId,
            String action,
            String reason) {
        var row = requireParticipation(societyId, participationId);
        var activity = requireActivity(societyId, row.getActivityId());
        var requestedAction = ParticipationAction.from(action);
        if (requestedAction == ParticipationAction.CANCEL) {
            requireOwnerOrManager(row, actorId, role);
            if (!Set.of(
                            PaymentStatus.PENDING_PAYMENT.code(),
                            ParticipationStatus.PENDING_APPROVAL.code(),
                            ParticipationStatus.CONFIRMED.code())
                    .contains(row.getStatus())) {
                throw new IllegalStateException("Registration cannot be cancelled");
            }
            if (UserRole.RESIDENT.matches(role)
                    && OffsetDateTime.now()
                            .plusHours(activity.getCancellationHours())
                            .isAfter(activity.getStartsAt())) {
                throw new IllegalStateException(
                        "Cancellation requires "
                                + activity.getCancellationHours()
                                + " hours notice");
            }
            row.setStatus(ParticipationStatus.CANCELLED.code());
            row.setCancelledAt(OffsetDateTime.now());
            if (PaymentStatus.PAID.matches(row.getPaymentStatus()))
                row.setPaymentStatus(PaymentStatus.REFUND_PENDING.code());
        } else {
            requireManager(actorId, role);
            switch (requestedAction) {
                case APPROVE -> {
                    requireParticipationStatus(row, ParticipationStatus.PENDING_APPROVAL);
                    row.setStatus(ParticipationStatus.CONFIRMED.code());
                    row.setReviewedBy(actorId);
                    row.setReviewedAt(OffsetDateTime.now());
                }
                case REJECT -> {
                    requireParticipationStatus(row, ParticipationStatus.PENDING_APPROVAL);
                    requireReason(reason, "Rejection reason is required");
                    row.setStatus(ParticipationStatus.REJECTED.code());
                    row.setRejectionReason(reason.trim());
                    row.setReviewedBy(actorId);
                    row.setReviewedAt(OffsetDateTime.now());
                    if (PaymentStatus.PAID.matches(row.getPaymentStatus()))
                        row.setPaymentStatus(PaymentStatus.REFUND_PENDING.code());
                }
                case CHECK_IN -> {
                    requireParticipationStatus(row, ParticipationStatus.CONFIRMED);
                    if (OffsetDateTime.now().isBefore(activity.getStartsAt().minusHours(12))) {
                        throw new IllegalStateException(
                                "Check-in opens 12 hours before the activity");
                    }
                    if (OffsetDateTime.now().isAfter(activity.getEndsAt())) {
                        throw new IllegalStateException("Activity check-in has closed");
                    }
                    row.setStatus(ParticipationStatus.CHECKED_IN.code());
                    row.setCheckedInAt(OffsetDateTime.now());
                }
                case ATTENDED -> {
                    if (!Set.of(
                                    ParticipationStatus.CONFIRMED.code(),
                                    ParticipationStatus.CHECKED_IN.code())
                            .contains(row.getStatus())) {
                        throw new IllegalStateException(
                                "Participant is not confirmed or checked in");
                    }
                    if (OffsetDateTime.now().isBefore(activity.getStartsAt())) {
                        throw new IllegalStateException(
                                "Attendance can be recorded after the activity starts");
                    }
                    row.setStatus(ParticipationStatus.ATTENDED.code());
                    row.setAttendedAt(OffsetDateTime.now());
                }
                case NO_SHOW -> {
                    requireParticipationStatus(row, ParticipationStatus.CONFIRMED);
                    if (OffsetDateTime.now().isBefore(activity.getEndsAt())) {
                        throw new IllegalStateException(
                                "No-show can be recorded after the activity ends");
                    }
                    row.setStatus(ParticipationStatus.NO_SHOW.code());
                }
                case REFUND -> {
                    if (!PaymentStatus.REFUND_PENDING.matches(row.getPaymentStatus())) {
                        throw new IllegalStateException("Registration has no pending refund");
                    }
                    row.setPaymentStatus(PaymentStatus.REFUNDED.code());
                }
                case CANCEL -> throw new IllegalStateException("Cancellation was already handled");
            }
        }
        row.setUpdatedAt(OffsetDateTime.now());
        row = participations.save(row);
        addEvent(activity, row, actorId, role, requestedAction.code(), reason);
        notifyUser(row.getParticipantId(), activity, "ACTIVITY_REGISTRATION_UPDATED");
        return participationView(row);
    }

    public Map<String, Object> uploadPhoto(
            UUID societyId,
            UUID actorId,
            String role,
            UUID activityId,
            String caption,
            UploadedFile file) {
        var activity = requireActivity(societyId, activityId);
        if (UserRole.RESIDENT.matches(role)) {
            if (OffsetDateTime.now().isBefore(activity.getStartsAt())) {
                throw new IllegalStateException(
                        "Gallery photos can be submitted after the activity starts");
            }
            participations
                    .findByActivityIdAndParticipantId(activityId, actorId)
                    .filter(
                            row ->
                                    Set.of(
                                                    ParticipationStatus.CONFIRMED.code(),
                                                    ParticipationStatus.CHECKED_IN.code(),
                                                    ParticipationStatus.ATTENDED.code())
                                            .contains(row.getStatus()))
                    .orElseThrow(
                            () ->
                                    new AuthorizationException(
                                            "Only confirmed participants can submit photos"));
        } else {
            requireManager(actorId, role);
        }
        var photo = new ActivityGalleryPhoto();
        photo.setSocietyId(societyId);
        photo.setActivityId(activityId);
        photo.setSubmittedBy(actorId);
        photo.setStorageKey(storage.storeImage(societyId, file));
        photo.setContentType(file.contentType());
        photo.setCaption(blankToNull(caption));
        photo.setModerationStatus(
                UserRole.SOCIETY_ADMIN.matches(role)
                        ? ModerationStatus.PUBLISHED.code()
                        : ModerationStatus.PENDING.code());
        photo.setFeatured(false);
        photo.setCreatedAt(OffsetDateTime.now());
        photo = photos.save(photo);
        storage.attach(photo.getStorageKey(), "ACTIVITY_PHOTO", photo.getId(), activity.getTitle());
        addEvent(activity, null, actorId, role, "PHOTO_SUBMITTED", caption);
        return photoView(photo);
    }

    public PhotoContent photo(UUID societyId, UUID actorId, String role, UUID photoId) {
        if (UserRole.STAFF.matches(role)) requireManager(actorId, role);
        var photo =
                photos.findByIdAndSocietyId(photoId, societyId)
                        .orElseThrow(
                                () -> new ResourceNotFoundException("Activity photo not found"));
        if (UserRole.RESIDENT.matches(role)
                && !ModerationStatus.PUBLISHED.matches(photo.getModerationStatus())
                && !actorId.equals(photo.getSubmittedBy())) {
            throw new ResourceNotFoundException("Activity photo not found");
        }
        return new PhotoContent(storage.load(photo.getStorageKey()), photo.getContentType());
    }

    public Map<String, Object> photoAction(
            UUID societyId, UUID actorId, String role, UUID photoId, String action, String reason) {
        requireAdmin(role);
        var photo =
                photos.findByIdAndSocietyId(photoId, societyId)
                        .orElseThrow(
                                () -> new ResourceNotFoundException("Activity photo not found"));
        var requestedAction = PhotoAction.from(action);
        switch (requestedAction) {
            case APPROVE -> {
                if (!ModerationStatus.PENDING.matches(photo.getModerationStatus())) {
                    throw new IllegalStateException("Photo is not pending moderation");
                }
                photo.setModerationStatus(ModerationStatus.PUBLISHED.code());
                photo.setRejectionReason(null);
            }
            case REJECT -> {
                if (!ModerationStatus.PENDING.matches(photo.getModerationStatus())) {
                    throw new IllegalStateException("Photo is not pending moderation");
                }
                requireReason(reason, "Rejection reason is required");
                photo.setModerationStatus(ModerationStatus.REJECTED.code());
                photo.setRejectionReason(reason.trim());
            }
            case REMOVE -> {
                requireReason(reason, "Removal reason is required");
                photo.setModerationStatus(ModerationStatus.REMOVED.code());
                photo.setFeatured(false);
                photo.setRejectionReason(reason.trim());
            }
            case FEATURE -> {
                if (!ModerationStatus.PUBLISHED.matches(photo.getModerationStatus())) {
                    throw new IllegalStateException("Only a published photo can be featured");
                }
                photo.setFeatured(true);
            }
            case UNFEATURE -> photo.setFeatured(false);
        }
        photo.setReviewedBy(actorId);
        photo.setReviewedAt(OffsetDateTime.now());
        photo = photos.save(photo);
        addEvent(
                requireActivity(societyId, photo.getActivityId()),
                null,
                actorId,
                role,
                "PHOTO_" + requestedAction.code(),
                reason);
        return photoView(photo);
    }

    public List<Map<String, Object>> history(
            UUID societyId, UUID actorId, String role, UUID activityId) {
        if (UserRole.STAFF.matches(role)) requireManager(actorId, role);
        var activity = requireActivity(societyId, activityId);
        if (UserRole.RESIDENT.matches(role)
                && !Set.of(
                                ActivityStatus.PUBLISHED.code(),
                                ActivityStatus.COMPLETED.code(),
                                ActivityStatus.CANCELLED.code())
                        .contains(activity.getStatus())) {
            throw new ResourceNotFoundException("Activity not found");
        }
        return events.findByActivityIdOrderByOccurredAt(activityId).stream()
                .map(this::eventView)
                .toList();
    }

    private void apply(
            SocietyActivity item,
            String title,
            String category,
            String description,
            String venue,
            OffsetDateTime startsAt,
            OffsetDateTime endsAt,
            OffsetDateTime registrationOpensAt,
            OffsetDateTime registrationClosesAt,
            Integer capacity,
            BigDecimal feePerPerson,
            boolean approvalRequired,
            int cancellationHours,
            String audience,
            String organizerName,
            String organizerMobile,
            String instructions) {
        item.setTitle(title.trim());
        item.setCategory(category);
        item.setDescription(description.trim());
        item.setVenue(venue.trim());
        item.setStartsAt(startsAt);
        item.setEndsAt(endsAt);
        item.setRegistrationOpensAt(registrationOpensAt);
        item.setRegistrationClosesAt(registrationClosesAt);
        item.setCapacity(capacity);
        item.setFeePerPerson(feePerPerson);
        item.setApprovalRequired(approvalRequired);
        item.setCancellationHours(cancellationHours);
        item.setAudience(audience);
        item.setOrganizerName(blankToNull(organizerName));
        item.setOrganizerMobile(blankToNull(organizerMobile));
        item.setInstructions(blankToNull(instructions));
        item.setUpdatedAt(OffsetDateTime.now());
    }

    private void validateSchedule(
            OffsetDateTime start,
            OffsetDateTime end,
            OffsetDateTime registrationOpen,
            OffsetDateTime registrationClose,
            Integer capacity) {
        if (!end.isAfter(start))
            throw new IllegalArgumentException("Activity end must be after start");
        if (!start.isAfter(OffsetDateTime.now()))
            throw new IllegalArgumentException("Activity must start in the future");
        if (registrationClose.isBefore(registrationOpen)) {
            throw new IllegalArgumentException("Registration close must be after opening");
        }
        if (registrationClose.isAfter(start)) {
            throw new IllegalArgumentException(
                    "Registration must close before the activity starts");
        }
        if (capacity != null && capacity < 1)
            throw new IllegalArgumentException("Capacity must be positive");
    }

    private int registeredCount(UUID activityId) {
        return participations.findByActivityId(activityId).stream()
                .filter(row -> CAPACITY_STATUSES.contains(row.getStatus()))
                .mapToInt(ActivityParticipation::getParticipantCount)
                .sum();
    }

    private void moveAfterPayment(ActivityParticipation row) {
        var activity = activities.findById(row.getActivityId()).orElseThrow();
        row.setStatus(
                activity.isApprovalRequired()
                        ? ParticipationStatus.PENDING_APPROVAL.code()
                        : ParticipationStatus.CONFIRMED.code());
    }

    private void requirePendingPayment(ActivityParticipation row) {
        if (!PaymentStatus.PENDING.matches(row.getPaymentStatus())) {
            throw new IllegalStateException("Registration has no pending payment");
        }
    }

    private void requireOwnerOrManager(ActivityParticipation row, UUID actorId, String role) {
        if (UserRole.RESIDENT.matches(role)) {
            if (!actorId.equals(row.getParticipantId())) {
                throw new AuthorizationException("You can only manage your own registration");
            }
        } else requireManager(actorId, role);
    }

    private void requireManager(UUID actorId, String role) {
        if (UserRole.SOCIETY_ADMIN.matches(role)) return;
        if (UserRole.STAFF.matches(role)
                && permissions.existsByStaffUserIdAndPermissionCode(
                        actorId, StaffPermissionCode.ACTIVITIES_GALLERIES.code())) return;
        throw new AuthorizationException("Activities and galleries permission is required");
    }

    private void requireAdmin(String role) {
        if (!UserRole.SOCIETY_ADMIN.matches(role)) {
            throw new AuthorizationException("Society administrator access is required");
        }
    }

    private SocietyActivity requireActivity(UUID societyId, UUID id) {
        return activities
                .findByIdAndSocietyId(id, societyId)
                .orElseThrow(() -> new ResourceNotFoundException("Activity not found"));
    }

    private ActivityParticipation requireParticipation(UUID societyId, UUID id) {
        return participations
                .findByIdAndSocietyId(id, societyId)
                .orElseThrow(
                        () -> new ResourceNotFoundException("Activity registration not found"));
    }

    private void requireActivityStatus(SocietyActivity item, ActivityStatus status) {
        if (!status.matches(item.getStatus())) {
            throw new IllegalStateException(
                    "Activity must be " + status.code().toLowerCase(Locale.ROOT));
        }
    }

    private void requireParticipationStatus(
            ActivityParticipation item, ParticipationStatus status) {
        if (!status.matches(item.getStatus())) {
            throw new IllegalStateException(
                    "Registration must be " + status.code().toLowerCase(Locale.ROOT));
        }
    }

    private void requireReason(String reason, String message) {
        if (reason == null || reason.isBlank()) throw new IllegalArgumentException(message);
    }

    private void notifyResidents(UUID societyId, SocietyActivity item, String template) {
        users.findBySocietyIdAndRoleOrderByFullName(societyId, UserRole.RESIDENT.code()).stream()
                .filter(user -> AccountStatus.ACTIVE.matches(user.getStatus()))
                .forEach(user -> notify(user, item, template));
    }

    private void notifyUser(UUID userId, SocietyActivity item, String template) {
        users.findById(userId).ifPresent(user -> notify(user, item, template));
    }

    private void notify(UserAccount user, SocietyActivity item, String template) {
        if (user.getEmail() == null || user.getEmail().isBlank()) return;
        var message = new NotificationOutbox();
        message.setSocietyId(item.getSocietyId());
        message.setChannel("EMAIL");
        message.setDestination(user.getEmail());
        message.setTemplateCode(template);
        message.setPayload(
                "{\"activityCode\":\""
                        + item.getActivityCode()
                        + "\",\"title\":\""
                        + item.getTitle().replace("\"", "")
                        + "\"}");
        message.setStatus(NotificationStatus.PENDING.code());
        message.setAttempts(0);
        message.setCreatedAt(OffsetDateTime.now());
        notifications.save(message);
    }

    private void addEvent(
            SocietyActivity activity,
            ActivityParticipation participation,
            UUID actorId,
            String role,
            String type,
            String note) {
        var event = new ActivityEvent();
        event.setSocietyId(activity.getSocietyId());
        event.setActivityId(activity.getId());
        event.setParticipationId(participation == null ? null : participation.getId());
        event.setEventType(type);
        event.setNote(blankToNull(note));
        event.setActorId(actorId);
        event.setActorRole(role);
        event.setOccurredAt(OffsetDateTime.now());
        events.save(event);
    }

    private Map<String, Object> activityView(SocietyActivity item, UUID actorId) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", item.getId());
        map.put("activity_code", item.getActivityCode());
        map.put("title", item.getTitle());
        map.put("category", item.getCategory());
        map.put("description", item.getDescription());
        map.put("venue", item.getVenue());
        map.put("starts_at", item.getStartsAt());
        map.put("ends_at", item.getEndsAt());
        map.put("registration_opens_at", item.getRegistrationOpensAt());
        map.put("registration_closes_at", item.getRegistrationClosesAt());
        map.put("capacity", item.getCapacity());
        int registered = registeredCount(item.getId());
        map.put("registered_count", registered);
        map.put(
                "available_places",
                item.getCapacity() == null ? null : Math.max(0, item.getCapacity() - registered));
        map.put("fee_per_person", item.getFeePerPerson());
        map.put("is_paid", item.getFeePerPerson().signum() > 0);
        map.put("approval_required", item.isApprovalRequired());
        map.put("cancellation_hours", item.getCancellationHours());
        map.put("audience", item.getAudience());
        map.put("organizer_name", item.getOrganizerName());
        map.put("organizer_mobile", item.getOrganizerMobile());
        map.put("instructions", item.getInstructions());
        map.put("status", item.getStatus());
        map.put("cancellation_reason", item.getCancellationReason());
        map.put("created_at", item.getCreatedAt());
        participations
                .findByActivityIdAndParticipantId(item.getId(), actorId)
                .ifPresent(row -> map.put("my_participation", participationView(row)));
        return map;
    }

    private Map<String, Object> participationView(ActivityParticipation row) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", row.getId());
        map.put("activity_id", row.getActivityId());
        activities
                .findById(row.getActivityId())
                .ifPresent(
                        item -> {
                            map.put("activity_title", item.getTitle());
                            map.put("activity_code", item.getActivityCode());
                            map.put("starts_at", item.getStartsAt());
                        });
        map.put("participant_id", row.getParticipantId());
        users.findById(row.getParticipantId())
                .ifPresent(
                        user -> {
                            map.put("participant_name", user.getFullName());
                            map.put("participant_email", user.getEmail());
                        });
        map.put("participant_count", row.getParticipantCount());
        map.put("participant_names", row.getParticipantNames());
        map.put("contact_mobile", row.getContactMobile());
        map.put("notes", row.getNotes());
        map.put("amount", row.getAmount());
        map.put("payment_status", row.getPaymentStatus());
        map.put("payment_method", row.getPaymentMethod());
        map.put("payment_reference", row.getPaymentReference());
        map.put("status", row.getStatus());
        map.put("rejection_reason", row.getRejectionReason());
        map.put("checked_in_at", row.getCheckedInAt());
        map.put("attended_at", row.getAttendedAt());
        map.put("created_at", row.getCreatedAt());
        return map;
    }

    private Map<String, Object> photoView(ActivityGalleryPhoto photo) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", photo.getId());
        map.put("activity_id", photo.getActivityId());
        activities
                .findById(photo.getActivityId())
                .ifPresent(item -> map.put("activity_title", item.getTitle()));
        map.put("submitted_by", photo.getSubmittedBy());
        users.findById(photo.getSubmittedBy())
                .ifPresent(user -> map.put("submitted_by_name", user.getFullName()));
        map.put("caption", photo.getCaption());
        map.put("moderation_status", photo.getModerationStatus());
        map.put("featured", photo.isFeatured());
        map.put("rejection_reason", photo.getRejectionReason());
        map.put("created_at", photo.getCreatedAt());
        map.put("photo_url", "/api/activities/photos/" + photo.getId());
        return map;
    }

    private Map<String, Object> eventView(ActivityEvent event) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", event.getId());
        map.put("event_type", event.getEventType());
        map.put("note", event.getNote());
        map.put("actor_role", event.getActorRole());
        map.put("occurred_at", event.getOccurredAt());
        users.findById(event.getActorId())
                .ifPresent(user -> map.put("actor_name", user.getFullName()));
        return map;
    }

    private String activityCode() {
        return "ACT-"
                + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMM"))
                + "-"
                + UUID.randomUUID().toString().replace("-", "").substring(0, 8).toUpperCase();
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
