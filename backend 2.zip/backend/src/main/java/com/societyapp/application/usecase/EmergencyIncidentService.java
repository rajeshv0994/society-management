package com.societyapp.application.usecase;

import com.societyapp.application.exception.AuthorizationException;
import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.port.in.EmergencyIncidentUseCase;
import com.societyapp.application.port.in.StructureAccessUseCase;
import com.societyapp.application.port.out.persistence.*;
import com.societyapp.domain.model.*;
import com.societyapp.domain.type.AccountStatus;
import com.societyapp.domain.type.EmergencyAction;
import com.societyapp.domain.type.EmergencyIncidentStatus;
import com.societyapp.domain.type.IncidentSeverity;
import com.societyapp.domain.type.NotificationStatus;
import com.societyapp.domain.type.StaffPermissionCode;
import com.societyapp.domain.type.UserRole;
import java.math.BigDecimal;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class EmergencyIncidentService implements EmergencyIncidentUseCase {
    private final EmergencyIncidentRepository incidents;
    private final EmergencyIncidentEventRepository events;
    private final EmergencyDirectoryContactRepository directory;
    private final UserAccountJpaRepository users;
    private final FlatRepository flats;
    private final FloorRepository floors;
    private final BlockRepository blocks;
    private final StructureAccessUseCase access;
    private final StaffPermissionRepository permissions;
    private final HouseholdEmergencyContactRepository householdContacts;
    private final NotificationOutboxRepository notifications;

    public EmergencyIncidentService(
            EmergencyIncidentRepository incidents,
            EmergencyIncidentEventRepository events,
            EmergencyDirectoryContactRepository directory,
            UserAccountJpaRepository users,
            FlatRepository flats,
            FloorRepository floors,
            BlockRepository blocks,
            StructureAccessUseCase access,
            StaffPermissionRepository permissions,
            HouseholdEmergencyContactRepository householdContacts,
            NotificationOutboxRepository notifications) {
        this.incidents = incidents;
        this.events = events;
        this.directory = directory;
        this.users = users;
        this.flats = flats;
        this.floors = floors;
        this.blocks = blocks;
        this.access = access;
        this.permissions = permissions;
        this.householdContacts = householdContacts;
        this.notifications = notifications;
    }

    public Map<String, Object> workspace(UUID societyId, UUID actorId, String role) {
        if (UserRole.STAFF.matches(role)) requireManager(actorId, role);
        var rows =
                UserRole.RESIDENT.matches(role)
                        ? incidents.findBySocietyIdAndResidentIdOrderByCreatedAtDesc(
                                societyId, actorId)
                        : incidents.findBySocietyIdOrderByCreatedAtDesc(societyId);
        var result = new LinkedHashMap<String, Object>();
        result.put("incidents", rows.stream().map(this::view).toList());
        result.put(
                "directory",
                directory
                        .findBySocietyIdAndActiveTrueOrderByContactTypeAscPriorityAsc(societyId)
                        .stream()
                        .map(this::directoryView)
                        .toList());
        result.put("resident_options", residentOptions(societyId, actorId, role));
        result.put("responder_options", responderOptions(societyId));
        result.put("total", rows.size());
        result.put(
                "open",
                rows.stream()
                        .filter(row -> EmergencyIncidentStatus.from(row.getStatus()).isOpen())
                        .count());
        result.put(
                "critical",
                rows.stream()
                        .filter(row -> IncidentSeverity.CRITICAL.matches(row.getSeverity()))
                        .filter(row -> EmergencyIncidentStatus.from(row.getStatus()).isOpen())
                        .count());
        result.put(
                "responding",
                rows.stream()
                        .filter(
                                row ->
                                        Set.of(
                                                        EmergencyIncidentStatus.RESPONDING.code(),
                                                        EmergencyIncidentStatus.ON_SCENE.code(),
                                                        EmergencyIncidentStatus.STABILIZED.code())
                                                .contains(row.getStatus()))
                        .count());
        result.put(
                "resolved",
                rows.stream()
                        .filter(
                                row ->
                                        Set.of(
                                                        EmergencyIncidentStatus.RESOLVED.code(),
                                                        EmergencyIncidentStatus.CLOSED.code())
                                                .contains(row.getStatus()))
                        .count());
        return result;
    }

    public List<Map<String, Object>> history(
            UUID societyId, UUID actorId, String role, UUID incidentId) {
        if (UserRole.STAFF.matches(role)) requireManager(actorId, role);
        var incident = requireIncident(societyId, incidentId);
        requireVisible(incident, actorId, role);
        return events.findByIncidentIdOrderByOccurredAt(incidentId).stream()
                .map(this::eventView)
                .toList();
    }

    public Map<String, Object> create(
            UUID societyId,
            UUID actorId,
            String role,
            UUID requestedResidentId,
            UUID flatId,
            String type,
            String severity,
            String title,
            String description,
            String location,
            BigDecimal latitude,
            BigDecimal longitude,
            int peopleAffected,
            String injuredName,
            String injuredMobile,
            String injuryDetails) {
        UUID residentId = requestedResidentId;
        if (UserRole.RESIDENT.matches(role)) {
            residentId = actorId;
            if (flatId == null) throw new IllegalArgumentException("Space is required");
            access.requireFlat(flatId, societyId);
            if (!access.occupiedBy(flatId, actorId)) {
                throw new IllegalArgumentException("You do not occupy the selected space");
            }
        } else {
            requireManager(actorId, role);
            if (residentId != null) requireResident(societyId, residentId);
            if (flatId != null) {
                access.requireFlat(flatId, societyId);
                if (residentId != null && !access.occupiedBy(flatId, residentId)) {
                    throw new IllegalArgumentException(
                            "Resident does not occupy the selected space");
                }
            }
        }
        if (latitude != null
                && (latitude.compareTo(BigDecimal.valueOf(-90)) < 0
                        || latitude.compareTo(BigDecimal.valueOf(90)) > 0)) {
            throw new IllegalArgumentException("Latitude must be between -90 and 90");
        }
        if (longitude != null
                && (longitude.compareTo(BigDecimal.valueOf(-180)) < 0
                        || longitude.compareTo(BigDecimal.valueOf(180)) > 0)) {
            throw new IllegalArgumentException("Longitude must be between -180 and 180");
        }
        var item = new EmergencyIncident();
        item.setSocietyId(societyId);
        item.setIncidentNumber(incidentNumber());
        item.setReporterId(actorId);
        item.setReporterRole(role);
        item.setResidentId(residentId);
        item.setFlatId(flatId);
        item.setIncidentType(type);
        item.setSeverity(IncidentSeverity.from(severity).code());
        item.setTitle(title.trim());
        item.setDescription(description.trim());
        item.setLocationDetails(location.trim());
        item.setLatitude(latitude);
        item.setLongitude(longitude);
        item.setPeopleAffected(peopleAffected);
        item.setInjuredPersonName(blankToNull(injuredName));
        item.setInjuredPersonMobile(blankToNull(injuredMobile));
        item.setInjuryDetails(blankToNull(injuryDetails));
        item.setStatus(EmergencyIncidentStatus.REPORTED.code());
        item.setCreatedAt(OffsetDateTime.now());
        item.setUpdatedAt(OffsetDateTime.now());
        item = incidents.save(item);
        addEvent(
                item,
                actorId,
                role,
                EmergencyIncidentStatus.REPORTED.code(),
                null,
                EmergencyIncidentStatus.REPORTED.code(),
                description);
        notifySocietyAdmins(societyId, item, "EMERGENCY_REPORTED");
        if (residentId != null && !actorId.equals(residentId)) {
            notifyUser(residentId, item, "EMERGENCY_REPORTED_FOR_RESIDENT");
        }
        return view(item);
    }

    public Map<String, Object> action(
            UUID societyId,
            UUID actorId,
            String role,
            UUID incidentId,
            String action,
            String note,
            UUID assignedStaffId,
            String hospitalName,
            String externalReference,
            String newSeverity) {
        var item = requireIncident(societyId, incidentId);
        var requestedAction = EmergencyAction.from(action);
        String oldStatus = item.getStatus();
        switch (requestedAction) {
            case ACKNOWLEDGE -> {
                requireManager(actorId, role);
                requireStatus(item, EmergencyIncidentStatus.REPORTED);
                item.setStatus(EmergencyIncidentStatus.ACKNOWLEDGED.code());
                item.setAcknowledgedAt(OffsetDateTime.now());
            }
            case ASSIGN -> {
                requireManager(actorId, role);
                if (!EmergencyIncidentStatus.from(item.getStatus()).isOpen()) {
                    throw new IllegalStateException("Only an open incident can be assigned");
                }
                if (assignedStaffId == null)
                    throw new IllegalArgumentException("Responder is required");
                var responder = requireStaff(societyId, assignedStaffId);
                item.setAssignedStaffId(assignedStaffId);
                if (EmergencyIncidentStatus.REPORTED.matches(item.getStatus())) {
                    item.setStatus(EmergencyIncidentStatus.ACKNOWLEDGED.code());
                    item.setAcknowledgedAt(OffsetDateTime.now());
                }
                notifyUser(responder.getId(), item, "EMERGENCY_ASSIGNED");
            }
            case START_RESPONSE -> {
                requireManager(actorId, role);
                if (!Set.of(
                                EmergencyIncidentStatus.REPORTED.code(),
                                EmergencyIncidentStatus.ACKNOWLEDGED.code())
                        .contains(item.getStatus())) {
                    throw new IllegalStateException("Incident is not awaiting response");
                }
                item.setStatus(EmergencyIncidentStatus.RESPONDING.code());
                item.setResponseStartedAt(OffsetDateTime.now());
                if (UserRole.STAFF.matches(role) && item.getAssignedStaffId() == null) {
                    item.setAssignedStaffId(actorId);
                }
                if (item.getAcknowledgedAt() == null) item.setAcknowledgedAt(OffsetDateTime.now());
            }
            case ARRIVE -> {
                requireManager(actorId, role);
                requireStatus(item, EmergencyIncidentStatus.RESPONDING);
                item.setStatus(EmergencyIncidentStatus.ON_SCENE.code());
                item.setArrivedAt(OffsetDateTime.now());
            }
            case REQUEST_AMBULANCE, REQUEST_POLICE, REQUEST_FIRE -> {
                requireManager(actorId, role);
                requireOpen(item);
                requireNote(note, "Dispatch details or call reference are required");
                if (requestedAction == EmergencyAction.REQUEST_AMBULANCE)
                    item.setAmbulanceRequested(true);
                if (requestedAction == EmergencyAction.REQUEST_POLICE)
                    item.setPoliceRequested(true);
                if (requestedAction == EmergencyAction.REQUEST_FIRE)
                    item.setFireServiceRequested(true);
                item.setExternalReference(blankToNull(externalReference));
                item.setHospitalName(blankToNull(hospitalName));
            }
            case NOTIFY_CONTACT -> {
                requireManager(actorId, role);
                requireOpen(item);
                requireNote(note, "Contact notification details are required");
                item.setEmergencyContactNotified(true);
                if (item.getResidentId() != null) {
                    notifyUser(item.getResidentId(), item, "EMERGENCY_CONTACT_NOTIFIED");
                }
            }
            case ADD_UPDATE -> {
                requireVisible(item, actorId, role);
                requireOpen(item);
                requireNote(note, "Update note is required");
            }
            case ESCALATE -> {
                requireManager(actorId, role);
                requireOpen(item);
                var requestedSeverity = IncidentSeverity.from(newSeverity);
                if (requestedSeverity == IncidentSeverity.LOW) {
                    throw new IllegalArgumentException("A valid escalation severity is required");
                }
                if (requestedSeverity.rank() <= IncidentSeverity.from(item.getSeverity()).rank()) {
                    throw new IllegalArgumentException("New severity must be higher");
                }
                item.setSeverity(requestedSeverity.code());
            }
            case STABILIZE -> {
                requireManager(actorId, role);
                if (!Set.of(
                                EmergencyIncidentStatus.RESPONDING.code(),
                                EmergencyIncidentStatus.ON_SCENE.code())
                        .contains(item.getStatus())) {
                    throw new IllegalStateException("Incident response is not on scene");
                }
                requireNote(note, "Stabilization details are required");
                item.setStatus(EmergencyIncidentStatus.STABILIZED.code());
                item.setStabilizedAt(OffsetDateTime.now());
            }
            case RESOLVE -> {
                requireManager(actorId, role);
                if (!EmergencyIncidentStatus.from(item.getStatus()).isOpen()) {
                    throw new IllegalStateException("Only an open incident can be resolved");
                }
                requireNote(note, "Resolution summary is required");
                item.setStatus(EmergencyIncidentStatus.RESOLVED.code());
                item.setResolutionSummary(note.trim());
                item.setResolvedAt(OffsetDateTime.now());
                notifyRelevant(item, "EMERGENCY_RESOLVED");
            }
            case CLOSE -> {
                requireAdmin(role);
                requireStatus(item, EmergencyIncidentStatus.RESOLVED);
                item.setStatus(EmergencyIncidentStatus.CLOSED.code());
                item.setClosedReason(blankToNull(note));
                item.setClosedAt(OffsetDateTime.now());
            }
            case CANCEL -> {
                if (UserRole.RESIDENT.matches(role)) {
                    requireResidentOwner(item, actorId, role);
                } else {
                    requireManager(actorId, role);
                }
                if (!Set.of(
                                EmergencyIncidentStatus.REPORTED.code(),
                                EmergencyIncidentStatus.ACKNOWLEDGED.code())
                        .contains(item.getStatus())) {
                    throw new IllegalStateException("Incident response has already started");
                }
                requireNote(note, "Cancellation reason is required");
                item.setStatus(EmergencyIncidentStatus.CANCELLED.code());
                item.setClosedReason(note.trim());
                item.setClosedAt(OffsetDateTime.now());
            }
            case FALSE_ALARM -> {
                requireManager(actorId, role);
                requireOpen(item);
                requireNote(note, "False alarm reason is required");
                item.setStatus(EmergencyIncidentStatus.FALSE_ALARM.code());
                item.setClosedReason(note.trim());
                item.setClosedAt(OffsetDateTime.now());
            }
            case REOPEN -> {
                requireAdmin(role);
                if (!Set.of(
                                EmergencyIncidentStatus.RESOLVED.code(),
                                EmergencyIncidentStatus.CLOSED.code(),
                                EmergencyIncidentStatus.CANCELLED.code(),
                                EmergencyIncidentStatus.FALSE_ALARM.code())
                        .contains(item.getStatus())) {
                    throw new IllegalStateException("Incident is already open");
                }
                requireNote(note, "Reopen reason is required");
                item.setStatus(EmergencyIncidentStatus.RESPONDING.code());
                item.setResponseStartedAt(OffsetDateTime.now());
                item.setResolvedAt(null);
                item.setClosedAt(null);
                item.setClosedReason(null);
            }
        }
        item.setUpdatedAt(OffsetDateTime.now());
        item = incidents.save(item);
        addEvent(item, actorId, role, requestedAction.code(), oldStatus, item.getStatus(), note);
        return view(item);
    }

    public Map<String, Object> saveDirectory(
            UUID societyId,
            UUID actorId,
            String role,
            UUID id,
            String type,
            String name,
            String phone,
            String alternatePhone,
            String address,
            boolean available24x7,
            int priority) {
        requireAdmin(role);
        var item =
                id == null
                        ? new EmergencyDirectoryContact()
                        : directory
                                .findByIdAndSocietyId(id, societyId)
                                .orElseThrow(
                                        () ->
                                                new ResourceNotFoundException(
                                                        "Emergency contact not found"));
        if (id == null) {
            item.setSocietyId(societyId);
            item.setCreatedBy(actorId);
            item.setCreatedAt(OffsetDateTime.now());
        }
        item.setContactType(type);
        item.setName(name.trim());
        item.setPhone(phone.trim());
        item.setAlternatePhone(blankToNull(alternatePhone));
        item.setAddress(blankToNull(address));
        item.setAvailable24x7(available24x7);
        item.setPriority(priority);
        item.setActive(true);
        item.setUpdatedAt(OffsetDateTime.now());
        return directoryView(directory.save(item));
    }

    public void removeDirectory(UUID societyId, String role, UUID id) {
        requireAdmin(role);
        var item =
                directory
                        .findByIdAndSocietyId(id, societyId)
                        .orElseThrow(
                                () -> new ResourceNotFoundException("Emergency contact not found"));
        item.setActive(false);
        item.setUpdatedAt(OffsetDateTime.now());
        directory.save(item);
    }

    private List<Map<String, Object>> residentOptions(UUID societyId, UUID actorId, String role) {
        var result = new ArrayList<Map<String, Object>>();
        var residents =
                UserRole.RESIDENT.matches(role)
                        ? List.of(requireResident(societyId, actorId))
                        : users
                                .findBySocietyIdAndRoleOrderByFullName(
                                        societyId, UserRole.RESIDENT.code())
                                .stream()
                                .filter(user -> AccountStatus.ACTIVE.matches(user.getStatus()))
                                .toList();
        for (var resident : residents) {
            for (var flat : flats.findAll()) {
                if (!access.belongsToSociety(flat.getId(), societyId)
                        || !access.occupiedBy(flat.getId(), resident.getId())) continue;
                var row = new LinkedHashMap<String, Object>();
                row.put("resident_id", resident.getId());
                row.put("resident_name", resident.getFullName());
                row.put("resident_mobile", resident.getMobile());
                row.put("flat_id", flat.getId());
                row.put("space_number", flat.getFlatNumber());
                floors.findById(flat.getFloorId())
                        .flatMap(floor -> blocks.findById(floor.getBlockId()))
                        .ifPresent(block -> row.put("block", block.getName()));
                row.put(
                        "emergency_contacts",
                        householdContacts
                                .findBySocietyIdAndPrimaryResidentIdAndActiveTrueOrderByPriority(
                                        societyId, resident.getId())
                                .stream()
                                .map(
                                        contact ->
                                                Map.of(
                                                        "name", contact.getFullName(),
                                                        "relationship", contact.getRelationship(),
                                                        "mobile", contact.getMobile(),
                                                        "priority", contact.getPriority()))
                                .toList());
                result.add(row);
            }
        }
        return result;
    }

    private List<Map<String, Object>> responderOptions(UUID societyId) {
        return users
                .findBySocietyIdAndRoleOrderByFullName(societyId, UserRole.STAFF.code())
                .stream()
                .filter(user -> AccountStatus.ACTIVE.matches(user.getStatus()))
                .filter(
                        user ->
                                permissions.existsByStaffUserIdAndPermissionCode(
                                        user.getId(),
                                        StaffPermissionCode.EMERGENCY_INCIDENTS.code()))
                .map(
                        user ->
                                Map.<String, Object>of(
                                        "id", user.getId(),
                                        "name", user.getFullName(),
                                        "mobile", user.getMobile() == null ? "" : user.getMobile()))
                .toList();
    }

    private void requireVisible(EmergencyIncident item, UUID actorId, String role) {
        if (UserRole.RESIDENT.matches(role)) requireResidentOwner(item, actorId, role);
        else requireManager(actorId, role);
    }

    private void requireResidentOwner(EmergencyIncident item, UUID actorId, String role) {
        if (!UserRole.RESIDENT.matches(role) || !actorId.equals(item.getResidentId())) {
            throw new AuthorizationException("You can only manage your own emergency incidents");
        }
    }

    private void requireManager(UUID actorId, String role) {
        if (UserRole.SOCIETY_ADMIN.matches(role)) return;
        if (UserRole.STAFF.matches(role)
                && permissions.existsByStaffUserIdAndPermissionCode(
                        actorId, StaffPermissionCode.EMERGENCY_INCIDENTS.code())) return;
        throw new AuthorizationException("Emergency incidents permission is required");
    }

    private void requireAdmin(String role) {
        if (!UserRole.SOCIETY_ADMIN.matches(role)) {
            throw new AuthorizationException("Society administrator access is required");
        }
    }

    private UserAccount requireResident(UUID societyId, UUID id) {
        return users.findById(id)
                .filter(user -> societyId.equals(user.getSocietyId()))
                .filter(user -> UserRole.RESIDENT.matches(user.getRole()))
                .orElseThrow(() -> new ResourceNotFoundException("Resident not found"));
    }

    private UserAccount requireStaff(UUID societyId, UUID id) {
        return users.findById(id)
                .filter(user -> societyId.equals(user.getSocietyId()))
                .filter(user -> UserRole.STAFF.matches(user.getRole()))
                .filter(user -> AccountStatus.ACTIVE.matches(user.getStatus()))
                .filter(
                        user ->
                                permissions.existsByStaffUserIdAndPermissionCode(
                                        id, StaffPermissionCode.EMERGENCY_INCIDENTS.code()))
                .orElseThrow(
                        () ->
                                new ResourceNotFoundException(
                                        "Eligible emergency responder not found"));
    }

    private EmergencyIncident requireIncident(UUID societyId, UUID id) {
        return incidents
                .findByIdAndSocietyId(id, societyId)
                .orElseThrow(() -> new ResourceNotFoundException("Emergency incident not found"));
    }

    private void requireOpen(EmergencyIncident item) {
        if (!EmergencyIncidentStatus.from(item.getStatus()).isOpen()) {
            throw new IllegalStateException("Incident is not open");
        }
    }

    private void requireStatus(EmergencyIncident item, EmergencyIncidentStatus status) {
        if (!status.matches(item.getStatus())) {
            throw new IllegalStateException(
                    "Incident must be " + status.code().toLowerCase(Locale.ROOT));
        }
    }

    private void requireNote(String note, String message) {
        if (note == null || note.isBlank()) throw new IllegalArgumentException(message);
    }

    private void notifySocietyAdmins(UUID societyId, EmergencyIncident item, String template) {
        users.findBySocietyIdAndRoleOrderByFullName(societyId, UserRole.SOCIETY_ADMIN.code())
                .forEach(user -> notify(user, item, template));
    }

    private void notifyRelevant(EmergencyIncident item, String template) {
        notifyUser(item.getReporterId(), item, template);
        if (item.getResidentId() != null && !item.getResidentId().equals(item.getReporterId())) {
            notifyUser(item.getResidentId(), item, template);
        }
    }

    private void notifyUser(UUID userId, EmergencyIncident item, String template) {
        users.findById(userId).ifPresent(user -> notify(user, item, template));
    }

    private void notify(UserAccount user, EmergencyIncident item, String template) {
        if (user.getEmail() == null || user.getEmail().isBlank()) return;
        var message = new NotificationOutbox();
        message.setSocietyId(item.getSocietyId());
        message.setChannel("EMAIL");
        message.setDestination(user.getEmail());
        message.setTemplateCode(template);
        message.setPayload(
                "{\"incidentNumber\":\""
                        + item.getIncidentNumber()
                        + "\",\"severity\":\""
                        + item.getSeverity()
                        + "\",\"title\":\""
                        + item.getTitle().replace("\"", "")
                        + "\"}");
        message.setStatus(NotificationStatus.PENDING.code());
        message.setAttempts(0);
        message.setCreatedAt(OffsetDateTime.now());
        notifications.save(message);
    }

    private void addEvent(
            EmergencyIncident item,
            UUID actorId,
            String role,
            String type,
            String from,
            String to,
            String note) {
        var event = new EmergencyIncidentEvent();
        event.setIncidentId(item.getId());
        event.setSocietyId(item.getSocietyId());
        event.setEventType(type);
        event.setFromStatus(from);
        event.setToStatus(to);
        event.setNote(blankToNull(note));
        event.setActorId(actorId);
        event.setActorRole(role);
        event.setOccurredAt(OffsetDateTime.now());
        events.save(event);
    }

    private Map<String, Object> view(EmergencyIncident item) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", item.getId());
        map.put("incident_number", item.getIncidentNumber());
        map.put("incident_type", item.getIncidentType());
        map.put("severity", item.getSeverity());
        map.put("title", item.getTitle());
        map.put("description", item.getDescription());
        map.put("location_details", item.getLocationDetails());
        map.put("latitude", item.getLatitude());
        map.put("longitude", item.getLongitude());
        map.put("people_affected", item.getPeopleAffected());
        map.put("injured_person_name", item.getInjuredPersonName());
        map.put("injured_person_mobile", item.getInjuredPersonMobile());
        map.put("injury_details", item.getInjuryDetails());
        map.put("status", item.getStatus());
        map.put("emergency_contact_notified", item.isEmergencyContactNotified());
        map.put("ambulance_requested", item.isAmbulanceRequested());
        map.put("police_requested", item.isPoliceRequested());
        map.put("fire_service_requested", item.isFireServiceRequested());
        map.put("hospital_name", item.getHospitalName());
        map.put("external_reference", item.getExternalReference());
        map.put("acknowledged_at", item.getAcknowledgedAt());
        map.put("response_started_at", item.getResponseStartedAt());
        map.put("arrived_at", item.getArrivedAt());
        map.put("stabilized_at", item.getStabilizedAt());
        map.put("resolved_at", item.getResolvedAt());
        map.put("closed_at", item.getClosedAt());
        map.put("resolution_summary", item.getResolutionSummary());
        map.put("closed_reason", item.getClosedReason());
        map.put("created_at", item.getCreatedAt());
        map.put("updated_at", item.getUpdatedAt());
        map.put("reporter_id", item.getReporterId());
        users.findById(item.getReporterId())
                .ifPresent(user -> map.put("reporter_name", user.getFullName()));
        map.put("resident_id", item.getResidentId());
        if (item.getResidentId() != null) {
            users.findById(item.getResidentId())
                    .ifPresent(
                            user -> {
                                map.put("resident_name", user.getFullName());
                                map.put("resident_mobile", user.getMobile());
                            });
        }
        map.put("assigned_staff_id", item.getAssignedStaffId());
        if (item.getAssignedStaffId() != null) {
            users.findById(item.getAssignedStaffId())
                    .ifPresent(
                            user -> {
                                map.put("assigned_staff_name", user.getFullName());
                                map.put("assigned_staff_mobile", user.getMobile());
                            });
        }
        map.put("flat_id", item.getFlatId());
        if (item.getFlatId() != null) {
            flats.findById(item.getFlatId())
                    .ifPresent(
                            flat -> {
                                map.put("space_number", flat.getFlatNumber());
                                floors.findById(flat.getFloorId())
                                        .flatMap(floor -> blocks.findById(floor.getBlockId()))
                                        .ifPresent(block -> map.put("block", block.getName()));
                            });
        }
        return map;
    }

    private Map<String, Object> directoryView(EmergencyDirectoryContact item) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", item.getId());
        map.put("contact_type", item.getContactType());
        map.put("name", item.getName());
        map.put("phone", item.getPhone());
        map.put("alternate_phone", item.getAlternatePhone());
        map.put("address", item.getAddress());
        map.put("available_24x7", item.isAvailable24x7());
        map.put("priority", item.getPriority());
        return map;
    }

    private Map<String, Object> eventView(EmergencyIncidentEvent item) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", item.getId());
        map.put("event_type", item.getEventType());
        map.put("from_status", item.getFromStatus());
        map.put("to_status", item.getToStatus());
        map.put("note", item.getNote());
        map.put("actor_role", item.getActorRole());
        map.put("occurred_at", item.getOccurredAt());
        users.findById(item.getActorId())
                .ifPresent(user -> map.put("actor_name", user.getFullName()));
        return map;
    }

    private String incidentNumber() {
        return "EMG-"
                + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMM"))
                + "-"
                + UUID.randomUUID().toString().replace("-", "").substring(0, 10).toUpperCase();
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
