package com.societyapp.application.port.in;

import java.util.UUID;

/** Checks whether a society can access a product feature. */
public interface ServiceEntitlementUseCase {
    boolean isEnabled(UUID societyId, String serviceCode);
}
