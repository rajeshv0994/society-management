package com.societyapp.application.usecase;

import com.societyapp.application.exception.AuthorizationException;
import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.port.in.StructureAccessUseCase;
import com.societyapp.application.port.in.VisitorUseCase;
import com.societyapp.application.port.out.DocumentStorage;
import com.societyapp.application.port.out.UploadedFile;
import com.societyapp.application.port.out.persistence.*;
import com.societyapp.domain.model.Visitor;
import com.societyapp.domain.type.AccountStatus;
import com.societyapp.domain.type.ApprovalAction;
import com.societyapp.domain.type.StaffPermissionCode;
import com.societyapp.domain.type.UserRole;
import com.societyapp.domain.type.VisitorStatus;
import com.societyapp.domain.type.VisitorTargetType;
import java.time.OffsetDateTime;
import java.util.*;

public class VisitorService implements VisitorUseCase {
    private final VisitorRepository visitors;
    private final FlatRepository flats;
    private final FloorRepository floors;
    private final BlockRepository blocks;
    private final StructureAccessUseCase access;
    private final UserAccountJpaRepository users;
    private final DocumentStorage storage;
    private final VisitorPhotoRepository visitorPhotos;
    private final StaffPermissionRepository staffPermissions;

    public VisitorService(
            VisitorRepository visitors,
            FlatRepository flats,
            FloorRepository floors,
            BlockRepository blocks,
            StructureAccessUseCase access,
            UserAccountJpaRepository users,
            DocumentStorage storage,
            VisitorPhotoRepository visitorPhotos,
            StaffPermissionRepository staffPermissions) {
        this.visitors = visitors;
        this.flats = flats;
        this.floors = floors;
        this.blocks = blocks;
        this.access = access;
        this.users = users;
        this.storage = storage;
        this.visitorPhotos = visitorPhotos;
        this.staffPermissions = staffPermissions;
    }

    public List<Map<String, Object>> list(UUID societyId, UUID userId, String role) {
        boolean gateStaff = UserRole.STAFF.matches(role) && canManageGate(userId);
        return visitors.findBySocietyIdOrderByCreatedAtDesc(societyId).stream()
                .filter(
                        visitor ->
                                switch (UserRole.from(role)) {
                                    case RESIDENT ->
                                            userId.equals(visitor.getHostResidentId())
                                                    || (visitor.getHostResidentId() == null
                                                            && visitor.getFlatId() != null
                                                            && access.occupiedBy(
                                                                    visitor.getFlatId(), userId));
                                    case STAFF ->
                                            gateStaff || userId.equals(visitor.getTargetUserId());
                                    default -> true;
                                })
                .map(this::view)
                .toList();
    }

    public Map<String, Object> permissions(UUID userId, String role) {
        boolean gate = !UserRole.STAFF.matches(role) || canManageGate(userId);
        return Map.of("user_id", userId, "can_manage_gate", gate);
    }

    public Map<String, Object> memberOptions(UUID societyId, UUID residentId) {
        var spaces = new ArrayList<Map<String, Object>>();
        for (var flat : flats.findAll()) {
            if (!access.belongsToSociety(flat.getId(), societyId)
                    || !access.occupiedBy(flat.getId(), residentId)) continue;
            var row = new LinkedHashMap<String, Object>();
            row.put("space_id", flat.getId());
            row.put("space_number", flat.getFlatNumber());
            floors.findById(flat.getFloorId())
                    .flatMap(floor -> blocks.findById(floor.getBlockId()))
                    .ifPresent(block -> row.put("block", block.getName()));
            spaces.add(row);
        }
        return Map.of("resident_id", residentId, "spaces", spaces);
    }

    public void requireGate(UUID userId, String role) {
        if (UserRole.SOCIETY_ADMIN.matches(role)) return;
        if (!UserRole.STAFF.matches(role) || !canManageGate(userId)) {
            throw new AuthorizationException("Visitor Gate permission is required");
        }
    }

    private boolean canManageGate(UUID staffId) {
        return staffPermissions.existsByStaffUserIdAndPermissionCode(
                staffId, StaffPermissionCode.VISITORS.code());
    }

    public List<Map<String, Object>> hosts(UUID societyId) {
        var residentNames = new HashMap<UUID, String>();
        users.findBySocietyIdAndRoleOrderByFullName(societyId, UserRole.RESIDENT.code()).stream()
                .filter(user -> AccountStatus.ACTIVE.matches(user.getStatus()))
                .forEach(user -> residentNames.put(user.getId(), user.getFullName()));
        var result = new ArrayList<Map<String, Object>>();
        for (var flat : flats.findAll()) {
            if (!access.belongsToSociety(flat.getId(), societyId)) continue;
            for (UUID residentId : new UUID[] {flat.getActiveOwnerId(), flat.getActiveTenantId()}) {
                if (residentId == null || !residentNames.containsKey(residentId)) continue;
                var row = new LinkedHashMap<String, Object>();
                row.put("resident_id", residentId);
                row.put("full_name", residentNames.get(residentId));
                users.findById(residentId).ifPresent(user -> row.put("mobile", user.getMobile()));
                row.put("space_id", flat.getId());
                row.put("space_number", flat.getFlatNumber());
                floors.findById(flat.getFloorId())
                        .flatMap(floor -> blocks.findById(floor.getBlockId()))
                        .ifPresent(block -> row.put("block", block.getName()));
                result.add(row);
            }
        }
        result.sort(Comparator.comparing(row -> row.get("full_name").toString()));
        return result;
    }

    public List<Map<String, Object>> targets(UUID societyId) {
        return users.findAll().stream()
                .filter(user -> societyId.equals(user.getSocietyId()))
                .filter(user -> AccountStatus.ACTIVE.matches(user.getStatus()))
                .filter(user -> UserRole.STAFF.matches(user.getRole()))
                .sorted(Comparator.comparing(user -> user.getFullName().toLowerCase()))
                .map(
                        user -> {
                            var row = new LinkedHashMap<String, Object>();
                            row.put("user_id", user.getId());
                            row.put("full_name", user.getFullName());
                            row.put("role", user.getRole());
                            row.put("mobile", user.getMobile());
                            return (Map<String, Object>) row;
                        })
                .toList();
    }

    public Map<String, Object> create(
            UUID societyId,
            UUID userId,
            String role,
            UUID flatId,
            UUID hostResidentId,
            String targetType,
            UUID targetUserId,
            String targetName,
            String visitorName,
            String mobile,
            String purpose,
            String vehicleNumber,
            OffsetDateTime expectedAt,
            int accompanyingMembers) {
        if (UserRole.STAFF.matches(role)) requireGate(userId, role);
        if (UserRole.RESIDENT.matches(role)) {
            targetType = UserRole.RESIDENT.code();
            hostResidentId = userId;
            targetUserId = userId;
        }
        targetType = targetType == null ? UserRole.RESIDENT.code() : targetType;
        var requestedTargetType = VisitorTargetType.from(targetType);
        targetType = requestedTargetType.code();
        com.societyapp.domain.model.UserAccount host = null;
        if (UserRole.RESIDENT.matches(targetType)) {
            if (flatId == null || hostResidentId == null) {
                throw new IllegalArgumentException("Resident and space are required");
            }
            access.requireFlat(flatId, societyId);
            host =
                    users.findById(hostResidentId)
                            .filter(user -> societyId.equals(user.getSocietyId()))
                            .filter(user -> UserRole.RESIDENT.matches(user.getRole()))
                            .orElseThrow(
                                    () -> new ResourceNotFoundException("Host resident not found"));
            if (!access.occupiedBy(flatId, hostResidentId)) {
                throw new IllegalArgumentException(
                        "Host resident does not occupy the selected space");
            }
            targetUserId = hostResidentId;
            targetName = host.getFullName();
        } else if (UserRole.STAFF.matches(targetType)) {
            String requiredRole = requestedTargetType.requiredRole().code();
            var target =
                    users.findById(targetUserId)
                            .filter(user -> societyId.equals(user.getSocietyId()))
                            .filter(user -> requiredRole.equals(user.getRole()))
                            .orElseThrow(
                                    () -> new ResourceNotFoundException("Visit target not found"));
            targetName = target.getFullName();
            flatId = null;
            hostResidentId = null;
        } else {
            if (targetName == null || targetName.isBlank()) {
                throw new IllegalArgumentException("Person or destination name is required");
            }
            targetUserId = null;
            flatId = null;
            hostResidentId = null;
        }
        boolean residentPreApproval =
                host != null && UserRole.RESIDENT.matches(role) && userId.equals(host.getId());
        var visitor = new Visitor();
        visitor.setSocietyId(societyId);
        visitor.setFlatId(flatId);
        visitor.setVisitorName(visitorName);
        visitor.setMobile(mobile);
        visitor.setPurpose(purpose);
        visitor.setVehicleNumber(vehicleNumber);
        visitor.setExpectedAt(expectedAt);
        visitor.setHostResidentId(hostResidentId);
        visitor.setTargetType(targetType);
        visitor.setTargetUserId(targetUserId);
        visitor.setTargetName(targetName);
        visitor.setAccompanyingMembers(accompanyingMembers);
        visitor.setApprovedBy(residentPreApproval ? userId : null);
        visitor.setResidentDecisionAt(residentPreApproval ? OffsetDateTime.now() : null);
        visitor.setStatus(
                residentPreApproval
                        ? VisitorStatus.APPROVED.code()
                        : UserRole.RESIDENT.matches(targetType)
                                ? VisitorStatus.PENDING_RESIDENT_APPROVAL.code()
                                : VisitorStatus.PENDING_STAFF_APPROVAL.code());
        visitor.setCreatedAt(OffsetDateTime.now());
        visitor = visitors.save(visitor);
        return Map.of("id", visitor.getId(), "status", visitor.getStatus());
    }

    public Map<String, Object> uploadPhoto(
            UUID societyId, UUID actorId, String role, UUID visitorId, UploadedFile file) {
        requireGate(actorId, role);
        var visitor =
                visitors.findByIdAndSocietyId(visitorId, societyId)
                        .orElseThrow(() -> new ResourceNotFoundException("Visitor not found"));
        var photo = new com.societyapp.domain.model.VisitorPhoto();
        photo.setVisitorId(visitorId);
        photo.setStorageKey(storage.storeImage(societyId, file));
        photo.setContentType(file.contentType());
        photo.setCreatedAt(OffsetDateTime.now());
        photo = visitorPhotos.save(photo);
        storage.attach(photo.getStorageKey(), "VISITOR_PHOTO", photo.getId(), "Visitor photo");
        return Map.of(
                "id",
                photo.getId(),
                "visitorId",
                visitorId,
                "photoUrl",
                "/api/visitors/photos/" + photo.getId());
    }

    public PhotoContent photo(UUID societyId, UUID userId, String role, UUID photoId) {
        var photo =
                visitorPhotos
                        .findById(photoId)
                        .filter(
                                item ->
                                        visitors.findByIdAndSocietyId(
                                                        item.getVisitorId(), societyId)
                                                .filter(visitor -> canView(visitor, userId, role))
                                                .isPresent())
                        .orElseThrow(
                                () -> new ResourceNotFoundException("Visitor photo not found"));
        return new PhotoContent(storage.load(photo.getStorageKey()), photo.getContentType());
    }

    public Map<String, Object> residentDecision(
            UUID societyId, UUID residentId, UUID visitorId, String decision, String note) {
        var visitor =
                visitors.findByIdAndSocietyId(visitorId, societyId)
                        .filter(item -> residentId.equals(item.getHostResidentId()))
                        .filter(
                                item ->
                                        VisitorStatus.PENDING_RESIDENT_APPROVAL.matches(
                                                item.getStatus()))
                        .orElseThrow(
                                () ->
                                        new IllegalStateException(
                                                "Visitor is not awaiting this resident's approval"));
        boolean approved = ApprovalAction.from(decision) == ApprovalAction.APPROVE;
        if (approved && visitorPhotos.countByVisitorId(visitorId) == 0) {
            throw new IllegalStateException("Visitor photo is required before approval");
        }
        visitor.setStatus(approved ? VisitorStatus.APPROVED.code() : VisitorStatus.DENIED.code());
        visitor.setApprovedBy(approved ? residentId : null);
        visitor.setResidentDecisionAt(OffsetDateTime.now());
        visitor.setApprovalMethod("RESIDENT_APP");
        visitor.setApprovalNote(
                note == null || note.isBlank()
                        ? approved ? "Approved by resident" : "Denied by resident"
                        : note.trim());
        visitors.save(visitor);
        return Map.of("id", visitorId, "status", visitor.getStatus());
    }

    public Map<String, Object> residentCancel(
            UUID societyId, UUID residentId, UUID visitorId, String note) {
        var visitor =
                visitors.findByIdAndSocietyId(visitorId, societyId)
                        .filter(item -> residentId.equals(item.getHostResidentId()))
                        .filter(
                                item ->
                                        Set.of(
                                                        VisitorStatus.PENDING_RESIDENT_APPROVAL
                                                                .code(),
                                                        VisitorStatus.APPROVED.code())
                                                .contains(item.getStatus()))
                        .orElseThrow(
                                () ->
                                        new IllegalStateException(
                                                "Only your pending or approved visitor can be cancelled"));
        visitor.setStatus(VisitorStatus.CANCELLED.code());
        visitor.setResidentDecisionAt(OffsetDateTime.now());
        visitor.setApprovalMethod("RESIDENT_CANCELLED");
        visitor.setApprovalNote(
                note == null || note.isBlank() ? "Cancelled by resident" : note.trim());
        visitors.save(visitor);
        return Map.of("id", visitorId, "status", visitor.getStatus());
    }

    public Map<String, Object> staffApproval(
            UUID societyId, UUID staffId, String role, UUID visitorId, String note) {
        requireGate(staffId, role);
        var visitor =
                visitors.findByIdAndSocietyId(visitorId, societyId)
                        .filter(
                                item ->
                                        Set.of(
                                                        VisitorStatus.PENDING_RESIDENT_APPROVAL
                                                                .code(),
                                                        VisitorStatus.PENDING_STAFF_APPROVAL.code())
                                                .contains(item.getStatus()))
                        .orElseThrow(
                                () ->
                                        new IllegalStateException(
                                                "Visitor is not awaiting approval"));
        if (visitorPhotos.countByVisitorId(visitorId) == 0) {
            throw new IllegalStateException("Visitor photo is required before approval");
        }
        visitor.setStatus(VisitorStatus.APPROVED.code());
        visitor.setStaffApprovedBy(staffId);
        visitor.setApprovalMethod("PHONE_VERIFIED");
        visitor.setApprovalNote(note);
        visitor.setResidentDecisionAt(OffsetDateTime.now());
        visitors.save(visitor);
        return Map.of("id", visitorId, "status", visitor.getStatus());
    }

    public Map<String, Object> targetStaffDecision(
            UUID societyId, UUID staffId, UUID visitorId, String decision) {
        var visitor =
                visitors.findByIdAndSocietyId(visitorId, societyId)
                        .filter(item -> staffId.equals(item.getTargetUserId()))
                        .filter(item -> UserRole.STAFF.matches(item.getTargetType()))
                        .filter(
                                item ->
                                        VisitorStatus.PENDING_STAFF_APPROVAL.matches(
                                                item.getStatus()))
                        .orElseThrow(
                                () ->
                                        new IllegalStateException(
                                                "Visitor is not awaiting this staff member's approval"));
        if (visitorPhotos.countByVisitorId(visitorId) == 0) {
            throw new IllegalStateException("Visitor photo is required before approval");
        }
        boolean approved = ApprovalAction.from(decision) == ApprovalAction.APPROVE;
        visitor.setStatus(approved ? VisitorStatus.APPROVED.code() : VisitorStatus.DENIED.code());
        visitor.setStaffApprovedBy(staffId);
        visitor.setApprovalMethod("STAFF_SELF");
        visitor.setApprovalNote(
                approved ? "Approved by staff member being visited" : "Denied by staff member");
        visitor.setResidentDecisionAt(OffsetDateTime.now());
        visitors.save(visitor);
        return Map.of("id", visitorId, "status", visitor.getStatus());
    }

    public Map<String, Object> updateStatus(
            UUID societyId, UUID actorId, String role, UUID visitorId, String status) {
        requireGate(actorId, role);
        var visitor =
                visitors.findByIdAndSocietyId(visitorId, societyId)
                        .orElseThrow(() -> new ResourceNotFoundException("Visitor not found"));
        var requestedStatus = VisitorStatus.from(status);
        if (requestedStatus != VisitorStatus.CHECKED_IN
                && requestedStatus != VisitorStatus.CHECKED_OUT) {
            throw new IllegalArgumentException("Invalid visitor gate status");
        }
        if (requestedStatus == VisitorStatus.CHECKED_IN) {
            if (!VisitorStatus.APPROVED.matches(visitor.getStatus())) {
                throw new IllegalStateException("Visitor approval is required before check-in");
            }
            if (visitorPhotos.countByVisitorId(visitorId) == 0) {
                throw new IllegalStateException("Visitor photo is required before check-in");
            }
        }
        if (requestedStatus == VisitorStatus.CHECKED_OUT
                && !VisitorStatus.CHECKED_IN.matches(visitor.getStatus())) {
            throw new IllegalStateException("Only checked-in visitors can be checked out");
        }
        visitor.setStatus(requestedStatus.code());
        if (requestedStatus == VisitorStatus.CHECKED_IN) {
            visitor.setCheckedInBy(actorId);
            visitor.setCheckedInAt(OffsetDateTime.now());
        } else {
            visitor.setCheckedOutAt(OffsetDateTime.now());
        }
        visitors.save(visitor);
        return Map.of("id", visitorId, "status", requestedStatus.code());
    }

    private Map<String, Object> view(Visitor visitor) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", visitor.getId());
        map.put("society_id", visitor.getSocietyId());
        map.put("space_id", visitor.getFlatId());
        map.put("unit_id", visitor.getFlatId());
        map.put("flat_id", visitor.getFlatId());
        map.put("visitor_name", visitor.getVisitorName());
        map.put("mobile", visitor.getMobile());
        map.put("purpose", visitor.getPurpose());
        map.put("vehicle_number", visitor.getVehicleNumber());
        map.put("expected_at", visitor.getExpectedAt());
        map.put("approved_by", visitor.getApprovedBy());
        map.put("host_resident_id", visitor.getHostResidentId());
        map.put("target_type", visitor.getTargetType());
        map.put("target_user_id", visitor.getTargetUserId());
        map.put("target_name", visitor.getTargetName());
        map.put(
                "target_mobile",
                visitor.getTargetUserId() == null
                        ? null
                        : users.findById(visitor.getTargetUserId())
                                .map(user -> user.getMobile())
                                .orElse(null));
        map.put(
                "host_resident_name",
                visitor.getHostResidentId() == null
                        ? null
                        : users.findById(visitor.getHostResidentId())
                                .map(user -> user.getFullName())
                                .orElse(null));
        map.put("accompanying_members", visitor.getAccompanyingMembers());
        map.put("total_people", visitor.getAccompanyingMembers() + 1);
        var photoUrls =
                visitorPhotos.findByVisitorIdOrderByCreatedAt(visitor.getId()).stream()
                        .map(photo -> "/api/visitors/photos/" + photo.getId())
                        .toList();
        map.put("photo_urls", photoUrls);
        map.put("photo_url", photoUrls.isEmpty() ? null : photoUrls.getFirst());
        map.put("photo_count", photoUrls.size());
        map.put("resident_decision_at", visitor.getResidentDecisionAt());
        map.put("staff_approved_by", visitor.getStaffApprovedBy());
        map.put("approval_method", visitor.getApprovalMethod());
        map.put("approval_note", visitor.getApprovalNote());
        map.put("checked_in_by", visitor.getCheckedInBy());
        map.put("checked_in_at", visitor.getCheckedInAt());
        map.put("checked_out_at", visitor.getCheckedOutAt());
        map.put("status", visitor.getStatus());
        map.put("created_at", visitor.getCreatedAt());
        if (visitor.getFlatId() != null) {
            flats.findById(visitor.getFlatId())
                    .ifPresent(
                            flat -> {
                                map.put("space_number", flat.getFlatNumber());
                                map.put("unit_number", flat.getFlatNumber());
                                map.put("flat_number", flat.getFlatNumber());
                                floors.findById(flat.getFloorId())
                                        .flatMap(floor -> blocks.findById(floor.getBlockId()))
                                        .ifPresent(block -> map.put("block", block.getName()));
                            });
        }
        return map;
    }

    private boolean canView(Visitor visitor, UUID userId, String role) {
        return switch (UserRole.from(role)) {
            case RESIDENT ->
                    userId.equals(visitor.getHostResidentId())
                            || (visitor.getHostResidentId() == null
                                    && visitor.getFlatId() != null
                                    && access.occupiedBy(visitor.getFlatId(), userId));
            case STAFF -> canManageGate(userId) || userId.equals(visitor.getTargetUserId());
            default -> true;
        };
    }
}
