package com.societyapp.application.usecase;

import com.societyapp.application.exception.AuthorizationException;
import com.societyapp.application.exception.ConflictException;
import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.port.in.AmenityUseCase;
import com.societyapp.application.port.out.persistence.*;
import com.societyapp.domain.model.*;
import com.societyapp.domain.type.AmenityBookingAction;
import com.societyapp.domain.type.AmenityBookingStatus;
import com.societyapp.domain.type.AmenityPricingType;
import com.societyapp.domain.type.PaymentMethod;
import com.societyapp.domain.type.PaymentStatus;
import com.societyapp.domain.type.StaffPermissionCode;
import com.societyapp.domain.type.UserRole;
import java.math.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class AmenityService implements AmenityUseCase {
    private static final ZoneId SOCIETY_TIME_ZONE = ZoneId.of("Asia/Kolkata");
    private static final Set<String> BLOCKING_STATUSES =
            Set.of(
                    PaymentStatus.PENDING_PAYMENT.code(),
                    AmenityBookingStatus.PENDING_APPROVAL.code(),
                    AmenityBookingStatus.CONFIRMED.code(),
                    AmenityBookingStatus.CHECKED_IN.code());
    private static final Set<PaymentMethod> ONLINE_METHODS =
            Set.of(PaymentMethod.UPI, PaymentMethod.CARD, PaymentMethod.NET_BANKING);

    private final AmenityRepository amenities;
    private final AmenityBookingRepository bookings;
    private final StaffPermissionRepository permissions;
    private final UserAccountJpaRepository users;
    private final SocietyPaymentSettingRepository paymentSettings;

    public AmenityService(
            AmenityRepository amenities,
            AmenityBookingRepository bookings,
            StaffPermissionRepository permissions,
            UserAccountJpaRepository users,
            SocietyPaymentSettingRepository paymentSettings) {
        this.amenities = amenities;
        this.bookings = bookings;
        this.permissions = permissions;
        this.users = users;
        this.paymentSettings = paymentSettings;
    }

    public List<Map<String, Object>> list(UUID societyId, String role) {
        return amenities.findBySocietyIdOrderByName(societyId).stream()
                .filter(item -> !UserRole.RESIDENT.matches(role) || item.isActive())
                .map(this::view)
                .toList();
    }

    public List<Map<String, Object>> bookings(UUID societyId, UUID userId, String role) {
        if (UserRole.STAFF.matches(role)) requireStaffPermission(userId);
        var rows =
                UserRole.RESIDENT.matches(role)
                        ? bookings.findBySocietyIdAndBookedByOrderByStartsAtDesc(societyId, userId)
                        : bookings.findBySocietyIdOrderByStartsAtDesc(societyId);
        return rows.stream().map(this::bookingView).toList();
    }

    public Map<String, Object> create(
            UUID societyId,
            String name,
            String amenityType,
            String amenityCode,
            String description,
            String location,
            Integer capacity,
            BigDecimal charge,
            String pricingType,
            BigDecimal bookingCharge,
            BigDecimal refundableDeposit,
            LocalTime opensAt,
            LocalTime closesAt,
            boolean approvalRequired,
            int slotMinutes,
            int advanceDays,
            int cancellationHours,
            String instructions) {
        var amenity = new Amenity();
        amenity.setSocietyId(societyId);
        amenity.setCreatedAt(OffsetDateTime.now());
        applyAmenity(
                amenity,
                name,
                amenityType,
                amenityCode,
                description,
                location,
                capacity,
                charge,
                pricingType,
                bookingCharge,
                refundableDeposit,
                opensAt,
                closesAt,
                approvalRequired,
                slotMinutes,
                advanceDays,
                cancellationHours,
                instructions,
                true);
        return view(amenities.save(amenity));
    }

    public Map<String, Object> update(
            UUID societyId,
            UUID amenityId,
            String name,
            String amenityType,
            String amenityCode,
            String description,
            String location,
            Integer capacity,
            BigDecimal charge,
            String pricingType,
            BigDecimal bookingCharge,
            BigDecimal refundableDeposit,
            LocalTime opensAt,
            LocalTime closesAt,
            boolean approvalRequired,
            int slotMinutes,
            int advanceDays,
            int cancellationHours,
            String instructions,
            boolean active) {
        var amenity = requireAmenity(societyId, amenityId, false);
        applyAmenity(
                amenity,
                name,
                amenityType,
                amenityCode,
                description,
                location,
                capacity,
                charge,
                pricingType,
                bookingCharge,
                refundableDeposit,
                opensAt,
                closesAt,
                approvalRequired,
                slotMinutes,
                advanceDays,
                cancellationHours,
                instructions,
                active);
        return view(amenities.save(amenity));
    }

    public Map<String, Object> book(
            UUID societyId,
            UUID userId,
            UUID amenityId,
            OffsetDateTime start,
            OffsetDateTime end,
            int attendees,
            String purpose) {
        if (!end.isAfter(start)) {
            throw new IllegalArgumentException("Booking end must be after start");
        }
        if (!start.isAfter(OffsetDateTime.now())) {
            throw new IllegalArgumentException("Booking must start in the future");
        }
        var amenity = requireAmenity(societyId, amenityId, true);
        if (start.isAfter(OffsetDateTime.now().plusDays(amenity.getAdvanceBookingDays()))) {
            throw new IllegalArgumentException(
                    "This amenity can be booked up to "
                            + amenity.getAdvanceBookingDays()
                            + " days ahead");
        }
        if (amenity.getCapacity() != null && attendees > amenity.getCapacity()) {
            throw new IllegalArgumentException(
                    "Attendees exceed the amenity capacity of " + amenity.getCapacity());
        }
        validateOperatingHours(amenity, start, end);
        long minutes = Duration.between(start, end).toMinutes();
        if (minutes < amenity.getSlotMinutes() || minutes % amenity.getSlotMinutes() != 0) {
            throw new IllegalArgumentException(
                    "Booking duration must use " + amenity.getSlotMinutes() + " minute slots");
        }
        if (bookings.existsByAmenityIdAndStatusInAndStartsAtLessThanAndEndsAtGreaterThan(
                amenityId, BLOCKING_STATUSES, end, start)) {
            throw new ConflictException("Amenity is already reserved for this time");
        }
        var baseCharge = calculateBaseCharge(amenity, minutes);
        var deposit = amenity.getRefundableDeposit();
        var amount = baseCharge.add(deposit);
        var booking = new AmenityBooking();
        booking.setSocietyId(societyId);
        booking.setAmenityId(amenityId);
        booking.setBookedBy(userId);
        booking.setBookingNumber(bookingNumber());
        booking.setStartsAt(start);
        booking.setEndsAt(end);
        booking.setAttendees(attendees);
        booking.setPurpose(blankToNull(purpose));
        booking.setAmount(amount);
        booking.setBaseCharge(baseCharge);
        booking.setDepositAmount(deposit);
        booking.setPaymentStatus(
                amount.signum() == 0 ? PaymentStatus.FREE.code() : PaymentStatus.PENDING.code());
        booking.setStatus(
                amount.signum() > 0
                        ? PaymentStatus.PENDING_PAYMENT.code()
                        : amenity.isBookingApprovalRequired()
                                ? AmenityBookingStatus.PENDING_APPROVAL.code()
                                : AmenityBookingStatus.CONFIRMED.code());
        booking.setCreatedAt(OffsetDateTime.now());
        booking.setUpdatedAt(OffsetDateTime.now());
        return bookingView(bookings.save(booking));
    }

    public Map<String, Object> checkout(
            UUID societyId, UUID actorId, String role, UUID bookingId, String method) {
        if (UserRole.STAFF.matches(role)) requireStaffPermission(actorId);
        var requestedMethod = PaymentMethod.from(method);
        if (!ONLINE_METHODS.contains(requestedMethod)) {
            throw new IllegalArgumentException("Invalid Razorpay payment method");
        }
        var setting =
                paymentSettings
                        .findBySocietyId(societyId)
                        .orElseThrow(
                                () ->
                                        new IllegalStateException(
                                                "Society online payment account is not configured"));
        if (!setting.isTestMode()) {
            throw new IllegalStateException("Live Razorpay amenity payments are not enabled yet");
        }
        var booking = requireBooking(societyId, bookingId);
        requireBookingOwnerOrManager(booking, actorId, role);
        if (!PaymentStatus.PENDING.matches(booking.getPaymentStatus())) {
            throw new IllegalStateException("This booking does not have a pending payment");
        }
        booking.setPaymentStatus(PaymentStatus.PAID.code());
        booking.setPaymentMethod(requestedMethod.razorpayCode());
        booking.setPaymentReference(
                "pay_amenity_test_"
                        + UUID.randomUUID().toString().replace("-", "").substring(0, 18));
        moveAfterPayment(booking);
        booking.setUpdatedAt(OffsetDateTime.now());
        return bookingView(bookings.save(booking));
    }

    public Map<String, Object> recordCash(
            UUID societyId, UUID actorId, String role, UUID bookingId) {
        requireManager(actorId, role);
        var booking = requireBooking(societyId, bookingId);
        if (!PaymentStatus.PENDING.matches(booking.getPaymentStatus())) {
            throw new IllegalStateException("This booking does not have a pending payment");
        }
        booking.setPaymentStatus(PaymentStatus.PAID.code());
        booking.setPaymentMethod(PaymentMethod.CASH.code());
        booking.setPaymentReference(
                "AM-CASH-"
                        + UUID.randomUUID()
                                .toString()
                                .replace("-", "")
                                .substring(0, 12)
                                .toUpperCase());
        moveAfterPayment(booking);
        booking.setUpdatedAt(OffsetDateTime.now());
        return bookingView(bookings.save(booking));
    }

    public Map<String, Object> action(
            UUID societyId,
            UUID actorId,
            String role,
            UUID bookingId,
            String action,
            String reason) {
        var booking = requireBooking(societyId, bookingId);
        var requestedAction = AmenityBookingAction.from(action);
        if (requestedAction == AmenityBookingAction.CANCEL) {
            requireBookingOwnerOrManager(booking, actorId, role);
            var amenity = requireAmenity(societyId, booking.getAmenityId(), false);
            if (UserRole.RESIDENT.matches(role)
                    && OffsetDateTime.now()
                            .plusHours(amenity.getCancellationHours())
                            .isAfter(booking.getStartsAt())) {
                throw new IllegalStateException(
                        "Cancellation requires "
                                + amenity.getCancellationHours()
                                + " hours notice");
            }
            if (!Set.of(
                            PaymentStatus.PENDING_PAYMENT.code(),
                            AmenityBookingStatus.PENDING_APPROVAL.code(),
                            AmenityBookingStatus.CONFIRMED.code())
                    .contains(booking.getStatus())) {
                throw new IllegalStateException("This booking cannot be cancelled");
            }
            booking.setStatus(AmenityBookingStatus.CANCELLED.code());
            booking.setCancelledAt(OffsetDateTime.now());
            if (PaymentStatus.PAID.matches(booking.getPaymentStatus())) {
                booking.setPaymentStatus(PaymentStatus.REFUND_PENDING.code());
            }
        } else {
            requireManager(actorId, role);
            switch (requestedAction) {
                case APPROVE -> {
                    requireStatus(booking, AmenityBookingStatus.PENDING_APPROVAL);
                    booking.setStatus(AmenityBookingStatus.CONFIRMED.code());
                    booking.setReviewedBy(actorId);
                    booking.setReviewedAt(OffsetDateTime.now());
                }
                case REJECT -> {
                    requireStatus(booking, AmenityBookingStatus.PENDING_APPROVAL);
                    if (reason == null || reason.isBlank()) {
                        throw new IllegalArgumentException("Rejection reason is required");
                    }
                    booking.setStatus(AmenityBookingStatus.REJECTED.code());
                    booking.setRejectionReason(reason.trim());
                    booking.setReviewedBy(actorId);
                    booking.setReviewedAt(OffsetDateTime.now());
                    if (PaymentStatus.PAID.matches(booking.getPaymentStatus())) {
                        booking.setPaymentStatus(PaymentStatus.REFUND_PENDING.code());
                    }
                }
                case CHECK_IN -> {
                    requireStatus(booking, AmenityBookingStatus.CONFIRMED);
                    booking.setStatus(AmenityBookingStatus.CHECKED_IN.code());
                    booking.setCheckedInAt(OffsetDateTime.now());
                }
                case CHECK_OUT -> {
                    requireStatus(booking, AmenityBookingStatus.CHECKED_IN);
                    booking.setStatus(AmenityBookingStatus.COMPLETED.code());
                    booking.setCheckedOutAt(OffsetDateTime.now());
                }
                case REFUND -> {
                    if (!PaymentStatus.REFUND_PENDING.matches(booking.getPaymentStatus())) {
                        throw new IllegalStateException("Booking does not have a pending refund");
                    }
                    booking.setPaymentStatus(PaymentStatus.REFUNDED.code());
                }
                case CANCEL -> throw new IllegalStateException("Cancellation was already handled");
            }
        }
        booking.setUpdatedAt(OffsetDateTime.now());
        return bookingView(bookings.save(booking));
    }

    private void applyAmenity(
            Amenity amenity,
            String name,
            String amenityType,
            String amenityCode,
            String description,
            String location,
            Integer capacity,
            BigDecimal charge,
            String pricingType,
            BigDecimal bookingCharge,
            BigDecimal refundableDeposit,
            LocalTime opensAt,
            LocalTime closesAt,
            boolean approvalRequired,
            int slotMinutes,
            int advanceDays,
            int cancellationHours,
            String instructions,
            boolean active) {
        if (opensAt != null && closesAt != null && !closesAt.isAfter(opensAt)) {
            throw new IllegalArgumentException("Closing time must be after opening time");
        }
        amenity.setName(name.trim());
        amenity.setAmenityType(amenityType);
        amenity.setAmenityCode(amenityCode.trim().toUpperCase(Locale.ROOT));
        amenity.setDescription(blankToNull(description));
        amenity.setLocation(blankToNull(location));
        amenity.setCapacity(capacity);
        amenity.setHourlyCharge(charge == null ? BigDecimal.ZERO : charge);
        amenity.setPricingType(AmenityPricingType.from(pricingType).code());
        amenity.setBookingCharge(bookingCharge == null ? BigDecimal.ZERO : bookingCharge);
        amenity.setRefundableDeposit(
                refundableDeposit == null ? BigDecimal.ZERO : refundableDeposit);
        amenity.setOpensAt(opensAt);
        amenity.setClosesAt(closesAt);
        amenity.setBookingApprovalRequired(approvalRequired);
        amenity.setSlotMinutes(slotMinutes);
        amenity.setAdvanceBookingDays(advanceDays);
        amenity.setCancellationHours(cancellationHours);
        amenity.setInstructions(blankToNull(instructions));
        amenity.setActive(active);
        amenity.setUpdatedAt(OffsetDateTime.now());
    }

    private BigDecimal calculateBaseCharge(Amenity amenity, long minutes) {
        return switch (AmenityPricingType.from(amenity.getPricingType())) {
            case FREE -> BigDecimal.ZERO;
            case FIXED -> amenity.getBookingCharge();
            case PER_SLOT ->
                    amenity.getBookingCharge()
                            .multiply(BigDecimal.valueOf(minutes / amenity.getSlotMinutes()));
            case HOURLY ->
                    amenity.getHourlyCharge()
                            .multiply(BigDecimal.valueOf(minutes))
                            .divide(BigDecimal.valueOf(60), 2, RoundingMode.HALF_UP);
        };
    }

    private void validateOperatingHours(Amenity amenity, OffsetDateTime start, OffsetDateTime end) {
        var localStart = start.atZoneSameInstant(SOCIETY_TIME_ZONE);
        var localEnd = end.atZoneSameInstant(SOCIETY_TIME_ZONE);
        if (!localStart.toLocalDate().equals(localEnd.toLocalDate())) {
            throw new IllegalArgumentException("Booking must start and end on the same day");
        }
        if (amenity.getOpensAt() != null
                && localStart.toLocalTime().isBefore(amenity.getOpensAt())) {
            throw new IllegalArgumentException("Booking starts before the amenity opens");
        }
        if (amenity.getClosesAt() != null
                && localEnd.toLocalTime().isAfter(amenity.getClosesAt())) {
            throw new IllegalArgumentException("Booking ends after the amenity closes");
        }
    }

    private void moveAfterPayment(AmenityBooking booking) {
        var amenity = requireAmenity(booking.getSocietyId(), booking.getAmenityId(), false);
        booking.setStatus(
                amenity.isBookingApprovalRequired()
                        ? AmenityBookingStatus.PENDING_APPROVAL.code()
                        : AmenityBookingStatus.CONFIRMED.code());
    }

    private Amenity requireAmenity(UUID societyId, UUID amenityId, boolean active) {
        return amenities
                .findByIdAndSocietyId(amenityId, societyId)
                .filter(item -> !active || item.isActive())
                .orElseThrow(() -> new ResourceNotFoundException("Amenity not found"));
    }

    private AmenityBooking requireBooking(UUID societyId, UUID bookingId) {
        return bookings.findByIdAndSocietyId(bookingId, societyId)
                .orElseThrow(() -> new ResourceNotFoundException("Amenity booking not found"));
    }

    private void requireBookingOwnerOrManager(AmenityBooking booking, UUID actorId, String role) {
        if (UserRole.RESIDENT.matches(role) && !booking.getBookedBy().equals(actorId)) {
            throw new AuthorizationException("You can only manage your own amenity booking");
        }
        if (UserRole.STAFF.matches(role)) requireStaffPermission(actorId);
    }

    private void requireManager(UUID actorId, String role) {
        if (UserRole.RESIDENT.matches(role)) {
            throw new AuthorizationException("Amenity management permission is required");
        }
        if (UserRole.STAFF.matches(role)) requireStaffPermission(actorId);
    }

    private void requireStaffPermission(UUID userId) {
        if (!permissions.existsByStaffUserIdAndPermissionCode(
                userId, StaffPermissionCode.AMENITIES.code())) {
            throw new AuthorizationException("Amenities permission is required");
        }
    }

    private void requireStatus(AmenityBooking booking, AmenityBookingStatus status) {
        if (!status.matches(booking.getStatus())) {
            throw new IllegalStateException(
                    "Booking must be " + status.code().toLowerCase(Locale.ROOT));
        }
    }

    private String bookingNumber() {
        return "AMB-"
                + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMM"))
                + "-"
                + UUID.randomUUID().toString().replace("-", "").substring(0, 10).toUpperCase();
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private Map<String, Object> view(Amenity item) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", item.getId());
        map.put("society_id", item.getSocietyId());
        map.put("name", item.getName());
        map.put("amenity_type", item.getAmenityType());
        map.put("amenity_code", item.getAmenityCode());
        map.put("description", item.getDescription());
        map.put("location", item.getLocation());
        map.put("capacity", item.getCapacity());
        map.put("hourly_charge", item.getHourlyCharge());
        map.put("pricing_type", item.getPricingType());
        map.put("booking_charge", item.getBookingCharge());
        map.put("refundable_deposit", item.getRefundableDeposit());
        map.put("opens_at", item.getOpensAt());
        map.put("closes_at", item.getClosesAt());
        map.put("booking_approval_required", item.isBookingApprovalRequired());
        map.put("slot_minutes", item.getSlotMinutes());
        map.put("advance_booking_days", item.getAdvanceBookingDays());
        map.put("cancellation_hours", item.getCancellationHours());
        map.put("instructions", item.getInstructions());
        map.put("active", item.isActive());
        map.put("updated_at", item.getUpdatedAt());
        return map;
    }

    private Map<String, Object> bookingView(AmenityBooking item) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", item.getId());
        map.put("booking_number", item.getBookingNumber());
        map.put("amenity_id", item.getAmenityId());
        amenities
                .findById(item.getAmenityId())
                .ifPresent(
                        amenity -> {
                            map.put("amenity_name", amenity.getName());
                            map.put("amenity_type", amenity.getAmenityType());
                            map.put("amenity_code", amenity.getAmenityCode());
                            map.put("amenity_location", amenity.getLocation());
                            map.put("approval_required", amenity.isBookingApprovalRequired());
                            map.put("cancellation_hours", amenity.getCancellationHours());
                        });
        map.put("booked_by", item.getBookedBy());
        users.findById(item.getBookedBy())
                .ifPresent(
                        user -> {
                            map.put("member_name", user.getFullName());
                            map.put("member_mobile", user.getMobile());
                        });
        map.put("starts_at", item.getStartsAt());
        map.put("ends_at", item.getEndsAt());
        map.put("attendees", item.getAttendees());
        map.put("purpose", item.getPurpose());
        map.put("amount", item.getAmount());
        map.put("base_charge", item.getBaseCharge());
        map.put("deposit_amount", item.getDepositAmount());
        map.put("status", item.getStatus());
        map.put("payment_status", item.getPaymentStatus());
        map.put("payment_method", item.getPaymentMethod());
        map.put("payment_reference", item.getPaymentReference());
        map.put("rejection_reason", item.getRejectionReason());
        map.put("checked_in_at", item.getCheckedInAt());
        map.put("checked_out_at", item.getCheckedOutAt());
        map.put("created_at", item.getCreatedAt());
        return map;
    }
}
