package com.societyapp.application.usecase;

import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.port.in.StorageMeterUseCase;
import com.societyapp.application.port.out.persistence.*;
import com.societyapp.domain.model.*;
import com.societyapp.domain.type.StorageSourceType;
import com.societyapp.domain.type.StorageStatus;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.*;

public class StorageMeterService implements StorageMeterUseCase {
    public static final long GB = 1024L * 1024L * 1024L;
    private final StoragePolicyRepository policies;
    private final SocietyStorageAccountRepository accounts;
    private final StorageObjectRepository objects;
    private final StorageAddonPurchaseRepository purchases;
    private final SocietyRepository societies;

    public StorageMeterService(
            StoragePolicyRepository policies,
            SocietyStorageAccountRepository accounts,
            StorageObjectRepository objects,
            StorageAddonPurchaseRepository purchases,
            SocietyRepository societies) {
        this.policies = policies;
        this.accounts = accounts;
        this.objects = objects;
        this.purchases = purchases;
        this.societies = societies;
    }

    public void register(
            UUID societyId,
            String storageKey,
            String category,
            String originalFilename,
            String contentType,
            long sizeBytes) {
        if (objects.findByStorageKey(storageKey).isPresent()) return;
        var policy = requirePolicy();
        var account = lockedAccount(societyId);
        long used = objects.usedBytes(societyId);
        long allowance = bytes(policy.getDefaultFreeGb()) + account.getPurchasedBytes();
        if (sizeBytes > allowance - used) {
            throw new IllegalStateException(
                    "Storage limit reached. Delete files or purchase more storage before uploading.");
        }
        var object = new StorageObject();
        object.setSocietyId(societyId);
        object.setStorageKey(storageKey);
        object.setCategory(category.toUpperCase(Locale.ROOT));
        object.setOriginalFilename(trim(originalFilename, 255));
        object.setContentType(trim(contentType, 100));
        object.setSizeBytes(sizeBytes);
        object.setSourceType(StorageSourceType.UPLOAD.code());
        object.setStatus(StorageStatus.ACTIVE.code());
        object.setCreatedAt(OffsetDateTime.now());
        objects.save(object);
    }

    public void attach(String storageKey, String sourceType, UUID sourceId, String displayName) {
        objects.findByStorageKey(storageKey)
                .ifPresent(
                        object -> {
                            object.setSourceType(sourceType);
                            object.setSourceId(sourceId);
                            object.setDisplayName(trim(displayName, 255));
                            objects.save(object);
                        });
    }

    public void registerExisting(
            UUID societyId,
            String storageKey,
            String category,
            String contentType,
            long sizeBytes) {
        if (!societies.existsById(societyId) || objects.findByStorageKey(storageKey).isPresent()) {
            return;
        }
        var object = new StorageObject();
        object.setSocietyId(societyId);
        object.setStorageKey(storageKey);
        object.setCategory(category.toUpperCase(Locale.ROOT));
        object.setContentType(trim(contentType, 100));
        object.setSizeBytes(sizeBytes);
        object.setSourceType(StorageSourceType.UPLOAD.code());
        object.setDisplayName("Existing " + category.toLowerCase(Locale.ROOT) + " file");
        object.setStatus(StorageStatus.ACTIVE.code());
        object.setCreatedAt(OffsetDateTime.now());
        objects.save(object);
    }

    public void markDeleted(StorageObject object, UUID actorId) {
        object.setStatus(StorageStatus.DELETED.code());
        object.setDeletedAt(OffsetDateTime.now());
        object.setDeletedBy(actorId);
        objects.save(object);
    }

    public StorageObject activeObject(UUID societyId, UUID objectId) {
        return objects.findByIdAndSocietyIdAndStatus(
                        objectId, societyId, StorageStatus.ACTIVE.code())
                .orElseThrow(() -> new ResourceNotFoundException("Stored file not found"));
    }

    public Map<String, Object> updatePolicy(
            UUID actorId, int defaultFreeGb, int purchaseBlockGb, BigDecimal price) {
        if (defaultFreeGb < 0 || purchaseBlockGb < 1 || price.signum() < 0) {
            throw new IllegalArgumentException("Storage policy values are invalid");
        }
        var policy = requirePolicy();
        policy.setDefaultFreeGb(defaultFreeGb);
        policy.setPurchaseBlockGb(purchaseBlockGb);
        policy.setPricePerBlockMonthly(price);
        policy.setUpdatedBy(actorId);
        policy.setUpdatedAt(OffsetDateTime.now());
        policies.save(policy);
        return policyView(policy);
    }

    public Map<String, Object> purchase(UUID societyId, UUID actorId, int blocks) {
        if (blocks < 1 || blocks > 100) {
            throw new IllegalArgumentException("Purchase must contain between 1 and 100 blocks");
        }
        societies
                .findById(societyId)
                .orElseThrow(() -> new ResourceNotFoundException("Society not found"));
        var policy = requirePolicy();
        var account = lockedAccount(societyId);
        long additional = Math.multiplyExact(bytes(policy.getPurchaseBlockGb()), blocks);
        var purchase = new StorageAddonPurchase();
        purchase.setSocietyId(societyId);
        purchase.setPurchasedBy(actorId);
        purchase.setBlocks(blocks);
        purchase.setBlockSizeGb(policy.getPurchaseBlockGb());
        purchase.setAdditionalBytes(additional);
        purchase.setPricePerBlockMonthly(policy.getPricePerBlockMonthly());
        purchase.setMonthlyAmount(
                policy.getPricePerBlockMonthly().multiply(BigDecimal.valueOf(blocks)));
        purchase.setStatus(StorageStatus.ACTIVE.code());
        purchase.setCreatedAt(OffsetDateTime.now());
        purchase = purchases.save(purchase);
        account.setPurchasedBytes(Math.addExact(account.getPurchasedBytes(), additional));
        account.setUpdatedAt(OffsetDateTime.now());
        accounts.save(account);
        return purchaseView(purchase);
    }

    public Map<String, Object> societyDashboard(UUID societyId) {
        var society =
                societies
                        .findById(societyId)
                        .orElseThrow(() -> new ResourceNotFoundException("Society not found"));
        var policy = requirePolicy();
        var account = accounts.findById(societyId).orElseGet(() -> emptyAccount(societyId));
        long used = objects.usedBytes(societyId);
        long free = bytes(policy.getDefaultFreeGb());
        long total = free + account.getPurchasedBytes();
        var result = new LinkedHashMap<String, Object>();
        result.put("society_id", societyId);
        result.put("society_name", society.getName());
        result.put("used_bytes", used);
        result.put("free_bytes", free);
        result.put("purchased_bytes", account.getPurchasedBytes());
        result.put("total_bytes", total);
        result.put("available_bytes", Math.max(0, total - used));
        result.put("usage_percent", total == 0 ? 100 : Math.min(100, used * 100.0 / total));
        result.put("policy", policyView(policy));
        result.put("monthly_addon_amount", monthlyAmount(societyId));
        result.put("usage_by_category", categoryUsage(societyId));
        result.put(
                "files",
                objects
                        .findBySocietyIdAndStatusOrderByCreatedAtDesc(
                                societyId, StorageStatus.ACTIVE.code())
                        .stream()
                        .map(this::objectView)
                        .toList());
        result.put(
                "purchases",
                purchases.findBySocietyIdOrderByCreatedAtDesc(societyId).stream()
                        .map(this::purchaseView)
                        .toList());
        return result;
    }

    public Map<String, Object> adminDashboard() {
        var result = new LinkedHashMap<String, Object>();
        result.put("policy", policyView(requirePolicy()));
        result.put(
                "societies",
                societies.findAll().stream()
                        .map(
                                society -> {
                                    var account =
                                            accounts.findById(society.getId())
                                                    .orElseGet(() -> emptyAccount(society.getId()));
                                    long used = objects.usedBytes(society.getId());
                                    var value = new LinkedHashMap<String, Object>();
                                    value.put("society_id", society.getId());
                                    value.put("society_name", society.getName());
                                    value.put("used_bytes", used);
                                    value.put("purchased_bytes", account.getPurchasedBytes());
                                    value.put(
                                            "monthly_addon_amount", monthlyAmount(society.getId()));
                                    return value;
                                })
                        .toList());
        return result;
    }

    public BigDecimal monthlyAmount(UUID societyId) {
        return purchases.findBySocietyIdAndStatus(societyId, StorageStatus.ACTIVE.code()).stream()
                .map(StorageAddonPurchase::getMonthlyAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private List<Map<String, Object>> categoryUsage(UUID societyId) {
        return objects.usageByCategory(societyId).stream()
                .map(
                        row ->
                                Map.<String, Object>of(
                                        "category",
                                        row[0],
                                        "used_bytes",
                                        ((Number) row[1]).longValue()))
                .toList();
    }

    private Map<String, Object> objectView(StorageObject object) {
        var value = new LinkedHashMap<String, Object>();
        value.put("id", object.getId());
        value.put("category", object.getCategory());
        value.put(
                "name",
                object.getDisplayName() != null
                        ? object.getDisplayName()
                        : object.getOriginalFilename());
        value.put("content_type", object.getContentType());
        value.put("size_bytes", object.getSizeBytes());
        value.put("source_type", object.getSourceType());
        value.put("created_at", object.getCreatedAt());
        value.put("cleanup_eligible", object.getSourceId() != null);
        return value;
    }

    private Map<String, Object> purchaseView(StorageAddonPurchase purchase) {
        var value = new LinkedHashMap<String, Object>();
        value.put("id", purchase.getId());
        value.put("blocks", purchase.getBlocks());
        value.put("block_size_gb", purchase.getBlockSizeGb());
        value.put("additional_bytes", purchase.getAdditionalBytes());
        value.put("monthly_amount", purchase.getMonthlyAmount());
        value.put("status", purchase.getStatus());
        value.put("created_at", purchase.getCreatedAt());
        return value;
    }

    private Map<String, Object> policyView(StoragePolicy policy) {
        return Map.of(
                "default_free_gb", policy.getDefaultFreeGb(),
                "purchase_block_gb", policy.getPurchaseBlockGb(),
                "price_per_block_monthly", policy.getPricePerBlockMonthly(),
                "updated_at", policy.getUpdatedAt());
    }

    private StoragePolicy requirePolicy() {
        return policies.findById((short) 1)
                .orElseThrow(() -> new IllegalStateException("Storage policy is not configured"));
    }

    private SocietyStorageAccount lockedAccount(UUID societyId) {
        return accounts.findForUpdate(societyId)
                .orElseGet(
                        () -> {
                            var account = emptyAccount(societyId);
                            return accounts.saveAndFlush(account);
                        });
    }

    private SocietyStorageAccount emptyAccount(UUID societyId) {
        var account = new SocietyStorageAccount();
        account.setSocietyId(societyId);
        account.setPurchasedBytes(0);
        account.setUpdatedAt(OffsetDateTime.now());
        return account;
    }

    private long bytes(int gigabytes) {
        return Math.multiplyExact((long) gigabytes, GB);
    }

    private String trim(String value, int length) {
        if (value == null || value.isBlank()) return null;
        return value.length() <= length ? value : value.substring(0, length);
    }
}
