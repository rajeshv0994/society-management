package com.societyapp.application.usecase;

import com.societyapp.application.exception.ConflictException;
import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.port.in.StructureUseCase;
import com.societyapp.application.port.out.persistence.*;
import com.societyapp.domain.model.*;
import com.societyapp.domain.type.FlatOccupancyStatus;
import com.societyapp.domain.type.LifecycleStatus;
import java.math.BigDecimal;
import java.util.*;

public class StructureService implements StructureUseCase {
    private final BlockRepository blocks;
    private final FloorRepository floors;
    private final FlatRepository flats;
    private final SocietyRepository societies;
    private final SubscriptionPlanRepository plans;
    private final SocietyCustomPlanRepository customPlans;

    public StructureService(
            BlockRepository blocks,
            FloorRepository floors,
            FlatRepository flats,
            SocietyRepository societies,
            SubscriptionPlanRepository plans,
            SocietyCustomPlanRepository customPlans) {
        this.blocks = blocks;
        this.floors = floors;
        this.flats = flats;
        this.societies = societies;
        this.plans = plans;
        this.customPlans = customPlans;
    }

    public Map<String, Object> get(UUID societyId) {
        var blockViews = new ArrayList<Map<String, Object>>();
        var floorViews = new ArrayList<Map<String, Object>>();
        var flatViews = new ArrayList<Map<String, Object>>();
        for (var block : blocks.findBySocietyIdOrderByName(societyId)) {
            var blockFloors = floors.findByBlockIdOrderByFloorNumber(block.getId());
            var blockFlats =
                    blockFloors.stream()
                            .flatMap(
                                    floor ->
                                            flats
                                                    .findByFloorIdOrderByFlatNumber(floor.getId())
                                                    .stream())
                            .toList();
            blockViews.add(
                    Map.of(
                            "id", block.getId(),
                            "name", block.getName(),
                            "section_count", blockFloors.size(),
                            "floor_count", blockFloors.size(),
                            "space_count", blockFlats.size(),
                            "unit_count", blockFlats.size(),
                            "flat_count", blockFlats.size(),
                            "occupied_count",
                                    blockFlats.stream()
                                            .filter(
                                                    flat ->
                                                            !FlatOccupancyStatus.VACANT.matches(
                                                                    flat.getOccupancyStatus()))
                                            .count()));
            for (var floor : blockFloors) {
                var floorFlats = flats.findByFloorIdOrderByFlatNumber(floor.getId());
                floorViews.add(
                        Map.of(
                                "id", floor.getId(),
                                "block_id", block.getId(),
                                "name", floor.getName(),
                                "section_order", floor.getFloorNumber(),
                                "floor_number", floor.getFloorNumber(),
                                "block", block.getName(),
                                "space_count", floorFlats.size(),
                                "unit_count", floorFlats.size(),
                                "flat_count", floorFlats.size()));
                for (var flat : floorFlats) {
                    var view = new LinkedHashMap<String, Object>();
                    view.put("id", flat.getId());
                    view.put("section_id", floor.getId());
                    view.put("floor_id", floor.getId());
                    view.put("block", block.getName());
                    view.put("section", floor.getName());
                    view.put("floor", floor.getName());
                    view.put("space_number", flat.getFlatNumber());
                    view.put("unit_number", flat.getFlatNumber());
                    view.put("flat_number", flat.getFlatNumber());
                    view.put("occupancy_status", flat.getOccupancyStatus());
                    view.put("area_sqft", flat.getAreaSqft());
                    flatViews.add(view);
                }
            }
        }
        return Map.of(
                "blocks", blockViews,
                "sections", floorViews,
                "floors", floorViews,
                "spaces", flatViews,
                "units", flatViews,
                "flats", flatViews);
    }

    public Map<String, Object> addBlock(UUID societyId, String name) {
        var block = new Block();
        block.setSocietyId(societyId);
        block.setName(name);
        return Map.of("id", blocks.save(block).getId());
    }

    public Map<String, Object> updateBlock(UUID societyId, UUID blockId, String name) {
        var block = requireBlock(societyId, blockId);
        block.setName(name.trim());
        blocks.save(block);
        return Map.of("id", blockId, "name", block.getName());
    }

    public Map<String, Object> deleteBlock(UUID societyId, UUID blockId) {
        var block = requireBlock(societyId, blockId);
        if (!floors.findByBlockIdOrderByFloorNumber(blockId).isEmpty()) {
            throw new ConflictException("Remove all sections before deleting this group");
        }
        blocks.delete(block);
        return Map.of("id", blockId, "deleted", true);
    }

    public Map<String, Object> addFloor(
            UUID societyId, UUID blockId, String name, int floorNumber) {
        if (!blocks.existsByIdAndSocietyId(blockId, societyId)) {
            throw new ResourceNotFoundException("Block not found");
        }
        var floor = new Floor();
        floor.setBlockId(blockId);
        floor.setName(name);
        floor.setFloorNumber(floorNumber);
        return Map.of("id", floors.save(floor).getId());
    }

    public Map<String, Object> updateFloor(
            UUID societyId, UUID floorId, String name, int floorNumber) {
        var floor = requireFloor(societyId, floorId);
        floor.setName(name.trim());
        floor.setFloorNumber(floorNumber);
        floors.save(floor);
        return Map.of(
                "id", floorId,
                "name", floor.getName(),
                "sectionOrder", floorNumber,
                "floorNumber", floorNumber);
    }

    public Map<String, Object> deleteFloor(UUID societyId, UUID floorId) {
        var floor = requireFloor(societyId, floorId);
        if (!flats.findByFloorIdOrderByFlatNumber(floorId).isEmpty()) {
            throw new ConflictException("Remove all spaces before deleting this section");
        }
        floors.delete(floor);
        return Map.of("id", floorId, "deleted", true);
    }

    public Map<String, Object> addFlat(
            UUID societyId, UUID floorId, String flatNumber, BigDecimal areaSqft) {
        var floor = requireFloor(societyId, floorId);
        ensurePlanCapacity(societyId);
        var flat = new Flat();
        flat.setFloorId(floor.getId());
        flat.setFlatNumber(flatNumber.trim());
        flat.setOccupancyStatus(FlatOccupancyStatus.VACANT.code());
        flat.setAreaSqft(areaSqft);
        return Map.of("id", flats.save(flat).getId());
    }

    public Map<String, Object> addSpace(UUID societyId, String spaceNumber, BigDecimal areaSqft) {
        var block =
                blocks.findBySocietyIdOrderByName(societyId).stream()
                        .findFirst()
                        .orElseGet(
                                () -> {
                                    var created = new Block();
                                    created.setSocietyId(societyId);
                                    created.setName("General");
                                    return blocks.save(created);
                                });
        var section =
                floors.findByBlockIdOrderByFloorNumber(block.getId()).stream()
                        .findFirst()
                        .orElseGet(
                                () -> {
                                    var created = new Floor();
                                    created.setBlockId(block.getId());
                                    created.setName("General");
                                    created.setFloorNumber(0);
                                    return floors.save(created);
                                });
        return addFlat(societyId, section.getId(), spaceNumber, areaSqft);
    }

    public Map<String, Object> updateFlat(
            UUID societyId, UUID flatId, String flatNumber, BigDecimal areaSqft) {
        var flat = requireFlat(societyId, flatId);
        flat.setFlatNumber(flatNumber.trim());
        flat.setAreaSqft(areaSqft);
        flats.save(flat);
        return Map.of(
                "id", flatId,
                "spaceNumber", flat.getFlatNumber(),
                "unitNumber", flat.getFlatNumber(),
                "flatNumber", flat.getFlatNumber());
    }

    public Map<String, Object> deleteFlat(UUID societyId, UUID flatId) {
        var flat = requireFlat(societyId, flatId);
        if (!FlatOccupancyStatus.VACANT.matches(flat.getOccupancyStatus())
                || flat.getActiveOwnerId() != null
                || flat.getActiveTenantId() != null) {
            throw new ConflictException("Only vacant, unassigned spaces can be deleted");
        }
        flats.delete(flat);
        return Map.of("id", flatId, "deleted", true);
    }

    private Block requireBlock(UUID societyId, UUID blockId) {
        return blocks.findById(blockId)
                .filter(block -> societyId.equals(block.getSocietyId()))
                .orElseThrow(() -> new ResourceNotFoundException("Block not found"));
    }

    private Floor requireFloor(UUID societyId, UUID floorId) {
        return floors.findById(floorId)
                .filter(floor -> blocks.existsByIdAndSocietyId(floor.getBlockId(), societyId))
                .orElseThrow(() -> new ResourceNotFoundException("Section not found"));
    }

    private Flat requireFlat(UUID societyId, UUID flatId) {
        return flats.findById(flatId)
                .filter(
                        flat ->
                                floors.findById(flat.getFloorId())
                                        .filter(
                                                floor ->
                                                        blocks.existsByIdAndSocietyId(
                                                                floor.getBlockId(), societyId))
                                        .isPresent())
                .orElseThrow(() -> new ResourceNotFoundException("Space not found"));
    }

    private void ensurePlanCapacity(UUID societyId) {
        var society =
                societies
                        .findById(societyId)
                        .orElseThrow(() -> new ResourceNotFoundException("Society not found"));
        Integer maximum =
                plans.findById(society.getPlanCode())
                        .map(SubscriptionPlan::getMaxFlats)
                        .orElse(null);
        var customMaximum =
                customPlans.findAllByOrderByCreatedAtDesc().stream()
                        .filter(plan -> societyId.equals(plan.getSocietyId()))
                        .filter(plan -> LifecycleStatus.ACTIVE.matches(plan.getStatus()))
                        .map(SocietyCustomPlan::getMaxFlats)
                        .findFirst()
                        .orElse(null);
        if (customMaximum != null) maximum = customMaximum;
        int purchasedSpaces = society.getTotalFlats();
        int allowed = maximum == null ? purchasedSpaces : Math.min(purchasedSpaces, maximum);
        long configuredSpaces =
                blocks.findBySocietyIdOrderByName(societyId).stream()
                        .flatMap(
                                block ->
                                        floors
                                                .findByBlockIdOrderByFloorNumber(block.getId())
                                                .stream())
                        .mapToLong(
                                section ->
                                        flats.findByFloorIdOrderByFlatNumber(section.getId())
                                                .size())
                        .sum();
        if (configuredSpaces >= allowed) {
            throw new ConflictException(
                    "Your subscription includes "
                            + allowed
                            + " spaces. Increase the selected space quantity first.");
        }
    }
}
