package com.societyapp.application.usecase;

import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.port.in.SupportUseCase;
import com.societyapp.application.port.out.persistence.*;
import com.societyapp.domain.model.*;
import com.societyapp.domain.type.MessageType;
import com.societyapp.domain.type.SupportPriority;
import com.societyapp.domain.type.SupportTicketStatus;
import com.societyapp.domain.type.UserRole;
import java.time.OffsetDateTime;
import java.util.*;

public class SupportService implements SupportUseCase {
    private final SupportTicketRepository tickets;
    private final SupportTicketMessageRepository messages;
    private final UserAccountJpaRepository users;

    public SupportService(
            SupportTicketRepository tickets,
            SupportTicketMessageRepository messages,
            UserAccountJpaRepository users) {
        this.tickets = tickets;
        this.messages = messages;
        this.users = users;
    }

    public List<Map<String, Object>> tickets(UUID societyId) {
        if (societyId == null) throw new IllegalArgumentException("A society account is required");
        return tickets.findBySocietyIdOrderByCreatedAtDesc(societyId).stream()
                .map(this::ticketView)
                .toList();
    }

    public Map<String, Object> create(
            UUID societyId, UUID userId, String subject, String description, String priority) {
        if (societyId == null) throw new IllegalArgumentException("A society account is required");
        var now = OffsetDateTime.now();
        var ticket = new SupportTicket();
        ticket.setSocietyId(societyId);
        ticket.setCreatedBy(userId);
        ticket.setSubject(subject);
        ticket.setDescription(description);
        ticket.setPriority(SupportPriority.from(priority).code());
        ticket.setStatus(SupportTicketStatus.OPEN.code());
        ticket.setCreatedAt(now);
        ticket.setUpdatedAt(now);
        ticket = tickets.save(ticket);
        saveMessage(ticket.getId(), userId, description);
        return Map.of("ticketId", ticket.getId(), "status", SupportTicketStatus.OPEN.code());
    }

    public List<Map<String, Object>> messages(
            UUID ticketId, UUID societyId, UUID userId, String role) {
        authorize(ticketId, societyId, role);
        var result = messages.findByTicketIdOrderByCreatedAt(ticketId);
        result.stream()
                .filter(message -> !message.getSenderId().equals(userId))
                .filter(message -> message.getReadAt() == null)
                .forEach(message -> message.setReadAt(OffsetDateTime.now()));
        messages.saveAll(result);
        return result.stream().map(this::messageView).toList();
    }

    public Map<String, Object> send(
            UUID ticketId, UUID societyId, UUID userId, String role, String text) {
        var ticket = authorize(ticketId, societyId, role);
        var message = saveMessage(ticketId, userId, text);
        if (SupportTicketStatus.OPEN.matches(ticket.getStatus())) {
            ticket.setStatus(SupportTicketStatus.IN_PROGRESS.code());
        }
        if (UserRole.SUPER_ADMIN.matches(role)) ticket.setAssignedTo(userId);
        ticket.setUpdatedAt(OffsetDateTime.now());
        tickets.save(ticket);
        return Map.of("messageId", message.getId(), "created", true);
    }

    private SupportTicket authorize(UUID ticketId, UUID societyId, String role) {
        return tickets.findById(ticketId)
                .filter(
                        ticket ->
                                UserRole.SUPER_ADMIN.matches(role)
                                        || Objects.equals(ticket.getSocietyId(), societyId))
                .orElseThrow(() -> new ResourceNotFoundException("Support ticket not found"));
    }

    private SupportTicketMessage saveMessage(UUID ticketId, UUID senderId, String text) {
        var message = new SupportTicketMessage();
        message.setTicketId(ticketId);
        message.setSenderId(senderId);
        message.setMessage(text);
        message.setMessageType(MessageType.TEXT.code());
        message.setCreatedAt(OffsetDateTime.now());
        return messages.save(message);
    }

    private Map<String, Object> ticketView(SupportTicket ticket) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", ticket.getId());
        map.put("society_id", ticket.getSocietyId());
        map.put("created_by", ticket.getCreatedBy());
        map.put("subject", ticket.getSubject());
        map.put("description", ticket.getDescription());
        map.put("priority", ticket.getPriority());
        map.put("status", ticket.getStatus());
        map.put("assigned_to", ticket.getAssignedTo());
        map.put("resolution", ticket.getResolution());
        map.put("created_at", ticket.getCreatedAt());
        map.put("updated_at", ticket.getUpdatedAt());
        map.put("closed_at", ticket.getClosedAt());
        map.put(
                "created_by_name",
                ticket.getCreatedBy() == null
                        ? null
                        : users.findById(ticket.getCreatedBy())
                                .map(user -> user.getFullName())
                                .orElse(null));
        map.put("message_count", messages.findByTicketIdOrderByCreatedAt(ticket.getId()).size());
        return map;
    }

    private Map<String, Object> messageView(SupportTicketMessage message) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", message.getId());
        map.put("message", message.getMessage());
        map.put("message_type", message.getMessageType());
        map.put("attachment_key", message.getAttachmentKey());
        map.put("created_at", message.getCreatedAt());
        map.put("read_at", message.getReadAt());
        map.put("sender_id", message.getSenderId());
        users.findById(message.getSenderId())
                .ifPresent(
                        user -> {
                            map.put("sender_name", user.getFullName());
                            map.put("sender_role", user.getRole());
                        });
        return map;
    }
}
