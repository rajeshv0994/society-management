package com.societyapp.application.usecase;

import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.mapper.ApiViewMapper;
import com.societyapp.application.policy.ServiceCatalogPolicy;
import com.societyapp.application.port.in.SocietyOnboardingUseCase;
import com.societyapp.application.port.out.PasswordCodec;
import com.societyapp.application.port.out.persistence.*;
import com.societyapp.domain.model.*;
import com.societyapp.domain.type.AccountStatus;
import com.societyapp.domain.type.ApprovalMode;
import com.societyapp.domain.type.SetupCodeStatus;
import com.societyapp.domain.type.SocietyStatus;
import com.societyapp.domain.type.SubscriptionPlanCode;
import com.societyapp.domain.type.SubscriptionStatus;
import com.societyapp.domain.type.TrialDurationUnit;
import com.societyapp.domain.type.UserRole;
import java.math.BigDecimal;
import java.security.SecureRandom;
import java.time.*;
import java.util.*;

public class SocietyOnboardingService implements SocietyOnboardingUseCase {
    private final SocietyRepository societies;
    private final SubscriptionPlanRepository plans;
    private final SetupCodeRepository setupCodes;
    private final PlatformServiceModuleRepository serviceModules;
    private final UserAccountJpaRepository users;
    private final PasswordCodec passwords;
    private final ApiViewMapper views;
    private final ServiceCatalogPolicy serviceCatalog;
    private final SecureRandom random = new SecureRandom();

    public SocietyOnboardingService(
            SocietyRepository societies,
            SubscriptionPlanRepository plans,
            SetupCodeRepository setupCodes,
            PlatformServiceModuleRepository serviceModules,
            UserAccountJpaRepository users,
            PasswordCodec passwords,
            ApiViewMapper views,
            ServiceCatalogPolicy serviceCatalog) {
        this.societies = societies;
        this.plans = plans;
        this.setupCodes = setupCodes;
        this.serviceModules = serviceModules;
        this.users = users;
        this.passwords = passwords;
        this.views = views;
        this.serviceCatalog = serviceCatalog;
    }

    public List<Map<String, Object>> plans() {
        return plans.findAll().stream()
                .filter(
                        plan ->
                                SubscriptionPlanCode.TRIAL.matches(plan.getCode())
                                        || SubscriptionPlanCode.STANDARD.matches(plan.getCode()))
                .sorted(Comparator.comparing(SubscriptionPlan::getPricePerSpace))
                .map(views::toMap)
                .toList();
    }

    public List<Map<String, Object>> services() {
        return serviceModules.findAllByOrderBySortOrderAscNameAsc().stream()
                .map(views::toMap)
                .toList();
    }

    public List<Map<String, Object>> activeSocieties() {
        return societies.findByStatusOrderByCreatedAtDesc(SocietyStatus.ACTIVE.code()).stream()
                .sorted(Comparator.comparing(Society::getName))
                .map(
                        society ->
                                Map.<String, Object>of(
                                        "id", society.getId(),
                                        "name", society.getName(),
                                        "society_code", society.getSocietyCode(),
                                        "city", society.getCity(),
                                        "state", society.getState()))
                .toList();
    }

    public Map<String, Object> register(Registration command) {
        var enabledModules = serviceCatalog.normalizeSelection(command.enabledModules());
        var plan =
                plans.findById(command.planCode().toUpperCase())
                        .orElseThrow(() -> new IllegalArgumentException("Unknown plan"));
        if (plan.getMaxFlats() != null && command.totalFlats() > plan.getMaxFlats()) {
            throw new IllegalArgumentException(
                    "This plan supports at most " + plan.getMaxFlats() + " spaces");
        }
        if (plan.getMaxStaff() != null && command.plannedStaff() > plan.getMaxStaff()) {
            throw new IllegalArgumentException(
                    "This plan supports at most " + plan.getMaxStaff() + " staff members");
        }
        var status =
                ApprovalMode.AUTO.matches(plan.getApprovalMode())
                        ? SocietyStatus.APPROVED
                        : SocietyStatus.PENDING_VERIFICATION;
        String accessToken = randomPart(32);
        var now = OffsetDateTime.now();
        var society = new Society();
        society.setName(command.name());
        society.setRegistrationNumber(generateRegistrationNumber());
        society.setSocietyCode(generateSocietyCode(command.name()));
        society.setSocietyType(command.societyType());
        society.setTotalBlocks(command.totalBlocks());
        society.setTotalFlats(command.totalFlats());
        society.setPlannedStaff(command.plannedStaff());
        society.setApproximateResidents(command.approximateResidents());
        society.setAddress(command.address());
        society.setCity(command.city());
        society.setState(command.state());
        society.setPinCode(command.pinCode());
        society.setContactPerson(command.contactPerson());
        society.setEmail(command.email());
        society.setMobile(command.mobile());
        society.setPlanCode(plan.getCode());
        society.setEnabledModules(serviceCatalog.writeSelection(enabledModules));
        society.setStatus(status.code());
        society.setApprovedAt(status == SocietyStatus.APPROVED ? now : null);
        society.setRegistrationAccessHash(passwords.encode(accessToken));
        society.setSubscriptionStatus(SubscriptionStatus.PENDING.code());
        society.setSetupCompleted(false);
        society.setCreatedAt(now);
        society.setUpdatedAt(now);
        society = societies.save(society);
        var result = new LinkedHashMap<String, Object>();
        result.put("societyId", society.getId());
        result.put("registrationAccessToken", accessToken);
        result.put("status", status.code());
        result.put("registrationNumber", society.getRegistrationNumber());
        result.put("societyCode", society.getSocietyCode());
        result.put("enabledModules", enabledModules);
        result.put("spaceCount", command.totalFlats());
        result.put("staffCount", command.plannedStaff());
        var spacePrice = plan.getPricePerSpace().multiply(BigDecimal.valueOf(command.totalFlats()));
        var staffPrice =
                plan.getPricePerStaff().multiply(BigDecimal.valueOf(command.plannedStaff()));
        var servicePricing = serviceCatalog.servicePricing(society);
        result.put(
                "estimatedMonthlyPrice",
                spacePrice.add(staffPrice).add(servicePricing.monthlyAmount()));
        result.put("baseMonthlyPrice", spacePrice.add(staffPrice));
        result.put("serviceMonthlyPrice", servicePricing.monthlyAmount());
        result.put("servicePricing", servicePricing.lines());
        result.put("pricePerSpace", plan.getPricePerSpace());
        result.put("pricePerStaff", plan.getPricePerStaff());
        if (SubscriptionPlanCode.TRIAL.matches(plan.getCode())) {
            result.put("trialDurationValue", plan.getTrialDurationValue());
            result.put("trialDurationUnit", plan.getTrialDurationUnit());
        }
        if (status == SocietyStatus.APPROVED) result.putAll(generateCode(society.getId()));
        return result;
    }

    public List<Map<String, Object>> pending() {
        return societies
                .findByStatusOrderByCreatedAtDesc(SocietyStatus.PENDING_VERIFICATION.code())
                .stream()
                .map(views::toMap)
                .toList();
    }

    public Map<String, Object> approve(UUID societyId) {
        var society =
                societies
                        .findById(societyId)
                        .filter(
                                item ->
                                        SocietyStatus.PENDING_VERIFICATION.matches(
                                                item.getStatus()))
                        .orElseThrow(() -> new IllegalStateException("Society is not pending"));
        society.setStatus(SocietyStatus.APPROVED.code());
        society.setApprovedAt(OffsetDateTime.now());
        society.setUpdatedAt(OffsetDateTime.now());
        societies.save(society);
        return generateCode(societyId);
    }

    public Map<String, Object> reject(UUID societyId, String reason) {
        if (reason == null || reason.isBlank()) {
            throw new IllegalArgumentException("Rejection reason is required");
        }
        var society =
                societies
                        .findById(societyId)
                        .filter(
                                item ->
                                        SocietyStatus.PENDING_VERIFICATION.matches(
                                                item.getStatus()))
                        .orElseThrow(() -> new IllegalStateException("Society is not pending"));
        society.setStatus(SocietyStatus.REJECTED.code());
        society.setRejectionReason(reason);
        society.setUpdatedAt(OffsetDateTime.now());
        societies.save(society);
        return Map.of(
                "societyId", societyId, "status", SocietyStatus.REJECTED.code(), "reason", reason);
    }

    public Map<String, Object> activate(
            String setupCode, String fullName, String email, String password, String mobile) {
        var code =
                setupCodes.findByStatusOrderByCreatedAtDesc(SetupCodeStatus.ACTIVE.code()).stream()
                        .filter(item -> item.getCodeHint().equals(hint(setupCode)))
                        .filter(item -> passwords.matches(setupCode, item.getCodeHash()))
                        .findFirst()
                        .orElseThrow(() -> new IllegalArgumentException("Invalid setup code"));
        if (code.getExpiresAt().isBefore(OffsetDateTime.now())
                || code.getActivationCount() >= code.getMaxActivations()) {
            throw new IllegalStateException("Setup code expired or already used");
        }
        var society =
                societies
                        .findById(code.getSocietyId())
                        .orElseThrow(() -> new ResourceNotFoundException("Society not found"));
        var user = new UserAccount();
        user.setSocietyId(society.getId());
        user.setFullName(fullName);
        user.setEmail(email);
        user.setMobile(mobile);
        user.setPasswordHash(passwords.encode(password));
        user.setRole(UserRole.SOCIETY_ADMIN.code());
        user.setStatus(AccountStatus.ACTIVE.code());
        user.setEmailVerified(true);
        user.setMobileVerified(true);
        user.setCreatedAt(OffsetDateTime.now());
        user = users.save(user);
        code.setActivationCount(code.getActivationCount() + 1);
        if (code.getActivationCount() >= code.getMaxActivations()) {
            code.setStatus(SetupCodeStatus.USED.code());
        }
        setupCodes.save(code);
        society.setStatus(SocietyStatus.ACTIVE.code());
        var plan =
                plans.findById(society.getPlanCode())
                        .orElseThrow(() -> new ResourceNotFoundException("Plan not found"));
        var subscriptionStartedAt = OffsetDateTime.now();
        society.setSubscriptionStartedAt(subscriptionStartedAt);
        if (SubscriptionPlanCode.TRIAL.matches(plan.getCode())) {
            society.setSubscriptionStatus(SubscriptionStatus.TRIAL.code());
            society.setSubscriptionExpiresAt(
                    TrialDurationUnit.DAYS.matches(plan.getTrialDurationUnit())
                            ? subscriptionStartedAt.plusDays(plan.getTrialDurationValue())
                            : subscriptionStartedAt.plusMonths(plan.getTrialDurationValue()));
        } else {
            society.setSubscriptionStatus(SubscriptionStatus.PENDING_PAYMENT.code());
            society.setSubscriptionExpiresAt(null);
        }
        society.setUpdatedAt(OffsetDateTime.now());
        societies.save(society);
        return Map.of(
                "societyId",
                society.getId(),
                "adminUserId",
                user.getId(),
                "status",
                SocietyStatus.ACTIVE.code());
    }

    private Map<String, Object> generateCode(UUID societyId) {
        String raw =
                "SOC-"
                        + Year.now().getValue()
                        + "-"
                        + randomPart(4)
                        + "-"
                        + (1000 + random.nextInt(9000));
        var expiresAt = OffsetDateTime.now().plusDays(7);
        var code = new SetupCode();
        code.setSocietyId(societyId);
        code.setCodeHash(passwords.encode(raw));
        code.setCodeHint(hint(raw));
        code.setExpiresAt(expiresAt);
        code.setMaxActivations(1);
        code.setActivationCount(0);
        code.setStatus(SetupCodeStatus.ACTIVE.code());
        code.setCreatedAt(OffsetDateTime.now());
        setupCodes.save(code);
        return Map.of("setupCode", raw, "expiresAt", expiresAt);
    }

    private String randomPart(int size) {
        String chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        var value = new StringBuilder();
        for (int i = 0; i < size; i++) {
            value.append(chars.charAt(random.nextInt(chars.length())));
        }
        return value.toString();
    }

    private String hint(String value) {
        return value.length() < 4 ? value : value.substring(value.length() - 4);
    }

    private String generateSocietyCode(String name) {
        String base =
                name.toUpperCase(Locale.ROOT)
                        .replaceAll("[^A-Z0-9]+", "-")
                        .replaceAll("(^-|-$)", "");
        if (base.isBlank()) base = "SOCIETY";
        if (base.length() > 20) base = base.substring(0, 20);
        String candidate = base;
        while (societies.existsBySocietyCodeIgnoreCase(candidate)) {
            candidate = base + "-" + randomPart(4);
        }
        return candidate;
    }

    private String generateRegistrationNumber() {
        String candidate;
        do {
            candidate = "REG-" + Year.now().getValue() + "-" + randomPart(6);
        } while (societies.existsByRegistrationNumberIgnoreCase(candidate));
        return candidate;
    }
}
