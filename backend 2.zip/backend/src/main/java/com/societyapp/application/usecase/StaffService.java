package com.societyapp.application.usecase;

import com.societyapp.application.exception.ConflictException;
import com.societyapp.application.policy.StaffPermissionCatalog;
import com.societyapp.application.port.in.StaffUseCase;
import com.societyapp.application.port.out.PasswordCodec;
import com.societyapp.application.port.out.persistence.*;
import com.societyapp.domain.model.*;
import com.societyapp.domain.type.AccountStatus;
import com.societyapp.domain.type.AttendanceStatus;
import com.societyapp.domain.type.LifecycleStatus;
import com.societyapp.domain.type.PaymentMethod;
import com.societyapp.domain.type.UserRole;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;

public class StaffService implements StaffUseCase {
    private final UserAccountJpaRepository users;
    private final StaffProfileRepository profiles;
    private final StaffPermissionRepository permissions;
    private final PasswordCodec passwords;
    private final SocietyRepository societies;
    private final SubscriptionPlanRepository plans;
    private final SocietyCustomPlanRepository customPlans;
    private final StaffAttendanceRepository attendance;
    private final StaffSalaryPaymentRepository salaryPayments;
    private final StaffTaskRepository tasks;

    public StaffService(
            UserAccountJpaRepository users,
            StaffProfileRepository profiles,
            StaffPermissionRepository permissions,
            PasswordCodec passwords,
            SocietyRepository societies,
            SubscriptionPlanRepository plans,
            SocietyCustomPlanRepository customPlans,
            StaffAttendanceRepository attendance,
            StaffSalaryPaymentRepository salaryPayments,
            StaffTaskRepository tasks) {
        this.users = users;
        this.profiles = profiles;
        this.permissions = permissions;
        this.passwords = passwords;
        this.societies = societies;
        this.plans = plans;
        this.customPlans = customPlans;
        this.attendance = attendance;
        this.salaryPayments = salaryPayments;
        this.tasks = tasks;
    }

    public List<Map<String, Object>> list(UUID societyId) {
        return users
                .findBySocietyIdAndRoleOrderByFullName(societyId, UserRole.STAFF.code())
                .stream()
                .map(this::view)
                .toList();
    }

    public Map<String, Object> detail(UUID societyId, UUID staffId) {
        var user = requireStaff(societyId, staffId);
        var result = new LinkedHashMap<String, Object>(view(user));
        var attendanceRows =
                attendance.findByStaffUserIdOrderByAttendanceDateDesc(staffId).stream()
                        .map(this::attendanceView)
                        .toList();
        var taskRows =
                tasks.findBySocietyIdOrderByCreatedAtDesc(societyId).stream()
                        .filter(task -> staffId.equals(task.getAssignedTo()))
                        .map(
                                task -> {
                                    var row = new LinkedHashMap<String, Object>();
                                    row.put("id", task.getId());
                                    row.put("title", task.getTitle());
                                    row.put("description", task.getDescription());
                                    row.put("priority", task.getPriority());
                                    row.put("status", task.getStatus());
                                    row.put("due_at", task.getDueAt());
                                    row.put("completion_note", task.getCompletionNote());
                                    row.put("completed_at", task.getCompletedAt());
                                    row.put("created_at", task.getCreatedAt());
                                    return (Map<String, Object>) row;
                                })
                        .toList();
        var salaryRows =
                salaryPayments.findByStaffUserIdOrderBySalaryMonthDesc(staffId).stream()
                        .map(this::salaryView)
                        .toList();
        result.put("attendance", attendanceRows);
        result.put("tasks", taskRows);
        result.put("salary_payments", salaryRows);
        result.put(
                "attendance_summary",
                Map.of(
                        "present",
                        attendanceRows.stream()
                                .filter(
                                        row ->
                                                AttendanceStatus.PRESENT.matches(
                                                        String.valueOf(row.get("status"))))
                                .count(),
                        "absent",
                        attendanceRows.stream()
                                .filter(
                                        row ->
                                                AttendanceStatus.ABSENT.matches(
                                                        String.valueOf(row.get("status"))))
                                .count(),
                        "half_day",
                        attendanceRows.stream()
                                .filter(
                                        row ->
                                                AttendanceStatus.HALF_DAY.matches(
                                                        String.valueOf(row.get("status"))))
                                .count(),
                        "leave",
                        attendanceRows.stream()
                                .filter(
                                        row ->
                                                AttendanceStatus.LEAVE.matches(
                                                        String.valueOf(row.get("status"))))
                                .count()));
        return result;
    }

    public Map<String, Object> updateEmployment(
            UUID societyId,
            UUID staffId,
            LocalDate joinedOn,
            LocalDate dateOfBirth,
            String gender,
            String alternateMobile,
            String address,
            String emergencyName,
            String emergencyMobile,
            String idType,
            String idNumber,
            BigDecimal monthlySalary,
            String bankAccountName,
            String bankAccountNumber,
            String bankIfsc,
            String upiId) {
        requireStaff(societyId, staffId);
        var profile = profiles.findById(staffId).orElseThrow();
        profile.setJoinedOn(joinedOn);
        profile.setDateOfBirth(dateOfBirth);
        profile.setGender(gender);
        profile.setAlternateMobile(alternateMobile);
        profile.setAddress(address);
        profile.setEmergencyContactName(emergencyName);
        profile.setEmergencyContactMobile(emergencyMobile);
        profile.setIdType(idType);
        profile.setIdNumber(idNumber);
        profile.setMonthlySalary(monthlySalary);
        profile.setBankAccountName(bankAccountName);
        profile.setBankAccountNumber(bankAccountNumber);
        profile.setBankIfsc(bankIfsc);
        profile.setUpiId(upiId);
        profiles.save(profile);
        return Map.of("id", staffId, "updated", true);
    }

    public Map<String, Object> markAttendance(
            UUID societyId,
            UUID markerId,
            UUID staffId,
            LocalDate date,
            String status,
            LocalTime checkIn,
            LocalTime checkOut,
            String note) {
        requireStaff(societyId, staffId);
        if (checkIn != null && checkOut != null && checkOut.isBefore(checkIn)) {
            throw new IllegalArgumentException("Check-out cannot be before check-in");
        }
        var row =
                attendance
                        .findByStaffUserIdAndAttendanceDate(staffId, date)
                        .orElseGet(StaffAttendance::new);
        if (row.getId() == null) {
            row.setSocietyId(societyId);
            row.setStaffUserId(staffId);
            row.setAttendanceDate(date);
            row.setCreatedAt(OffsetDateTime.now());
        }
        row.setStatus(AttendanceStatus.from(status).code());
        row.setCheckIn(checkIn);
        row.setCheckOut(checkOut);
        row.setNote(note);
        row.setMarkedBy(markerId);
        row.setUpdatedAt(OffsetDateTime.now());
        row = attendance.save(row);
        return Map.of("id", row.getId(), "status", row.getStatus());
    }

    public Map<String, Object> ownAttendance(UUID societyId, UUID staffId) {
        requireStaff(societyId, staffId);
        var rows = attendance.findByStaffUserIdOrderByAttendanceDateDesc(staffId);
        var result = new LinkedHashMap<String, Object>();
        result.put(
                "today",
                rows.stream()
                        .filter(row -> row.getAttendanceDate().equals(LocalDate.now()))
                        .findFirst()
                        .map(this::attendanceView)
                        .orElse(null));
        result.put("history", rows.stream().map(this::attendanceView).toList());
        result.put(
                "summary",
                Map.of(
                        "present",
                                rows.stream()
                                        .filter(
                                                row ->
                                                        AttendanceStatus.PRESENT.matches(
                                                                row.getStatus()))
                                        .count(),
                        "absent",
                                rows.stream()
                                        .filter(
                                                row ->
                                                        AttendanceStatus.ABSENT.matches(
                                                                row.getStatus()))
                                        .count(),
                        "half_day",
                                rows.stream()
                                        .filter(
                                                row ->
                                                        AttendanceStatus.HALF_DAY.matches(
                                                                row.getStatus()))
                                        .count(),
                        "leave",
                                rows.stream()
                                        .filter(
                                                row ->
                                                        AttendanceStatus.LEAVE.matches(
                                                                row.getStatus()))
                                        .count()));
        return result;
    }

    public Map<String, Object> clockIn(UUID societyId, UUID staffId) {
        requireStaff(societyId, staffId);
        LocalDate today = LocalDate.now();
        var row =
                attendance
                        .findByStaffUserIdAndAttendanceDate(staffId, today)
                        .orElseGet(StaffAttendance::new);
        if (row.getId() != null && row.getCheckIn() != null) {
            throw new ConflictException("You are already checked in today");
        }
        if (row.getId() != null && row.getCheckIn() == null && !staffId.equals(row.getMarkedBy())) {
            throw new ConflictException(
                    "Today's attendance was marked by the society admin; contact the admin for a correction");
        }
        if (row.getId() == null) {
            row.setSocietyId(societyId);
            row.setStaffUserId(staffId);
            row.setAttendanceDate(today);
            row.setCreatedAt(OffsetDateTime.now());
        }
        row.setStatus(AttendanceStatus.PRESENT.code());
        row.setCheckIn(LocalTime.now().withSecond(0).withNano(0));
        row.setCheckOut(null);
        row.setMarkedBy(staffId);
        row.setUpdatedAt(OffsetDateTime.now());
        row = attendance.save(row);
        return attendanceView(row);
    }

    public Map<String, Object> clockOut(UUID societyId, UUID staffId) {
        requireStaff(societyId, staffId);
        var row =
                attendance
                        .findByStaffUserIdAndAttendanceDate(staffId, LocalDate.now())
                        .orElseThrow(
                                () -> new IllegalStateException("Check in before checking out"));
        if (row.getCheckIn() == null)
            throw new IllegalStateException("Check in before checking out");
        if (row.getCheckOut() != null)
            throw new ConflictException("You are already checked out today");
        var checkOut = LocalTime.now().withSecond(0).withNano(0);
        if (checkOut.isBefore(row.getCheckIn())) {
            throw new IllegalStateException("Check-out cannot be before check-in");
        }
        row.setCheckOut(checkOut);
        row.setMarkedBy(staffId);
        row.setUpdatedAt(OffsetDateTime.now());
        row = attendance.save(row);
        return attendanceView(row);
    }

    public Map<String, Object> recordSalaryPayment(
            UUID societyId,
            UUID recorderId,
            UUID staffId,
            LocalDate salaryMonth,
            BigDecimal amount,
            LocalDate paidOn,
            String method,
            String reference,
            String note) {
        requireStaff(societyId, staffId);
        salaryMonth = salaryMonth.withDayOfMonth(1);
        if (salaryPayments.existsByStaffUserIdAndSalaryMonth(staffId, salaryMonth)) {
            throw new ConflictException("Salary payment is already recorded for this month");
        }
        var payment = new StaffSalaryPayment();
        payment.setSocietyId(societyId);
        payment.setStaffUserId(staffId);
        payment.setSalaryMonth(salaryMonth);
        payment.setAmount(amount);
        payment.setPaidOn(paidOn);
        payment.setPaymentMethod(PaymentMethod.from(method).code());
        payment.setReferenceNumber(reference);
        payment.setNote(note);
        payment.setRecordedBy(recorderId);
        payment.setCreatedAt(OffsetDateTime.now());
        payment = salaryPayments.save(payment);
        return Map.of("id", payment.getId(), "status", "RECORDED");
    }

    public Map<String, Object> create(
            UUID societyId,
            String fullName,
            String email,
            String mobile,
            String temporaryPassword,
            String staffType,
            String employeeCode,
            String dutyArea,
            String shiftName) {
        ensureStaffCapacity(societyId);
        var user = new UserAccount();
        user.setSocietyId(societyId);
        user.setFullName(fullName);
        user.setEmail(email);
        user.setMobile(mobile);
        user.setPasswordHash(passwords.encode(temporaryPassword));
        user.setRole(UserRole.STAFF.code());
        user.setStatus(AccountStatus.ACTIVE.code());
        user.setEmailVerified(false);
        user.setMobileVerified(false);
        user.setCreatedAt(OffsetDateTime.now());
        user = users.save(user);
        var profile = new StaffProfile();
        profile.setUserId(user.getId());
        profile.setStaffType(staffType);
        profile.setEmployeeCode(employeeCode);
        profile.setDutyArea(dutyArea);
        profile.setShiftName(shiftName);
        profile.setJoinedOn(LocalDate.now());
        profiles.save(profile);
        return Map.of(
                "userId",
                user.getId(),
                "role",
                UserRole.STAFF.code(),
                "status",
                AccountStatus.ACTIVE.code());
    }

    public Map<String, Object> update(
            UUID societyId,
            UUID staffId,
            String fullName,
            String email,
            String mobile,
            String staffType,
            String employeeCode,
            String dutyArea,
            String shiftName) {
        var user = requireStaff(societyId, staffId);
        user.setFullName(fullName.trim());
        user.setEmail(email.trim().toLowerCase());
        user.setMobile(mobile.trim());
        users.save(user);
        var profile = profiles.findById(staffId).orElseGet(StaffProfile::new);
        profile.setUserId(staffId);
        profile.setStaffType(staffType);
        profile.setEmployeeCode(employeeCode);
        profile.setDutyArea(dutyArea);
        profile.setShiftName(shiftName);
        if (profile.getJoinedOn() == null) profile.setJoinedOn(LocalDate.now());
        profiles.save(profile);
        return Map.of("id", staffId, "updated", true);
    }

    public Map<String, Object> setStatus(UUID societyId, UUID staffId, String status) {
        var user = requireStaff(societyId, staffId);
        user.setStatus(AccountStatus.from(status).code());
        users.save(user);
        return Map.of("id", staffId, "status", status);
    }

    public Map<String, Object> resetPassword(
            UUID societyId, UUID staffId, String temporaryPassword) {
        var user = requireStaff(societyId, staffId);
        user.setPasswordHash(passwords.encode(temporaryPassword));
        users.save(user);
        return Map.of("id", staffId, "passwordReset", true);
    }

    public Map<String, Object> setPermissions(
            UUID societyId, UUID granterId, UUID staffId, Set<String> codes) {
        requireStaff(societyId, staffId);
        var society =
                societies
                        .findById(societyId)
                        .orElseThrow(
                                () ->
                                        new com.societyapp.application.exception
                                                .ResourceNotFoundException("Society not found"));
        codes = StaffPermissionCatalog.validate(codes, society.getEnabledModules());
        permissions.deleteByStaffUserId(staffId);
        permissions.flush();
        for (var code : codes) {
            var permission = new StaffPermission();
            permission.setStaffUserId(staffId);
            permission.setPermissionCode(code);
            permission.setGrantedBy(granterId);
            permission.setGrantedAt(OffsetDateTime.now());
            permissions.save(permission);
        }
        return Map.of("id", staffId, "permissions", codes);
    }

    private UserAccount requireStaff(UUID societyId, UUID staffId) {
        return users.findById(staffId)
                .filter(user -> societyId.equals(user.getSocietyId()))
                .filter(user -> UserRole.STAFF.matches(user.getRole()))
                .orElseThrow(
                        () ->
                                new com.societyapp.application.exception.ResourceNotFoundException(
                                        "Staff member not found"));
    }

    private void ensureStaffCapacity(UUID societyId) {
        var society =
                societies
                        .findById(societyId)
                        .orElseThrow(() -> new ConflictException("Society not found"));
        Integer planLimit =
                customPlans.findAllByOrderByCreatedAtDesc().stream()
                        .filter(plan -> societyId.equals(plan.getSocietyId()))
                        .filter(plan -> LifecycleStatus.ACTIVE.matches(plan.getStatus()))
                        .map(SocietyCustomPlan::getMaxStaff)
                        .filter(Objects::nonNull)
                        .findFirst()
                        .orElseGet(
                                () ->
                                        plans.findById(society.getPlanCode())
                                                .map(SubscriptionPlan::getMaxStaff)
                                                .orElse(null));
        int purchasedSeats = society.getPlannedStaff();
        int allowed = planLimit == null ? purchasedSeats : Math.min(purchasedSeats, planLimit);
        long activeStaff =
                users
                        .findBySocietyIdAndRoleOrderByFullName(societyId, UserRole.STAFF.code())
                        .stream()
                        .filter(user -> AccountStatus.ACTIVE.matches(user.getStatus()))
                        .count();
        if (activeStaff >= allowed) {
            throw new ConflictException(
                    "Your subscription includes "
                            + allowed
                            + " staff seats. Increase the selected staff quantity first.");
        }
    }

    private Map<String, Object> view(UserAccount user) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", user.getId());
        map.put("full_name", user.getFullName());
        map.put("email", user.getEmail());
        map.put("mobile", user.getMobile());
        map.put("status", user.getStatus());
        map.put(
                "permissions",
                permissions.findByStaffUserId(user.getId()).stream()
                        .map(StaffPermission::getPermissionCode)
                        .sorted()
                        .toList());
        profiles.findById(user.getId())
                .ifPresent(
                        profile -> {
                            map.put("staff_type", profile.getStaffType());
                            map.put("employee_code", profile.getEmployeeCode());
                            map.put("duty_area", profile.getDutyArea());
                            map.put("shift_name", profile.getShiftName());
                            map.put("joined_on", profile.getJoinedOn());
                            map.put("date_of_birth", profile.getDateOfBirth());
                            map.put("gender", profile.getGender());
                            map.put("alternate_mobile", profile.getAlternateMobile());
                            map.put("address", profile.getAddress());
                            map.put("emergency_contact_name", profile.getEmergencyContactName());
                            map.put(
                                    "emergency_contact_mobile",
                                    profile.getEmergencyContactMobile());
                            map.put("id_type", profile.getIdType());
                            map.put("id_number", profile.getIdNumber());
                            map.put("monthly_salary", profile.getMonthlySalary());
                            map.put("bank_account_name", profile.getBankAccountName());
                            map.put("bank_account_number", profile.getBankAccountNumber());
                            map.put("bank_ifsc", profile.getBankIfsc());
                            map.put("upi_id", profile.getUpiId());
                        });
        return map;
    }

    private Map<String, Object> attendanceView(StaffAttendance row) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", row.getId());
        map.put("attendance_date", row.getAttendanceDate());
        map.put("status", row.getStatus());
        map.put("check_in", row.getCheckIn());
        map.put("check_out", row.getCheckOut());
        map.put("note", row.getNote());
        map.put("marked_by", row.getMarkedBy());
        map.put("updated_at", row.getUpdatedAt());
        return map;
    }

    private Map<String, Object> salaryView(StaffSalaryPayment row) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", row.getId());
        map.put("salary_month", row.getSalaryMonth());
        map.put("amount", row.getAmount());
        map.put("paid_on", row.getPaidOn());
        map.put("payment_method", row.getPaymentMethod());
        map.put("reference_number", row.getReferenceNumber());
        map.put("note", row.getNote());
        map.put("created_at", row.getCreatedAt());
        return map;
    }
}
