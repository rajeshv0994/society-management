package com.societyapp.application.usecase;

import com.societyapp.application.exception.AuthorizationException;
import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.port.in.TaskUseCase;
import com.societyapp.application.port.out.persistence.*;
import com.societyapp.domain.model.*;
import com.societyapp.domain.type.AccountStatus;
import com.societyapp.domain.type.StaffPermissionCode;
import com.societyapp.domain.type.TaskStatus;
import com.societyapp.domain.type.UserRole;
import com.societyapp.domain.type.WorkPriority;
import java.time.OffsetDateTime;
import java.util.*;

public class TaskService implements TaskUseCase {
    private final StaffTaskRepository tasks;
    private final StaffTaskUpdateRepository updates;
    private final UserAccountJpaRepository users;
    private final StaffPermissionRepository permissions;

    public TaskService(
            StaffTaskRepository tasks,
            StaffTaskUpdateRepository updates,
            UserAccountJpaRepository users,
            StaffPermissionRepository permissions) {
        this.tasks = tasks;
        this.updates = updates;
        this.users = users;
        this.permissions = permissions;
    }

    public List<Map<String, Object>> list(UUID societyId, UUID userId, String role) {
        if (UserRole.STAFF.matches(role)) requireStaffPermission(userId);
        return tasks.findBySocietyIdOrderByCreatedAtDesc(societyId).stream()
                .filter(
                        task ->
                                !UserRole.STAFF.matches(role)
                                        || task.getAssignedTo().equals(userId))
                .map(this::view)
                .toList();
    }

    public Map<String, Object> options(UUID societyId, UUID userId, String role) {
        if (UserRole.STAFF.matches(role)) requireStaffPermission(userId);
        var staff =
                users
                        .findBySocietyIdAndRoleOrderByFullName(societyId, UserRole.STAFF.code())
                        .stream()
                        .filter(user -> AccountStatus.ACTIVE.matches(user.getStatus()))
                        .filter(
                                user ->
                                        permissions.existsByStaffUserIdAndPermissionCode(
                                                user.getId(), StaffPermissionCode.TASKS.code()))
                        .map(
                                user ->
                                        Map.<String, Object>of(
                                                "id", user.getId(),
                                                "full_name", user.getFullName()))
                        .toList();
        return Map.of("current_user_id", userId, "staff", staff);
    }

    public Map<String, Object> detail(UUID societyId, UUID userId, String role, UUID taskId) {
        var task = requireVisible(societyId, userId, role, taskId);
        var result = new LinkedHashMap<String, Object>(view(task));
        result.put(
                "timeline",
                updates.findByTaskIdOrderByCreatedAt(taskId).stream()
                        .map(this::updateView)
                        .toList());
        return result;
    }

    public Map<String, Object> create(
            UUID societyId,
            UUID assignerId,
            String title,
            String description,
            UUID assigneeId,
            OffsetDateTime dueAt,
            String priority) {
        var staff = requireAssignableStaff(societyId, assigneeId);
        var now = OffsetDateTime.now();
        var task = new StaffTask();
        task.setSocietyId(societyId);
        task.setTitle(title.trim());
        task.setDescription(description == null ? null : description.trim());
        task.setAssignedTo(staff.getId());
        task.setAssignedBy(assignerId);
        task.setDueAt(dueAt);
        task.setPriority(
                WorkPriority.from(priority == null ? WorkPriority.NORMAL.code() : priority).code());
        task.setStatus(TaskStatus.OPEN.code());
        task.setCreatedAt(now);
        task.setUpdatedAt(now);
        task = tasks.save(task);
        addUpdate(
                task.getId(),
                assignerId,
                "CREATED",
                null,
                TaskStatus.OPEN.code(),
                "Task assigned to " + staff.getFullName());
        return Map.of("id", task.getId(), "status", task.getStatus());
    }

    public Map<String, Object> edit(
            UUID societyId,
            UUID actorId,
            UUID taskId,
            String title,
            String description,
            UUID assignedTo,
            OffsetDateTime dueAt,
            String priority) {
        var task =
                tasks.findByIdAndSocietyId(taskId, societyId)
                        .orElseThrow(() -> new ResourceNotFoundException("Task not found"));
        var staff = requireAssignableStaff(societyId, assignedTo);
        boolean reassigned = !task.getAssignedTo().equals(assignedTo);
        task.setTitle(title.trim());
        task.setDescription(description == null ? null : description.trim());
        task.setAssignedTo(assignedTo);
        task.setDueAt(dueAt);
        task.setPriority(WorkPriority.from(priority).code());
        task.setUpdatedAt(OffsetDateTime.now());
        tasks.save(task);
        addUpdate(
                taskId,
                actorId,
                reassigned ? "REASSIGNED" : "EDITED",
                task.getStatus(),
                task.getStatus(),
                reassigned ? "Task reassigned to " + staff.getFullName() : "Task details updated");
        return Map.of("id", taskId, "status", task.getStatus());
    }

    public Map<String, Object> progress(
            UUID societyId, UUID actorId, String role, UUID taskId, String status, String note) {
        var task = requireVisible(societyId, actorId, role, taskId);
        var previous = TaskStatus.from(task.getStatus());
        var next = TaskStatus.from(status);
        validateTransition(previous, next, role);
        if ((next == TaskStatus.BLOCKED || next == TaskStatus.COMPLETED)
                && (note == null || note.isBlank())) {
            throw new IllegalArgumentException(
                    "A note is required when blocking or completing a task");
        }
        if (previous == next && (note == null || note.isBlank())) {
            throw new IllegalArgumentException("Add a progress note or change status");
        }
        var now = OffsetDateTime.now();
        task.setStatus(next.code());
        task.setUpdatedAt(now);
        if (next == TaskStatus.IN_PROGRESS && task.getStartedAt() == null) {
            task.setStartedAt(now);
        }
        if (next == TaskStatus.COMPLETED) {
            task.setCompletionNote(note.trim());
            task.setCompletedAt(now);
        } else {
            task.setCompletedAt(null);
            if (previous == TaskStatus.COMPLETED) {
                task.setCompletionNote(null);
            }
        }
        tasks.save(task);
        addUpdate(
                taskId,
                actorId,
                previous == next ? "PROGRESS_NOTE" : "STATUS_CHANGED",
                previous.code(),
                next.code(),
                note);
        return Map.of("id", taskId, "status", next.code());
    }

    public Map<String, Object> comment(
            UUID societyId, UUID actorId, String role, UUID taskId, String note) {
        var task = requireVisible(societyId, actorId, role, taskId);
        task.setUpdatedAt(OffsetDateTime.now());
        tasks.save(task);
        addUpdate(taskId, actorId, "COMMENT", null, null, note);
        return Map.of("id", taskId, "commented", true);
    }

    public Map<String, Object> complete(
            UUID societyId, UUID userId, String role, UUID taskId, String note) {
        return progress(societyId, userId, role, taskId, TaskStatus.COMPLETED.code(), note);
    }

    private StaffTask requireVisible(UUID societyId, UUID userId, String role, UUID taskId) {
        if (UserRole.STAFF.matches(role)) requireStaffPermission(userId);
        return tasks.findByIdAndSocietyId(taskId, societyId)
                .filter(
                        task ->
                                !UserRole.STAFF.matches(role)
                                        || task.getAssignedTo().equals(userId))
                .orElseThrow(() -> new ResourceNotFoundException("Task not found"));
    }

    private UserAccount requireAssignableStaff(UUID societyId, UUID staffId) {
        return users.findById(staffId)
                .filter(user -> societyId.equals(user.getSocietyId()))
                .filter(user -> UserRole.STAFF.matches(user.getRole()))
                .filter(user -> AccountStatus.ACTIVE.matches(user.getStatus()))
                .filter(
                        user ->
                                permissions.existsByStaffUserIdAndPermissionCode(
                                        user.getId(), StaffPermissionCode.TASKS.code()))
                .orElseThrow(
                        () ->
                                new ResourceNotFoundException(
                                        "Active staff with Tasks permission not found"));
    }

    private void requireStaffPermission(UUID staffId) {
        if (!permissions.existsByStaffUserIdAndPermissionCode(
                staffId, StaffPermissionCode.TASKS.code())) {
            throw new AuthorizationException("Tasks permission is required");
        }
    }

    private void validateTransition(TaskStatus from, TaskStatus to, String role) {
        if (from == to) return;
        if (!from.allowedTransitions().contains(to)) {
            throw new IllegalStateException("Invalid task status transition");
        }
        if (UserRole.STAFF.matches(role)
                && ((from == TaskStatus.COMPLETED && to == TaskStatus.IN_PROGRESS)
                        || (from == TaskStatus.CANCELLED && to == TaskStatus.OPEN)
                        || to == TaskStatus.CANCELLED)) {
            throw new AuthorizationException("Only Society Admin can cancel or reopen tasks");
        }
    }

    private void addUpdate(
            UUID taskId, UUID actorId, String event, String from, String to, String note) {
        var update = new StaffTaskUpdate();
        update.setTaskId(taskId);
        update.setActorUserId(actorId);
        update.setEventType(event);
        update.setFromStatus(from);
        update.setToStatus(to);
        update.setNote(note);
        update.setCreatedAt(OffsetDateTime.now());
        updates.save(update);
    }

    private Map<String, Object> view(StaffTask task) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", task.getId());
        map.put("reference", "TSK-" + task.getId().toString().substring(0, 8).toUpperCase());
        map.put("title", task.getTitle());
        map.put("description", task.getDescription());
        map.put("assigned_to", task.getAssignedTo());
        map.put("assigned_by", task.getAssignedBy());
        map.put("due_at", task.getDueAt());
        map.put("priority", task.getPriority());
        map.put("status", task.getStatus());
        map.put("completion_note", task.getCompletionNote());
        map.put("created_at", task.getCreatedAt());
        map.put("updated_at", task.getUpdatedAt());
        map.put("started_at", task.getStartedAt());
        map.put("completed_at", task.getCompletedAt());
        map.put(
                "overdue",
                task.getDueAt() != null
                        && task.getDueAt().isBefore(OffsetDateTime.now())
                        && !TaskStatus.from(task.getStatus()).isTerminal());
        map.put(
                "assigned_to_name",
                users.findById(task.getAssignedTo()).map(UserAccount::getFullName).orElse(null));
        map.put(
                "assigned_by_name",
                users.findById(task.getAssignedBy()).map(UserAccount::getFullName).orElse(null));
        return map;
    }

    private Map<String, Object> updateView(StaffTaskUpdate update) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", update.getId());
        map.put("event_type", update.getEventType());
        map.put("from_status", update.getFromStatus());
        map.put("to_status", update.getToStatus());
        map.put("note", update.getNote());
        map.put("created_at", update.getCreatedAt());
        map.put(
                "actor_name",
                users.findById(update.getActorUserId())
                        .map(UserAccount::getFullName)
                        .orElse("User"));
        return map;
    }
}
