package com.societyapp.application.usecase;

import com.societyapp.application.exception.ConflictException;
import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.mapper.ApiViewMapper;
import com.societyapp.application.policy.StaffPermissionCatalog;
import com.societyapp.application.port.in.ConfigurationUseCase;
import com.societyapp.application.port.in.StructureAccessUseCase;
import com.societyapp.application.port.out.JsonCodec;
import com.societyapp.application.port.out.JsonCodecException;
import com.societyapp.application.port.out.persistence.*;
import com.societyapp.domain.model.*;
import com.societyapp.domain.type.BuiltInServiceCode;
import com.societyapp.domain.type.ChargeCalculationType;
import com.societyapp.domain.type.ChargeFrequency;
import com.societyapp.domain.type.ParkingAction;
import com.societyapp.domain.type.ParkingSlotStatus;
import com.societyapp.domain.type.ParkingSlotType;
import com.societyapp.domain.type.UserRole;
import com.societyapp.domain.type.VendorStatus;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;

public class ConfigurationService implements ConfigurationUseCase {
    private final ParkingSlotRepository parking;
    private final VendorRepository vendors;
    private final ComplaintCategoryRepository categories;
    private final MaintenanceChargeRuleRepository charges;
    private final StaffPermissionRepository permissions;
    private final UserAccountJpaRepository users;
    private final BlockRepository blocks;
    private final FloorRepository floors;
    private final FlatRepository flats;
    private final SocietyRepository societies;
    private final AuditEventRepository audits;
    private final StructureAccessUseCase structure;
    private final ApiViewMapper views;
    private final JsonCodec json;

    public ConfigurationService(
            ParkingSlotRepository parking,
            VendorRepository vendors,
            ComplaintCategoryRepository categories,
            MaintenanceChargeRuleRepository charges,
            StaffPermissionRepository permissions,
            UserAccountJpaRepository users,
            BlockRepository blocks,
            FloorRepository floors,
            FlatRepository flats,
            SocietyRepository societies,
            AuditEventRepository audits,
            StructureAccessUseCase structure,
            ApiViewMapper views,
            JsonCodec json) {
        this.parking = parking;
        this.vendors = vendors;
        this.categories = categories;
        this.charges = charges;
        this.permissions = permissions;
        this.users = users;
        this.blocks = blocks;
        this.floors = floors;
        this.flats = flats;
        this.societies = societies;
        this.audits = audits;
        this.structure = structure;
        this.views = views;
        this.json = json;
    }

    public Map<String, Object> get(UUID societyId) {
        var society = requireSociety(societyId);
        var parkingRows = parking.findBySocietyIdOrderBySlotNumber(societyId);
        var vendorRows = vendors.findBySocietyIdOrderByName(societyId);
        var categoryRows = categories.findBySocietyIdOrderByName(societyId);
        var chargeRows = charges.findBySocietyIdOrderByName(societyId);
        var result = new LinkedHashMap<String, Object>();
        result.put("parking", parkingRows.stream().map(views::toMap).toList());
        result.put("vendors", vendorRows.stream().map(views::toMap).toList());
        result.put("complaintCategories", categoryRows.stream().map(views::toMap).toList());
        result.put("chargeRules", chargeRows.stream().map(views::toMap).toList());
        result.put("spaces", spaceOptions(societyId));
        result.put("summary", summary(parkingRows, vendorRows, categoryRows, chargeRows));
        result.put("setup", setupReadiness(societyId, society));
        result.put("enabled_modules", enabledModules(society));
        result.put(
                "staff_permission_options",
                StaffPermissionCatalog.definitionsFor(society.getEnabledModules())
                        .entrySet()
                        .stream()
                        .map(
                                entry ->
                                        Map.of(
                                                "code",
                                                entry.getKey(),
                                                "label",
                                                entry.getValue().label(),
                                                "required_module",
                                                entry.getValue().requiredModule()))
                        .toList());
        return result;
    }

    public Map<String, Object> reference(UUID societyId, UUID userId, String role) {
        var society = requireSociety(societyId);
        var now = LocalDate.now();
        var result = new LinkedHashMap<String, Object>();
        result.put(
                "parking",
                StaffPermissionCatalog.moduleEnabled(
                                society.getEnabledModules(), BuiltInServiceCode.PARKING.code())
                        ? parking.findBySocietyIdOrderBySlotNumber(societyId).stream()
                                .filter(
                                        item ->
                                                !ParkingSlotStatus.INACTIVE.matches(
                                                        item.getStatus()))
                                .map(this::parkingReference)
                                .toList()
                        : List.of());
        result.put(
                "vendors",
                StaffPermissionCatalog.moduleEnabled(
                                society.getEnabledModules(), BuiltInServiceCode.VENDORS.code())
                        ? vendors.findBySocietyIdOrderByName(societyId).stream()
                                .filter(item -> VendorStatus.ACTIVE.matches(item.getStatus()))
                                .map(views::toMap)
                                .toList()
                        : List.of());
        result.put(
                "complaint_categories",
                StaffPermissionCatalog.moduleEnabled(
                                society.getEnabledModules(), BuiltInServiceCode.COMPLAINTS.code())
                        ? categories.findBySocietyIdOrderByName(societyId).stream()
                                .filter(ComplaintCategory::isActive)
                                .map(views::toMap)
                                .toList()
                        : List.of());
        result.put(
                "charge_rules",
                StaffPermissionCatalog.moduleEnabled(
                                society.getEnabledModules(), BuiltInServiceCode.BILLING.code())
                        ? charges.findBySocietyIdOrderByName(societyId).stream()
                                .filter(MaintenanceChargeRule::isActive)
                                .filter(item -> !item.getEffectiveFrom().isAfter(now))
                                .filter(
                                        item ->
                                                item.getEffectiveTo() == null
                                                        || !item.getEffectiveTo().isBefore(now))
                                .map(views::toMap)
                                .toList()
                        : List.of());
        result.put("enabled_modules", enabledModules(society));
        result.put("viewer_role", role);
        result.put("viewer_id", userId);
        return result;
    }

    public Map<String, Object> addParking(
            UUID societyId, UUID actorId, String number, String type) {
        requireModule(societyId, BuiltInServiceCode.PARKING);
        number = required(number, "Parking slot number").toUpperCase(Locale.ROOT);
        var requestedType = ParkingSlotType.from(type);
        if (parking.existsBySocietyIdAndSlotNumberIgnoreCase(societyId, number)) {
            throw new ConflictException("Parking slot number already exists");
        }
        var now = OffsetDateTime.now();
        var slot = new ParkingSlot();
        slot.setSocietyId(societyId);
        slot.setSlotNumber(number);
        slot.setSlotType(requestedType.code());
        slot.setStatus(ParkingSlotStatus.AVAILABLE.code());
        slot.setCreatedAt(now);
        slot.setUpdatedAt(now);
        slot = parking.save(slot);
        audit(societyId, actorId, "CONFIGURATION_CREATED", "PARKING_SLOT", slot.getId(), Map.of());
        return views.toMap(slot);
    }

    public Map<String, Object> updateParking(
            UUID societyId, UUID actorId, UUID id, String number, String type) {
        requireModule(societyId, BuiltInServiceCode.PARKING);
        var slot = requireParking(societyId, id);
        number = required(number, "Parking slot number").toUpperCase(Locale.ROOT);
        var requestedType = ParkingSlotType.from(type);
        if (parking.existsBySocietyIdAndSlotNumberIgnoreCaseAndIdNot(societyId, number, id)) {
            throw new ConflictException("Parking slot number already exists");
        }
        slot.setSlotNumber(number);
        slot.setSlotType(requestedType.code());
        slot.setUpdatedAt(OffsetDateTime.now());
        slot = parking.save(slot);
        audit(societyId, actorId, "CONFIGURATION_UPDATED", "PARKING_SLOT", id, Map.of());
        return views.toMap(slot);
    }

    public Map<String, Object> parkingAction(
            UUID societyId,
            UUID actorId,
            UUID id,
            String action,
            UUID flatId,
            String vehicleNumber) {
        requireModule(societyId, BuiltInServiceCode.PARKING);
        var slot = requireParking(societyId, id);
        var requestedAction = ParkingAction.from(action);
        switch (requestedAction) {
            case ALLOCATE -> {
                if (flatId == null) throw new IllegalArgumentException("Space is required");
                structure.requireFlat(flatId, societyId);
                vehicleNumber = required(vehicleNumber, "Vehicle number").toUpperCase(Locale.ROOT);
                slot.setFlatId(flatId);
                slot.setVehicleNumber(vehicleNumber);
                slot.setStatus(ParkingSlotStatus.ALLOCATED.code());
            }
            case RELEASE, ACTIVATE -> clearAllocation(slot, ParkingSlotStatus.AVAILABLE);
            case RESERVE -> clearAllocation(slot, ParkingSlotStatus.RESERVED);
            case MAINTENANCE -> clearAllocation(slot, ParkingSlotStatus.MAINTENANCE);
            case DEACTIVATE -> clearAllocation(slot, ParkingSlotStatus.INACTIVE);
        }
        slot.setUpdatedAt(OffsetDateTime.now());
        slot = parking.save(slot);
        audit(
                societyId,
                actorId,
                "PARKING_" + requestedAction.code(),
                "PARKING_SLOT",
                id,
                Map.of("status", slot.getStatus()));
        return views.toMap(slot);
    }

    public Map<String, Object> addVendor(
            UUID societyId,
            UUID actorId,
            String name,
            String serviceType,
            String contact,
            String mobile,
            String email,
            String gst) {
        requireModule(societyId, BuiltInServiceCode.VENDORS);
        name = required(name, "Vendor name");
        serviceType = required(serviceType, "Service type");
        ensureVendorUnique(societyId, name, serviceType, null);
        var now = OffsetDateTime.now();
        var vendor = new Vendor();
        vendor.setSocietyId(societyId);
        applyVendor(vendor, name, serviceType, contact, mobile, email, gst);
        vendor.setStatus(VendorStatus.ACTIVE.code());
        vendor.setCreatedAt(now);
        vendor.setUpdatedAt(now);
        vendor = vendors.save(vendor);
        audit(societyId, actorId, "CONFIGURATION_CREATED", "VENDOR", vendor.getId(), Map.of());
        return views.toMap(vendor);
    }

    public Map<String, Object> updateVendor(
            UUID societyId,
            UUID actorId,
            UUID id,
            String name,
            String serviceType,
            String contact,
            String mobile,
            String email,
            String gst) {
        requireModule(societyId, BuiltInServiceCode.VENDORS);
        var vendor = requireVendor(societyId, id);
        name = required(name, "Vendor name");
        serviceType = required(serviceType, "Service type");
        ensureVendorUnique(societyId, name, serviceType, id);
        applyVendor(vendor, name, serviceType, contact, mobile, email, gst);
        vendor.setUpdatedAt(OffsetDateTime.now());
        vendor = vendors.save(vendor);
        audit(societyId, actorId, "CONFIGURATION_UPDATED", "VENDOR", id, Map.of());
        return views.toMap(vendor);
    }

    public Map<String, Object> setVendorStatus(
            UUID societyId, UUID actorId, UUID id, String status) {
        requireModule(societyId, BuiltInServiceCode.VENDORS);
        var requestedStatus = VendorStatus.from(status);
        var vendor = requireVendor(societyId, id);
        vendor.setStatus(requestedStatus.code());
        vendor.setUpdatedAt(OffsetDateTime.now());
        vendor = vendors.save(vendor);
        audit(
                societyId,
                actorId,
                "VENDOR_" + requestedStatus.code(),
                "VENDOR",
                id,
                Map.of("status", requestedStatus.code()));
        return views.toMap(vendor);
    }

    public Map<String, Object> addCategory(
            UUID societyId, UUID actorId, String name, int slaHours) {
        requireModule(societyId, BuiltInServiceCode.COMPLAINTS);
        name = required(name, "Category name");
        validateSla(slaHours);
        if (categories.existsBySocietyIdAndNameIgnoreCase(societyId, name)) {
            throw new ConflictException("Complaint category already exists");
        }
        var now = OffsetDateTime.now();
        var category = new ComplaintCategory();
        category.setSocietyId(societyId);
        category.setName(name);
        category.setSlaHours(slaHours);
        category.setActive(true);
        category.setCreatedAt(now);
        category.setUpdatedAt(now);
        category = categories.save(category);
        audit(
                societyId,
                actorId,
                "CONFIGURATION_CREATED",
                "COMPLAINT_CATEGORY",
                category.getId(),
                Map.of());
        return views.toMap(category);
    }

    public Map<String, Object> updateCategory(
            UUID societyId, UUID actorId, UUID id, String name, int slaHours) {
        requireModule(societyId, BuiltInServiceCode.COMPLAINTS);
        var category = requireCategory(societyId, id);
        name = required(name, "Category name");
        validateSla(slaHours);
        if (categories.existsBySocietyIdAndNameIgnoreCaseAndIdNot(societyId, name, id)) {
            throw new ConflictException("Complaint category already exists");
        }
        category.setName(name);
        category.setSlaHours(slaHours);
        category.setUpdatedAt(OffsetDateTime.now());
        category = categories.save(category);
        audit(societyId, actorId, "CONFIGURATION_UPDATED", "COMPLAINT_CATEGORY", id, Map.of());
        return views.toMap(category);
    }

    public Map<String, Object> setCategoryStatus(
            UUID societyId, UUID actorId, UUID id, boolean active) {
        requireModule(societyId, BuiltInServiceCode.COMPLAINTS);
        var category = requireCategory(societyId, id);
        category.setActive(active);
        category.setUpdatedAt(OffsetDateTime.now());
        category = categories.save(category);
        audit(
                societyId,
                actorId,
                active ? "CATEGORY_ACTIVATED" : "CATEGORY_DEACTIVATED",
                "COMPLAINT_CATEGORY",
                id,
                Map.of("active", active));
        return views.toMap(category);
    }

    public Map<String, Object> addCharge(
            UUID societyId,
            UUID actorId,
            String name,
            String calculationType,
            BigDecimal amount,
            String frequency,
            LocalDate effectiveFrom,
            LocalDate effectiveTo) {
        requireModule(societyId, BuiltInServiceCode.BILLING);
        name = required(name, "Charge rule name");
        validateCharge(calculationType, amount, frequency, effectiveFrom, effectiveTo);
        if (charges.existsBySocietyIdAndNameIgnoreCaseAndEffectiveFrom(
                societyId, name, effectiveFrom)) {
            throw new ConflictException("Charge rule already exists for this effective date");
        }
        var now = OffsetDateTime.now();
        var charge = new MaintenanceChargeRule();
        charge.setSocietyId(societyId);
        applyCharge(charge, name, calculationType, amount, frequency, effectiveFrom, effectiveTo);
        charge.setActive(true);
        charge.setCreatedAt(now);
        charge.setUpdatedAt(now);
        charge = charges.save(charge);
        audit(societyId, actorId, "CONFIGURATION_CREATED", "CHARGE_RULE", charge.getId(), Map.of());
        return views.toMap(charge);
    }

    public Map<String, Object> updateCharge(
            UUID societyId,
            UUID actorId,
            UUID id,
            String name,
            String calculationType,
            BigDecimal amount,
            String frequency,
            LocalDate effectiveFrom,
            LocalDate effectiveTo) {
        requireModule(societyId, BuiltInServiceCode.BILLING);
        var charge = requireCharge(societyId, id);
        name = required(name, "Charge rule name");
        validateCharge(calculationType, amount, frequency, effectiveFrom, effectiveTo);
        if (charges.existsBySocietyIdAndNameIgnoreCaseAndEffectiveFromAndIdNot(
                societyId, name, effectiveFrom, id)) {
            throw new ConflictException("Charge rule already exists for this effective date");
        }
        applyCharge(charge, name, calculationType, amount, frequency, effectiveFrom, effectiveTo);
        charge.setUpdatedAt(OffsetDateTime.now());
        charge = charges.save(charge);
        audit(societyId, actorId, "CONFIGURATION_UPDATED", "CHARGE_RULE", id, Map.of());
        return views.toMap(charge);
    }

    public Map<String, Object> setChargeStatus(
            UUID societyId, UUID actorId, UUID id, boolean active) {
        requireModule(societyId, BuiltInServiceCode.BILLING);
        var charge = requireCharge(societyId, id);
        charge.setActive(active);
        charge.setUpdatedAt(OffsetDateTime.now());
        charge = charges.save(charge);
        audit(
                societyId,
                actorId,
                active ? "CHARGE_RULE_ACTIVATED" : "CHARGE_RULE_DEACTIVATED",
                "CHARGE_RULE",
                id,
                Map.of("active", active));
        return views.toMap(charge);
    }

    public Map<String, Object> setPermissions(
            UUID societyId, UUID granterId, UUID staffId, Set<String> codes) {
        var society = requireSociety(societyId);
        users.findById(staffId)
                .filter(user -> societyId.equals(user.getSocietyId()))
                .filter(user -> UserRole.STAFF.matches(user.getRole()))
                .orElseThrow(() -> new ResourceNotFoundException("Staff member not found"));
        codes = StaffPermissionCatalog.validate(codes, society.getEnabledModules());
        permissions.deleteByStaffUserId(staffId);
        permissions.flush();
        for (String code : codes) {
            var permission = new StaffPermission();
            permission.setStaffUserId(staffId);
            permission.setPermissionCode(code);
            permission.setGrantedBy(granterId);
            permission.setGrantedAt(OffsetDateTime.now());
            permissions.save(permission);
        }
        audit(
                societyId,
                granterId,
                "STAFF_PERMISSIONS_UPDATED",
                UserRole.STAFF.code(),
                staffId,
                Map.of("permissions", codes));
        return Map.of("staffId", staffId, "permissions", codes);
    }

    public Map<String, Object> complete(UUID societyId, UUID actorId) {
        var society = requireSociety(societyId);
        var readiness = setupReadiness(societyId, society);
        if (!Boolean.TRUE.equals(readiness.get("ready"))) {
            throw new IllegalStateException("At least one property group and space are required");
        }
        society.setSetupCompleted(true);
        society.setUpdatedAt(OffsetDateTime.now());
        societies.save(society);
        audit(societyId, actorId, "SOCIETY_SETUP_COMPLETED", "SOCIETY", societyId, Map.of());
        return Map.of("setup_completed", true, "setup", setupReadiness(societyId, society));
    }

    private Map<String, Object> summary(
            List<ParkingSlot> parkingRows,
            List<Vendor> vendorRows,
            List<ComplaintCategory> categoryRows,
            List<MaintenanceChargeRule> chargeRows) {
        return Map.of(
                "parking_total",
                parkingRows.size(),
                "parking_available",
                parkingRows.stream()
                        .filter(item -> ParkingSlotStatus.AVAILABLE.matches(item.getStatus()))
                        .count(),
                "parking_allocated",
                parkingRows.stream()
                        .filter(item -> ParkingSlotStatus.ALLOCATED.matches(item.getStatus()))
                        .count(),
                "active_vendors",
                vendorRows.stream()
                        .filter(item -> VendorStatus.ACTIVE.matches(item.getStatus()))
                        .count(),
                "active_categories",
                categoryRows.stream().filter(ComplaintCategory::isActive).count(),
                "active_charge_rules",
                chargeRows.stream().filter(MaintenanceChargeRule::isActive).count());
    }

    private Map<String, Object> setupReadiness(UUID societyId, Society society) {
        var societyBlocks = blocks.findBySocietyIdOrderByName(societyId);
        long spaceCount =
                societyBlocks.stream()
                        .flatMap(
                                block ->
                                        floors
                                                .findByBlockIdOrderByFloorNumber(block.getId())
                                                .stream())
                        .mapToLong(
                                floor -> flats.findByFloorIdOrderByFlatNumber(floor.getId()).size())
                        .sum();
        var checklist = new ArrayList<Map<String, Object>>();
        checklist.add(
                checklist(
                        "PROPERTY_GROUP",
                        "At least one property group",
                        !societyBlocks.isEmpty(),
                        true));
        checklist.add(checklist("SPACE", "At least one configured space", spaceCount > 0, true));
        addOptionalChecklist(
                checklist,
                society,
                BuiltInServiceCode.PARKING.code(),
                "Parking slots",
                !parking.findBySocietyIdOrderBySlotNumber(societyId).isEmpty());
        addOptionalChecklist(
                checklist,
                society,
                BuiltInServiceCode.VENDORS.code(),
                "Active vendors",
                vendors.findBySocietyIdOrderByName(societyId).stream()
                        .anyMatch(item -> VendorStatus.ACTIVE.matches(item.getStatus())));
        addOptionalChecklist(
                checklist,
                society,
                BuiltInServiceCode.COMPLAINTS.code(),
                "Active complaint categories",
                categories.findBySocietyIdOrderByName(societyId).stream()
                        .anyMatch(ComplaintCategory::isActive));
        addOptionalChecklist(
                checklist,
                society,
                BuiltInServiceCode.BILLING.code(),
                "Active charge rules",
                charges.findBySocietyIdOrderByName(societyId).stream()
                        .anyMatch(MaintenanceChargeRule::isActive));
        boolean ready =
                checklist.stream()
                        .filter(item -> Boolean.TRUE.equals(item.get("required")))
                        .allMatch(item -> Boolean.TRUE.equals(item.get("complete")));
        return Map.of(
                "ready",
                ready,
                "setup_completed",
                society.isSetupCompleted(),
                "property_groups",
                societyBlocks.size(),
                "spaces",
                spaceCount,
                "checklist",
                checklist);
    }

    private void addOptionalChecklist(
            List<Map<String, Object>> checklist,
            Society society,
            String module,
            String label,
            boolean complete) {
        if (StaffPermissionCatalog.moduleEnabled(society.getEnabledModules(), module)) {
            checklist.add(checklist(module, label, complete, false));
        }
    }

    private Map<String, Object> checklist(
            String code, String label, boolean complete, boolean required) {
        return Map.of("code", code, "label", label, "complete", complete, "required", required);
    }

    private List<Map<String, Object>> spaceOptions(UUID societyId) {
        var result = new ArrayList<Map<String, Object>>();
        for (var block : blocks.findBySocietyIdOrderByName(societyId)) {
            for (var floor : floors.findByBlockIdOrderByFloorNumber(block.getId())) {
                for (var flat : flats.findByFloorIdOrderByFlatNumber(floor.getId())) {
                    result.add(
                            Map.of(
                                    "id",
                                    flat.getId(),
                                    "label",
                                    block.getName()
                                            + " · "
                                            + floor.getName()
                                            + " · "
                                            + flat.getFlatNumber(),
                                    "space_number",
                                    flat.getFlatNumber(),
                                    "occupancy_status",
                                    flat.getOccupancyStatus()));
                }
            }
        }
        return result;
    }

    private Map<String, Object> parkingReference(ParkingSlot slot) {
        var result = new LinkedHashMap<String, Object>();
        result.put("id", slot.getId());
        result.put("slot_number", slot.getSlotNumber());
        result.put("slot_type", slot.getSlotType());
        result.put("status", slot.getStatus());
        if (slot.getFlatId() != null) result.put("flat_id", slot.getFlatId());
        if (slot.getVehicleNumber() != null) result.put("vehicle_number", slot.getVehicleNumber());
        return result;
    }

    private void applyVendor(
            Vendor vendor,
            String name,
            String serviceType,
            String contact,
            String mobile,
            String email,
            String gst) {
        vendor.setName(name.trim());
        vendor.setServiceType(serviceType.trim());
        vendor.setContactPerson(blankToNull(contact));
        vendor.setMobile(required(mobile, "Vendor mobile"));
        vendor.setEmail(lowerBlankToNull(email));
        vendor.setGstNumber(upperBlankToNull(gst));
    }

    private void ensureVendorUnique(
            UUID societyId, String name, String serviceType, UUID excludedId) {
        boolean exists =
                excludedId == null
                        ? vendors.existsBySocietyIdAndNameIgnoreCaseAndServiceTypeIgnoreCase(
                                societyId, name, serviceType)
                        : vendors
                                .existsBySocietyIdAndNameIgnoreCaseAndServiceTypeIgnoreCaseAndIdNot(
                                        societyId, name, serviceType, excludedId);
        if (exists) throw new ConflictException("Vendor and service type already exist");
    }

    private void applyCharge(
            MaintenanceChargeRule charge,
            String name,
            String calculationType,
            BigDecimal amount,
            String frequency,
            LocalDate effectiveFrom,
            LocalDate effectiveTo) {
        charge.setName(name.trim());
        charge.setCalculationType(ChargeCalculationType.from(calculationType).code());
        charge.setAmount(amount);
        charge.setFrequency(ChargeFrequency.from(frequency).code());
        charge.setEffectiveFrom(effectiveFrom);
        charge.setEffectiveTo(effectiveTo);
    }

    private void validateCharge(
            String calculationType,
            BigDecimal amount,
            String frequency,
            LocalDate effectiveFrom,
            LocalDate effectiveTo) {
        var requestedCalculationType = ChargeCalculationType.from(calculationType);
        ChargeFrequency.from(frequency);
        if (amount == null || amount.signum() < 0) {
            throw new IllegalArgumentException("Charge amount cannot be negative");
        }
        if (requestedCalculationType == ChargeCalculationType.PERCENTAGE
                && amount.compareTo(BigDecimal.valueOf(100)) > 0) {
            throw new IllegalArgumentException("Percentage charge cannot exceed 100");
        }
        if (effectiveFrom == null) throw new IllegalArgumentException("Effective date is required");
        if (effectiveTo != null && effectiveTo.isBefore(effectiveFrom)) {
            throw new IllegalArgumentException("Effective end date cannot be before start date");
        }
    }

    private void validateSla(int slaHours) {
        if (slaHours < 1 || slaHours > 8760) {
            throw new IllegalArgumentException("SLA must be between 1 and 8760 hours");
        }
    }

    private void clearAllocation(ParkingSlot slot, ParkingSlotStatus status) {
        slot.setFlatId(null);
        slot.setVehicleNumber(null);
        slot.setStatus(status.code());
    }

    private ParkingSlot requireParking(UUID societyId, UUID id) {
        return parking.findByIdAndSocietyId(id, societyId)
                .orElseThrow(() -> new ResourceNotFoundException("Parking slot not found"));
    }

    private Vendor requireVendor(UUID societyId, UUID id) {
        return vendors.findByIdAndSocietyId(id, societyId)
                .orElseThrow(() -> new ResourceNotFoundException("Vendor not found"));
    }

    private ComplaintCategory requireCategory(UUID societyId, UUID id) {
        return categories
                .findByIdAndSocietyId(id, societyId)
                .orElseThrow(() -> new ResourceNotFoundException("Complaint category not found"));
    }

    private MaintenanceChargeRule requireCharge(UUID societyId, UUID id) {
        return charges.findByIdAndSocietyId(id, societyId)
                .orElseThrow(() -> new ResourceNotFoundException("Charge rule not found"));
    }

    private Society requireSociety(UUID societyId) {
        return societies
                .findById(societyId)
                .orElseThrow(() -> new ResourceNotFoundException("Society not found"));
    }

    private Society requireModule(UUID societyId, BuiltInServiceCode module) {
        var society = requireSociety(societyId);
        if (!StaffPermissionCatalog.moduleEnabled(society.getEnabledModules(), module.code())) {
            throw new IllegalStateException(
                    module.code().replace('_', ' ') + " module is not enabled");
        }
        return society;
    }

    private List<String> enabledModules(Society society) {
        try {
            return json.readStrings(society.getEnabledModules());
        } catch (JsonCodecException exception) {
            return List.of();
        }
    }

    private void audit(
            UUID societyId,
            UUID actorId,
            String action,
            String type,
            UUID entityId,
            Map<String, ?> details) {
        var event = new AuditEvent();
        event.setSocietyId(societyId);
        event.setActorUserId(actorId);
        event.setAction(action);
        event.setEntityType(type);
        event.setEntityId(entityId == null ? null : entityId.toString());
        try {
            event.setDetails(json.write(details));
        } catch (JsonCodecException exception) {
            event.setDetails("{}");
        }
        event.setOccurredAt(OffsetDateTime.now());
        audits.save(event);
    }

    private String required(String value, String label) {
        if (value == null || value.isBlank())
            throw new IllegalArgumentException(label + " is required");
        return value.trim();
    }

    private String normalized(String value) {
        return value == null ? "" : value.trim().toUpperCase(Locale.ROOT);
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private String lowerBlankToNull(String value) {
        value = blankToNull(value);
        return value == null ? null : value.toLowerCase(Locale.ROOT);
    }

    private String upperBlankToNull(String value) {
        value = blankToNull(value);
        return value == null ? null : value.toUpperCase(Locale.ROOT);
    }
}
