package com.societyapp.application.usecase;

import com.societyapp.application.port.in.AuditUseCase;
import com.societyapp.application.port.out.JsonCodec;
import com.societyapp.application.port.out.JsonCodecException;
import com.societyapp.application.port.out.persistence.AuditEventRepository;
import com.societyapp.application.port.out.persistence.AuditEventRepository.AuditQuery;
import com.societyapp.application.port.out.persistence.SocietyRepository;
import com.societyapp.application.port.out.persistence.UserAccountJpaRepository;
import com.societyapp.domain.model.AuditEvent;
import java.time.OffsetDateTime;
import java.util.*;

public class AuditService implements AuditUseCase {
    private final AuditEventRepository events;
    private final SocietyRepository societies;
    private final UserAccountJpaRepository users;
    private final JsonCodec json;

    public AuditService(
            AuditEventRepository events,
            SocietyRepository societies,
            UserAccountJpaRepository users,
            JsonCodec json) {
        this.events = events;
        this.societies = societies;
        this.users = users;
        this.json = json;
    }

    public void record(
            UUID societyId,
            UUID actorId,
            String action,
            String entityType,
            String entityId,
            Map<String, ?> details) {
        record(societyId, actorId, action, entityType, entityId, false, details);
    }

    public void record(
            UUID societyId,
            UUID actorId,
            String action,
            String entityType,
            String entityId,
            boolean sensitive,
            Map<String, ?> details) {
        var event = new AuditEvent();
        event.setSocietyId(societyId);
        event.setActorUserId(actorId);
        event.setAction(limit(action, 100));
        event.setEntityType(limit(entityType, 80));
        event.setEntityId(entityId == null ? null : limit(entityId, 100));
        event.setSensitive(sensitive);
        var storedDetails = new LinkedHashMap<String, Object>();
        if (details != null) {
            details.forEach((key, value) -> storedDetails.put(key, value));
        }
        if (actorId != null) {
            users.findById(actorId)
                    .ifPresent(
                            actor -> {
                                storedDetails.put("actor_name_snapshot", actor.getFullName());
                                storedDetails.put("actor_email_snapshot", actor.getEmail());
                            });
        }
        try {
            event.setDetails(json.write(storedDetails));
        } catch (JsonCodecException exception) {
            throw new IllegalStateException("Could not serialize audit details", exception);
        }
        event.setOccurredAt(OffsetDateTime.now());
        events.save(event);
    }

    public Map<String, Object> search(
            int page,
            int size,
            String action,
            String entityType,
            UUID societyId,
            UUID actorId,
            OffsetDateTime from,
            OffsetDateTime to,
            String search) {
        return search(page, size, action, entityType, societyId, actorId, from, to, search, null);
    }

    public Map<String, Object> search(
            int page,
            int size,
            String action,
            String entityType,
            UUID societyId,
            UUID actorId,
            OffsetDateTime from,
            OffsetDateTime to,
            String search,
            Boolean sensitive) {
        int safePage = Math.max(page, 0);
        int safeSize = Math.min(Math.max(size, 1), 100);
        var result =
                events.search(
                        new AuditQuery(
                                safePage,
                                safeSize,
                                action,
                                entityType,
                                societyId,
                                actorId,
                                from,
                                to,
                                search,
                                sensitive));
        var societyNames = new HashMap<UUID, String>();
        var actorNames = new HashMap<UUID, String>();
        societies
                .findAllById(
                        result.items().stream()
                                .map(AuditEvent::getSocietyId)
                                .filter(Objects::nonNull)
                                .collect(java.util.stream.Collectors.toSet()))
                .forEach(item -> societyNames.put(item.getId(), item.getName()));
        users.findAllById(
                        result.items().stream()
                                .map(AuditEvent::getActorUserId)
                                .filter(Objects::nonNull)
                                .collect(java.util.stream.Collectors.toSet()))
                .forEach(item -> actorNames.put(item.getId(), item.getFullName()));

        var items =
                result.items().stream()
                        .map(event -> view(event, societyNames, actorNames))
                        .toList();
        var response = new LinkedHashMap<String, Object>();
        response.put("items", items);
        response.put("page", result.page());
        response.put("size", result.size());
        response.put("total", result.totalElements());
        response.put("total_pages", result.totalPages());
        return response;
    }

    private Map<String, Object> view(
            AuditEvent event, Map<UUID, String> societyNames, Map<UUID, String> actorNames) {
        Object details = parseDetails(event.getDetails());
        String actorName = actorNames.get(event.getActorUserId());
        if (actorName == null && details instanceof Map<?, ?> detailMap) {
            actorName = Objects.toString(detailMap.get("actor_name_snapshot"), null);
        }
        var value = new LinkedHashMap<String, Object>();
        value.put("id", event.getId());
        value.put("society_id", event.getSocietyId());
        value.put("society_name", societyNames.get(event.getSocietyId()));
        value.put("actor_user_id", event.getActorUserId());
        value.put("actor_name", actorName);
        value.put("action", event.getAction());
        value.put("entity_type", event.getEntityType());
        value.put("entity_id", event.getEntityId());
        value.put("sensitive", event.isSensitive());
        value.put("details", details);
        value.put("occurred_at", event.getOccurredAt());
        return value;
    }

    private Object parseDetails(String details) {
        try {
            return json.readObject(details);
        } catch (JsonCodecException ignored) {
            return Map.of("raw", details);
        }
    }

    private String limit(String value, int maximum) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Audit action and entity type are required");
        }
        return value.length() <= maximum ? value : value.substring(0, maximum);
    }
}
