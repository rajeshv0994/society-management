package com.societyapp.application.port.in;

public interface StorageMeterUseCase {
    void register(
            java.util.UUID arg0,
            java.lang.String arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            java.lang.String arg4,
            long arg5);

    void attach(
            java.lang.String arg0,
            java.lang.String arg1,
            java.util.UUID arg2,
            java.lang.String arg3);

    void registerExisting(
            java.util.UUID arg0,
            java.lang.String arg1,
            java.lang.String arg2,
            java.lang.String arg3,
            long arg4);

    void markDeleted(com.societyapp.domain.model.StorageObject arg0, java.util.UUID arg1);

    com.societyapp.domain.model.StorageObject activeObject(
            java.util.UUID arg0, java.util.UUID arg1);

    java.util.Map<java.lang.String, java.lang.Object> updatePolicy(
            java.util.UUID arg0, int arg1, int arg2, java.math.BigDecimal arg3);

    java.util.Map<java.lang.String, java.lang.Object> purchase(
            java.util.UUID arg0, java.util.UUID arg1, int arg2);

    java.util.Map<java.lang.String, java.lang.Object> societyDashboard(java.util.UUID arg0);

    java.util.Map<java.lang.String, java.lang.Object> adminDashboard();

    java.math.BigDecimal monthlyAmount(java.util.UUID arg0);
}
