package com.societyapp.application.usecase;

import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.mapper.ApiViewMapper;
import com.societyapp.application.policy.ServiceCatalogPolicy;
import com.societyapp.application.port.in.PlatformAdminUseCase;
import com.societyapp.application.port.in.SubscriptionQuantityUseCase;
import com.societyapp.application.port.out.JsonCodec;
import com.societyapp.application.port.out.JsonCodecException;
import com.societyapp.application.port.out.PasswordCodec;
import com.societyapp.application.port.out.persistence.*;
import com.societyapp.domain.model.*;
import com.societyapp.domain.type.AccountStatus;
import com.societyapp.domain.type.ActivityStatus;
import com.societyapp.domain.type.ApprovalMode;
import com.societyapp.domain.type.DeliveryStatus;
import com.societyapp.domain.type.EmergencyIncidentStatus;
import com.societyapp.domain.type.IncidentSeverity;
import com.societyapp.domain.type.LifecycleStatus;
import com.societyapp.domain.type.ModerationStatus;
import com.societyapp.domain.type.NotificationStatus;
import com.societyapp.domain.type.PlatformServiceStatus;
import com.societyapp.domain.type.RequirementStatus;
import com.societyapp.domain.type.ServiceAvailabilityType;
import com.societyapp.domain.type.SetupCodeStatus;
import com.societyapp.domain.type.SocietyStatus;
import com.societyapp.domain.type.SubscriptionPlanCode;
import com.societyapp.domain.type.SubscriptionStatus;
import com.societyapp.domain.type.SupportPriority;
import com.societyapp.domain.type.SupportTicketStatus;
import com.societyapp.domain.type.TrialDurationUnit;
import com.societyapp.domain.type.UserRole;
import com.societyapp.domain.type.VerificationStatus;
import java.math.BigDecimal;
import java.security.SecureRandom;
import java.time.*;
import java.util.*;

public class PlatformAdminService implements PlatformAdminUseCase {
    private final SocietyRepository societies;
    private final SubscriptionPlanRepository plans;
    private final PlatformServiceModuleRepository serviceModules;
    private final SetupCodeRepository setupCodes;
    private final UserAccountJpaRepository users;
    private final SocietyDocumentRepository documents;
    private final BlockRepository blocks;
    private final FloorRepository floors;
    private final FlatRepository flats;
    private final ParkingSlotRepository parking;
    private final AmenityRepository amenities;
    private final HouseholdMemberRepository householdMembers;
    private final HouseholdVehicleRepository householdVehicles;
    private final HouseholdEmergencyContactRepository householdContacts;
    private final DeliveryRepository deliveries;
    private final EmergencyIncidentRepository emergencyIncidents;
    private final SocietyActivityRepository activities;
    private final ActivityParticipationRepository activityParticipations;
    private final ActivityGalleryPhotoRepository activityPhotos;
    private final SubscriptionOrderRepository orders;
    private final SocietyCustomPlanRepository customPlans;
    private final SupportTicketRepository tickets;
    private final SupportTicketMessageRepository ticketMessages;
    private final RequirementRequestRepository requirements;
    private final NotificationOutboxRepository notifications;
    private final AuditEventRepository audits;
    private final PasswordCodec passwords;
    private final JsonCodec json;
    private final ApiViewMapper views;
    private final ServiceCatalogPolicy serviceCatalog;
    private final SubscriptionQuantityUseCase subscriptionQuantities;
    private final SecureRandom random = new SecureRandom();

    public PlatformAdminService(
            SocietyRepository societies,
            SubscriptionPlanRepository plans,
            PlatformServiceModuleRepository serviceModules,
            SetupCodeRepository setupCodes,
            UserAccountJpaRepository users,
            SocietyDocumentRepository documents,
            BlockRepository blocks,
            FloorRepository floors,
            FlatRepository flats,
            ParkingSlotRepository parking,
            AmenityRepository amenities,
            HouseholdMemberRepository householdMembers,
            HouseholdVehicleRepository householdVehicles,
            HouseholdEmergencyContactRepository householdContacts,
            DeliveryRepository deliveries,
            EmergencyIncidentRepository emergencyIncidents,
            SocietyActivityRepository activities,
            ActivityParticipationRepository activityParticipations,
            ActivityGalleryPhotoRepository activityPhotos,
            SubscriptionOrderRepository orders,
            SocietyCustomPlanRepository customPlans,
            SupportTicketRepository tickets,
            SupportTicketMessageRepository ticketMessages,
            RequirementRequestRepository requirements,
            NotificationOutboxRepository notifications,
            AuditEventRepository audits,
            PasswordCodec passwords,
            JsonCodec json,
            ApiViewMapper views,
            ServiceCatalogPolicy serviceCatalog,
            SubscriptionQuantityUseCase subscriptionQuantities) {
        this.societies = societies;
        this.plans = plans;
        this.serviceModules = serviceModules;
        this.setupCodes = setupCodes;
        this.users = users;
        this.documents = documents;
        this.blocks = blocks;
        this.floors = floors;
        this.flats = flats;
        this.parking = parking;
        this.amenities = amenities;
        this.householdMembers = householdMembers;
        this.householdVehicles = householdVehicles;
        this.householdContacts = householdContacts;
        this.deliveries = deliveries;
        this.emergencyIncidents = emergencyIncidents;
        this.activities = activities;
        this.activityParticipations = activityParticipations;
        this.activityPhotos = activityPhotos;
        this.orders = orders;
        this.customPlans = customPlans;
        this.tickets = tickets;
        this.ticketMessages = ticketMessages;
        this.requirements = requirements;
        this.notifications = notifications;
        this.audits = audits;
        this.passwords = passwords;
        this.json = json;
        this.views = views;
        this.serviceCatalog = serviceCatalog;
        this.subscriptionQuantities = subscriptionQuantities;
    }

    public Map<String, Object> dashboard() {
        var societyList = societies.findAll();
        var customPlanSocietyIds =
                customPlans.findAll().stream()
                        .filter(plan -> LifecycleStatus.ACTIVE.matches(plan.getStatus()))
                        .map(SocietyCustomPlan::getSocietyId)
                        .collect(java.util.stream.Collectors.toSet());
        BigDecimal standardValue =
                societyList.stream()
                        .filter(society -> SocietyStatus.ACTIVE.matches(society.getStatus()))
                        .filter(society -> !customPlanSocietyIds.contains(society.getId()))
                        .map(
                                society ->
                                        plans.findById(society.getPlanCode())
                                                .map(
                                                        plan ->
                                                                plan.getPricePerSpace()
                                                                        .multiply(
                                                                                BigDecimal.valueOf(
                                                                                        society
                                                                                                .getTotalFlats()))
                                                                        .add(
                                                                                plan.getPricePerStaff()
                                                                                        .multiply(
                                                                                                BigDecimal
                                                                                                        .valueOf(
                                                                                                                society
                                                                                                                        .getPlannedStaff()))))
                                                .orElse(BigDecimal.ZERO))
                        .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal customValue =
                customPlans.findAll().stream()
                        .filter(plan -> LifecycleStatus.ACTIVE.matches(plan.getStatus()))
                        .map(
                                plan ->
                                        societies
                                                .findById(plan.getSocietyId())
                                                .map(
                                                        society ->
                                                                plan.getPricePerSpace()
                                                                        .multiply(
                                                                                BigDecimal.valueOf(
                                                                                        society
                                                                                                .getTotalFlats()))
                                                                        .add(
                                                                                plan.getPricePerStaff()
                                                                                        .multiply(
                                                                                                BigDecimal
                                                                                                        .valueOf(
                                                                                                                society
                                                                                                                        .getPlannedStaff()))))
                                                .orElse(BigDecimal.ZERO))
                        .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal serviceValue =
                societyList.stream()
                        .filter(society -> SocietyStatus.ACTIVE.matches(society.getStatus()))
                        .map(society -> serviceCatalog.servicePricing(society).monthlyAmount())
                        .reduce(BigDecimal.ZERO, BigDecimal::add);
        return Map.of(
                "total_societies", societyList.size(),
                "active_societies", countSocietyStatus(societyList, SocietyStatus.ACTIVE),
                "pending_approvals",
                        countSocietyStatus(societyList, SocietyStatus.PENDING_VERIFICATION),
                "active_members",
                        users.findAll().stream()
                                .filter(user -> UserRole.RESIDENT.matches(user.getRole()))
                                .filter(user -> AccountStatus.ACTIVE.matches(user.getStatus()))
                                .count(),
                "open_requirements",
                        requirements.findAll().stream()
                                .filter(
                                        item ->
                                                Set.of(
                                                                RequirementStatus.NEW.code(),
                                                                RequirementStatus.CONTACTED.code(),
                                                                RequirementStatus.ANALYSING.code())
                                                        .contains(item.getStatus()))
                                .count(),
                "open_tickets",
                        tickets.findAll().stream()
                                .filter(
                                        item ->
                                                Set.of(
                                                                SupportTicketStatus.OPEN.code(),
                                                                SupportTicketStatus.IN_PROGRESS
                                                                        .code())
                                                        .contains(item.getStatus()))
                                .count(),
                "failed_notifications",
                        notifications.findAll().stream()
                                .filter(item -> NotificationStatus.FAILED.matches(item.getStatus()))
                                .count(),
                "monthly_plan_value", standardValue.add(customValue).add(serviceValue));
    }

    public List<Map<String, Object>> societies(String status, String search) {
        String term = search == null ? null : search.toLowerCase(Locale.ROOT);
        var requestedStatus = status == null ? null : SocietyStatus.from(status);
        return societies.findAll().stream()
                .filter(
                        item ->
                                requestedStatus == null
                                        || requestedStatus.matches(item.getStatus()))
                .filter(
                        item ->
                                term == null
                                        || item.getName().toLowerCase(Locale.ROOT).contains(term)
                                        || item.getRegistrationNumber()
                                                .toLowerCase(Locale.ROOT)
                                                .contains(term))
                .sorted(Comparator.comparing(Society::getCreatedAt).reversed())
                .map(this::societySummary)
                .toList();
    }

    public Map<String, Object> createSociety(UUID actorId, CreateSociety command) {
        var enabledModules = serviceCatalog.normalizeSelection(command.enabledModules());
        String planCode = command.planCode().toUpperCase();
        var selectedPlan =
                plans.findById(planCode)
                        .orElseThrow(
                                () -> new ResourceNotFoundException("Subscription plan not found"));
        validatePlanQuantities(selectedPlan, command.totalFlats(), command.plannedStaff());
        var now = OffsetDateTime.now();
        var society = new Society();
        society.setName(command.name());
        society.setRegistrationNumber(generateRegistrationNumber());
        society.setSocietyCode(generateSocietyCode(command.name()));
        society.setSocietyType(command.societyType());
        society.setTotalBlocks(command.totalBlocks());
        society.setTotalFlats(command.totalFlats());
        society.setPlannedStaff(command.plannedStaff());
        society.setAddress(command.address());
        society.setCity(command.city());
        society.setState(command.state());
        society.setPinCode(command.pinCode());
        society.setContactPerson(command.contactPerson());
        society.setEmail(command.email());
        society.setMobile(command.mobile());
        society.setPlanCode(planCode);
        society.setEnabledModules(serviceCatalog.writeSelection(enabledModules));
        society.setStatus(SocietyStatus.APPROVED.code());
        society.setSubscriptionStatus(SubscriptionStatus.PENDING.code());
        society.setApprovedAt(now);
        society.setCreatedAt(now);
        society.setUpdatedAt(now);
        society = societies.save(society);
        UUID societyId = society.getId();
        String code = createSetupCode(societyId);
        var expiresAt =
                setupCodes.findByStatusOrderByCreatedAtDesc(SetupCodeStatus.ACTIVE.code()).stream()
                        .filter(item -> item.getSocietyId().equals(societyId))
                        .findFirst()
                        .orElseThrow()
                        .getExpiresAt();
        audit(actorId, "SOCIETY_CREATED", "SOCIETY", societyId.toString(), command.name());
        return Map.of(
                "societyId",
                societyId,
                "status",
                SocietyStatus.APPROVED.code(),
                "registrationNumber",
                society.getRegistrationNumber(),
                "enabledModules",
                enabledModules,
                "setupCode",
                code,
                "expiresAt",
                expiresAt);
    }

    public Map<String, Object> society(UUID societyId) {
        var society =
                societies
                        .findById(societyId)
                        .orElseThrow(() -> new ResourceNotFoundException("Society not found"));
        var result = new LinkedHashMap<String, Object>();
        var societyView = beanMap(society);
        societyView.put(
                "logo_url",
                society.getLogoStorageKey() == null
                        ? null
                        : "/api/public/societies/" + societyId + "/logo");
        plans.findById(society.getPlanCode())
                .ifPresent(
                        plan -> {
                            societyView.put("plan_name", plan.getName());
                            societyView.put("price_per_space", plan.getPricePerSpace());
                            societyView.put("price_per_staff", plan.getPricePerStaff());
                            societyView.put(
                                    "estimated_monthly_price",
                                    plan.getPricePerSpace()
                                            .multiply(BigDecimal.valueOf(society.getTotalFlats()))
                                            .add(
                                                    plan.getPricePerStaff()
                                                            .multiply(
                                                                    BigDecimal.valueOf(
                                                                            society
                                                                                    .getPlannedStaff()))));
                            societyView.put("max_flats", plan.getMaxFlats());
                            societyView.put("max_staff", plan.getMaxStaff());
                            societyView.put("trial_duration_months", plan.getTrialDurationMonths());
                            societyView.put("trial_duration_value", plan.getTrialDurationValue());
                            societyView.put("trial_duration_unit", plan.getTrialDurationUnit());
                        });
        result.put("society", societyView);
        var societyBlocks = blocks.findBySocietyIdOrderByName(societyId);
        long floorCount =
                societyBlocks.stream()
                        .mapToLong(
                                block ->
                                        floors.findByBlockIdOrderByFloorNumber(block.getId())
                                                .size())
                        .sum();
        long flatCount =
                societyBlocks.stream()
                        .flatMap(
                                block ->
                                        floors
                                                .findByBlockIdOrderByFloorNumber(block.getId())
                                                .stream())
                        .mapToLong(
                                floor -> flats.findByFloorIdOrderByFlatNumber(floor.getId()).size())
                        .sum();
        var hierarchy =
                societyBlocks.stream()
                        .map(
                                block -> {
                                    var blockView =
                                            new LinkedHashMap<String, Object>(views.toMap(block));
                                    blockView.put(
                                            "sections",
                                            floors
                                                    .findByBlockIdOrderByFloorNumber(block.getId())
                                                    .stream()
                                                    .map(
                                                            floor -> {
                                                                var floorView =
                                                                        new LinkedHashMap<
                                                                                String, Object>(
                                                                                views.toMap(floor));
                                                                floorView.put(
                                                                        "spaces",
                                                                        flats
                                                                                .findByFloorIdOrderByFlatNumber(
                                                                                        floor
                                                                                                .getId())
                                                                                .stream()
                                                                                .map(views::toMap)
                                                                                .toList());
                                                                return floorView;
                                                            })
                                                    .toList());
                                    return blockView;
                                })
                        .toList();
        var structure = new LinkedHashMap<String, Object>();
        structure.put("blocks", societyBlocks.size());
        structure.put("sections", floorCount);
        structure.put("spaces", flatCount);
        structure.put("parking_slots", parking.findBySocietyIdOrderBySlotNumber(societyId).size());
        structure.put("amenities", amenities.findBySocietyIdOrderByName(societyId).size());
        structure.put("hierarchy", hierarchy);
        result.put("structure", structure);
        result.put(
                "users",
                users.findAll().stream()
                        .filter(user -> societyId.equals(user.getSocietyId()))
                        .map(this::userView)
                        .toList());
        long residentCount =
                users
                        .findBySocietyIdAndRoleOrderByFullName(societyId, UserRole.RESIDENT.code())
                        .stream()
                        .filter(user -> AccountStatus.ACTIVE.matches(user.getStatus()))
                        .count();
        result.put(
                "household_summary",
                Map.of(
                        "households", residentCount,
                        "family_members", householdMembers.countBySocietyIdAndActiveTrue(societyId),
                        "vehicles", householdVehicles.countBySocietyIdAndActiveTrue(societyId),
                        "emergency_contacts",
                                householdContacts.countBySocietyIdAndActiveTrue(societyId),
                        "pending_verification",
                                householdMembers.countBySocietyIdAndActiveTrueAndVerificationStatus(
                                                societyId, VerificationStatus.PENDING.code())
                                        + householdVehicles
                                                .countBySocietyIdAndActiveTrueAndVerificationStatus(
                                                        societyId,
                                                        VerificationStatus.PENDING.code())));
        result.put(
                "delivery_summary",
                Map.of(
                        "total", deliveries.countBySocietyId(societyId),
                        "active",
                                deliveries.countBySocietyIdAndStatusIn(
                                        societyId,
                                        Set.of(
                                                DeliveryStatus.EXPECTED.code(),
                                                DeliveryStatus.RECEIVED.code(),
                                                DeliveryStatus.READY_FOR_PICKUP.code(),
                                                DeliveryStatus.OUT_FOR_DELIVERY.code(),
                                                DeliveryStatus.REJECTED.code(),
                                                DeliveryStatus.DAMAGED.code()))));
        var openEmergencyStatuses =
                Set.of(
                        EmergencyIncidentStatus.REPORTED.code(),
                        EmergencyIncidentStatus.ACKNOWLEDGED.code(),
                        EmergencyIncidentStatus.RESPONDING.code(),
                        EmergencyIncidentStatus.ON_SCENE.code(),
                        EmergencyIncidentStatus.STABILIZED.code());
        result.put(
                "emergency_summary",
                Map.of(
                        "total", emergencyIncidents.countBySocietyId(societyId),
                        "open",
                                emergencyIncidents.countBySocietyIdAndStatusIn(
                                        societyId, openEmergencyStatuses),
                        "critical",
                                emergencyIncidents.countBySocietyIdAndSeverityAndStatusIn(
                                        societyId,
                                        IncidentSeverity.CRITICAL.code(),
                                        openEmergencyStatuses)));
        result.put(
                "activity_summary",
                Map.of(
                        "total", activities.countBySocietyId(societyId),
                        "published",
                                activities.countBySocietyIdAndStatus(
                                        societyId, ActivityStatus.PUBLISHED.code()),
                        "participations", activityParticipations.countBySocietyId(societyId),
                        "published_photos",
                                activityPhotos.countBySocietyIdAndModerationStatus(
                                        societyId, ModerationStatus.PUBLISHED.code()),
                        "pending_photos",
                                activityPhotos.countBySocietyIdAndModerationStatus(
                                        societyId, ModerationStatus.PENDING.code())));
        result.put(
                "documents",
                documents.findBySocietyId(societyId).stream().map(views::toMap).toList());
        result.put(
                "orders",
                orders.findAll().stream()
                        .filter(order -> societyId.equals(order.getSocietyId()))
                        .map(views::toMap)
                        .toList());
        result.put(
                "customPlans",
                customPlans.findAll().stream()
                        .filter(plan -> societyId.equals(plan.getSocietyId()))
                        .map(views::toMap)
                        .toList());
        result.put(
                "support",
                tickets.findBySocietyIdOrderByCreatedAtDesc(societyId).stream()
                        .map(views::toMap)
                        .toList());
        result.put(
                "requirements",
                requirements.findBySocietyIdOrderByCreatedAtDesc(societyId).stream()
                        .map(views::toMap)
                        .toList());
        result.put(
                "notifications",
                notifications.findBySocietyIdOrderByCreatedAtDesc(societyId).stream()
                        .map(views::toMap)
                        .toList());
        result.put(
                "audit_events",
                audits.findBySocietyIdOrderByOccurredAtDesc(societyId).stream()
                        .map(views::toMap)
                        .toList());
        return result;
    }

    public Map<String, Object> updateSociety(UUID actorId, UUID societyId, UpdateSociety command) {
        var enabledModules = serviceCatalog.normalizeSelection(command.enabledModules());
        String plan = command.planCode().toUpperCase();
        var selectedPlan =
                plans.findById(plan)
                        .orElseThrow(
                                () -> new ResourceNotFoundException("Subscription plan not found"));
        var society =
                societies
                        .findById(societyId)
                        .orElseThrow(() -> new ResourceNotFoundException("Society not found"));
        validatePlanQuantities(selectedPlan, society.getTotalFlats(), command.plannedStaff());
        society.setName(command.name());
        society.setDescription(command.description());
        society.setWebsite(command.website());
        society.setContactPerson(command.contactPerson());
        society.setEmail(command.email());
        society.setMobile(command.mobile());
        society.setAddress(command.address());
        society.setCity(command.city());
        society.setState(command.state());
        society.setPinCode(command.pinCode());
        society.setPlanCode(plan);
        society.setPlannedStaff(command.plannedStaff());
        society.setEnabledModules(serviceCatalog.writeSelection(enabledModules));
        society.setStatus(command.status());
        society.setUpdatedAt(OffsetDateTime.now());
        societies.save(society);
        audit(actorId, "SOCIETY_UPDATED", "SOCIETY", societyId.toString(), command.name());
        return Map.of(
                "societyId",
                societyId,
                "status",
                command.status(),
                "planCode",
                plan,
                "enabledModules",
                enabledModules,
                "updated",
                true);
    }

    public List<Map<String, Object>> plans() {
        return plans.findAll().stream()
                .filter(
                        plan ->
                                SubscriptionPlanCode.TRIAL.matches(plan.getCode())
                                        || SubscriptionPlanCode.STANDARD.matches(plan.getCode()))
                .sorted(Comparator.comparing(SubscriptionPlan::getPricePerSpace))
                .map(
                        plan -> {
                            var map = beanMap(plan);
                            map.put(
                                    "society_count",
                                    societies.findAll().stream()
                                            .filter(
                                                    society ->
                                                            plan.getCode()
                                                                    .equals(society.getPlanCode()))
                                            .count());
                            return map;
                        })
                .toList();
    }

    public List<Map<String, Object>> services() {
        return serviceModules.findAllByOrderBySortOrderAscNameAsc().stream()
                .map(
                        service -> {
                            var row = new LinkedHashMap<String, Object>(views.toMap(service));
                            var selectedSocieties =
                                    societies.findAll().stream()
                                            .filter(
                                                    society ->
                                                            serviceCatalog
                                                                    .selected(society)
                                                                    .contains(service.getCode()))
                                            .toList();
                            row.put("selected_society_count", selectedSocieties.size());
                            row.put(
                                    "projected_monthly_revenue",
                                    ServiceAvailabilityType.PAID_PER_SPACE.matches(
                                                    service.getAvailabilityType())
                                            ? selectedSocieties.stream()
                                                    .map(
                                                            society ->
                                                                    service.getPricePerSpace()
                                                                            .multiply(
                                                                                    BigDecimal
                                                                                            .valueOf(
                                                                                                    society
                                                                                                            .getTotalFlats())))
                                                    .reduce(BigDecimal.ZERO, BigDecimal::add)
                                            : BigDecimal.ZERO);
                            return (Map<String, Object>) row;
                        })
                .toList();
    }

    public Map<String, Object> createService(
            UUID actorId,
            String code,
            String name,
            String description,
            String status,
            int sortOrder,
            String availabilityType,
            BigDecimal pricePerSpace) {
        String normalizedCode = code.trim().toUpperCase(Locale.ROOT);
        if (serviceModules.existsById(normalizedCode)) {
            throw new IllegalArgumentException("Service code already exists");
        }
        var module = new PlatformServiceModule();
        module.setCode(normalizedCode);
        module.setName(name.trim());
        module.setDescription(description);
        applyServiceCommercialPolicy(module, status, availabilityType, pricePerSpace);
        module.setSortOrder(sortOrder);
        module.setCreatedAt(OffsetDateTime.now());
        module.setUpdatedAt(OffsetDateTime.now());
        serviceModules.save(module);
        synchronizeServiceAvailability(module);
        audit(actorId, "SERVICE_CREATED", "PLATFORM_SERVICE", normalizedCode, name);
        return beanMap(module);
    }

    public Map<String, Object> updateService(
            UUID actorId,
            String code,
            String name,
            String description,
            String status,
            int sortOrder,
            String availabilityType,
            BigDecimal pricePerSpace) {
        String normalizedCode = code.trim().toUpperCase(Locale.ROOT);
        var module =
                serviceModules
                        .findById(normalizedCode)
                        .orElseThrow(() -> new ResourceNotFoundException("Service not found"));
        module.setName(name.trim());
        module.setDescription(description);
        applyServiceCommercialPolicy(module, status, availabilityType, pricePerSpace);
        module.setSortOrder(sortOrder);
        module.setUpdatedAt(OffsetDateTime.now());
        serviceModules.save(module);
        synchronizeServiceAvailability(module);
        audit(actorId, "SERVICE_UPDATED", "PLATFORM_SERVICE", normalizedCode, name);
        return beanMap(module);
    }

    public Map<String, Object> updatePlan(
            UUID actorId,
            String code,
            String name,
            String approvalMode,
            Integer maxFlats,
            BigDecimal pricePerSpace,
            Integer maxStaff,
            BigDecimal pricePerStaff,
            Integer trialDurationValue,
            String trialDurationUnit,
            Integer trialDurationMonths) {
        var plan =
                plans.findById(code.toUpperCase())
                        .orElseThrow(() -> new ResourceNotFoundException("Plan not found"));
        if (name != null && !name.isBlank()) {
            plan.setName(name);
        }
        plan.setApprovalMode(ApprovalMode.from(approvalMode).code());
        plan.setMaxFlats(maxFlats);
        plan.setPricePerSpace(pricePerSpace);
        plan.setMaxStaff(maxStaff);
        plan.setPricePerStaff(pricePerStaff);
        plan.setPriceMonthly(BigDecimal.ZERO);
        int duration =
                trialDurationValue != null
                        ? trialDurationValue
                        : trialDurationMonths != null ? trialDurationMonths : 1;
        String durationUnit =
                trialDurationUnit != null
                        ? trialDurationUnit
                        : trialDurationMonths != null
                                ? TrialDurationUnit.MONTHS.code()
                                : plan.getTrialDurationUnit();
        var requestedDurationUnit = TrialDurationUnit.from(durationUnit);
        plan.setTrialDurationValue(duration);
        plan.setTrialDurationUnit(requestedDurationUnit.code());
        plan.setTrialDurationMonths(
                requestedDurationUnit == TrialDurationUnit.MONTHS ? duration : 1);
        plans.save(plan);
        audit(actorId, "PLAN_UPDATED", "SUBSCRIPTION_PLAN", code, "Billing rates updated");
        return Map.of("code", code.toUpperCase(), "updated", true);
    }

    public List<Map<String, Object>> orders() {
        return orders.findAllByOrderByCreatedAtDesc().stream()
                .map(
                        order -> {
                            var map = beanMap(order);
                            map.put(
                                    "society_name",
                                    societies
                                            .findById(order.getSocietyId())
                                            .map(Society::getName)
                                            .orElse(null));
                            return map;
                        })
                .toList();
    }

    public List<Map<String, Object>> notifications(String status) {
        var requestedStatus = status == null ? null : NotificationStatus.from(status);
        return notifications.findAllByOrderByCreatedAtDesc().stream()
                .filter(
                        item ->
                                requestedStatus == null
                                        || requestedStatus.matches(item.getStatus()))
                .limit(500)
                .map(
                        item -> {
                            var map = beanMap(item);
                            map.put(
                                    "society_name",
                                    item.getSocietyId() == null
                                            ? null
                                            : societies
                                                    .findById(item.getSocietyId())
                                                    .map(Society::getName)
                                                    .orElse(null));
                            return map;
                        })
                .toList();
    }

    public Map<String, Object> retry(UUID id) {
        var notification =
                notifications
                        .findById(id)
                        .filter(item -> NotificationStatus.FAILED.matches(item.getStatus()))
                        .orElseThrow(
                                () ->
                                        new IllegalStateException(
                                                "Only failed notifications can be retried"));
        notification.setStatus(NotificationStatus.PENDING.code());
        notification.setLastError(null);
        notifications.save(notification);
        return Map.of("id", id, "status", NotificationStatus.PENDING.code());
    }

    public List<Map<String, Object>> audit() {
        return audits.findAll().stream()
                .sorted(Comparator.comparing(AuditEvent::getOccurredAt).reversed())
                .limit(500)
                .map(
                        event -> {
                            var map = beanMap(event);
                            map.put(
                                    "society_name",
                                    event.getSocietyId() == null
                                            ? null
                                            : societies
                                                    .findById(event.getSocietyId())
                                                    .map(Society::getName)
                                                    .orElse(null));
                            map.put(
                                    "actor_name",
                                    event.getActorUserId() == null
                                            ? null
                                            : users.findById(event.getActorUserId())
                                                    .map(UserAccount::getFullName)
                                                    .orElse(null));
                            return map;
                        })
                .toList();
    }

    public List<Map<String, Object>> tickets() {
        return tickets.findAllByOrderByCreatedAtDesc().stream()
                .sorted(Comparator.comparingInt(this::priorityOrder))
                .map(this::ticketView)
                .toList();
    }

    public Map<String, Object> updateTicket(
            UUID actorId, UUID ticketId, String status, String resolution) {
        var ticket =
                tickets.findById(ticketId)
                        .orElseThrow(() -> new ResourceNotFoundException("Ticket not found"));
        var requestedStatus = SupportTicketStatus.from(status);
        ticket.setStatus(requestedStatus.code());
        if (resolution != null) ticket.setResolution(resolution);
        ticket.setAssignedTo(actorId);
        ticket.setUpdatedAt(OffsetDateTime.now());
        ticket.setClosedAt(
                requestedStatus == SupportTicketStatus.RESOLVED
                                || requestedStatus == SupportTicketStatus.CLOSED
                        ? OffsetDateTime.now()
                        : null);
        tickets.save(ticket);
        return Map.of("id", ticketId, "status", requestedStatus.code());
    }

    private Map<String, Object> societySummary(Society society) {
        var map = beanMap(society);
        map.put("document_count", documents.findBySocietyId(society.getId()).size());
        map.put(
                "configured_flat_count",
                blocks.findBySocietyIdOrderByName(society.getId()).stream()
                        .flatMap(
                                block ->
                                        floors
                                                .findByBlockIdOrderByFloorNumber(block.getId())
                                                .stream())
                        .mapToLong(
                                floor -> flats.findByFloorIdOrderByFlatNumber(floor.getId()).size())
                        .sum());
        map.put("configured_unit_count", map.get("configured_flat_count"));
        map.put("configured_space_count", map.get("configured_flat_count"));
        map.put(
                "active_member_count",
                users.findAll().stream()
                        .filter(user -> society.getId().equals(user.getSocietyId()))
                        .filter(user -> UserRole.RESIDENT.matches(user.getRole()))
                        .filter(user -> AccountStatus.ACTIVE.matches(user.getStatus()))
                        .count());
        var subscription = subscriptionQuantities.get(society.getId());
        map.put("subscription_estimated_monthly", subscription.get("estimated_monthly_price"));
        map.put("subscription_service_monthly", subscription.get("service_monthly_price"));
        return map;
    }

    private Map<String, Object> userView(UserAccount user) {
        var map = new LinkedHashMap<String, Object>();
        map.put("id", user.getId());
        map.put("full_name", user.getFullName());
        map.put("email", user.getEmail());
        map.put("mobile", user.getMobile());
        map.put("role", user.getRole());
        map.put("status", user.getStatus());
        map.put("created_at", user.getCreatedAt());
        return map;
    }

    private Map<String, Object> ticketView(SupportTicket ticket) {
        var map = beanMap(ticket);
        map.put(
                "society_name",
                ticket.getSocietyId() == null
                        ? null
                        : societies
                                .findById(ticket.getSocietyId())
                                .map(Society::getName)
                                .orElse(null));
        map.put(
                "created_by_name",
                ticket.getCreatedBy() == null
                        ? null
                        : users.findById(ticket.getCreatedBy())
                                .map(UserAccount::getFullName)
                                .orElse(null));
        map.put(
                "message_count",
                ticketMessages.findByTicketIdOrderByCreatedAt(ticket.getId()).size());
        return map;
    }

    private String createSetupCode(UUID societyId) {
        String raw =
                "SOC-"
                        + Year.now().getValue()
                        + "-"
                        + randomPart(4)
                        + "-"
                        + (1000 + random.nextInt(9000));
        var setup = new SetupCode();
        setup.setSocietyId(societyId);
        setup.setCodeHash(passwords.encode(raw));
        setup.setCodeHint(raw.substring(raw.length() - 4));
        setup.setExpiresAt(OffsetDateTime.now().plusDays(7));
        setup.setMaxActivations(1);
        setup.setActivationCount(0);
        setup.setStatus(SetupCodeStatus.ACTIVE.code());
        setup.setCreatedAt(OffsetDateTime.now());
        setupCodes.save(setup);
        return raw;
    }

    private void audit(UUID actorId, String action, String type, String entityId, String name) {
        var event = new AuditEvent();
        event.setActorUserId(actorId);
        event.setAction(action);
        event.setEntityType(type);
        event.setEntityId(entityId);
        try {
            event.setDetails(json.write(Map.of("name", name)));
        } catch (JsonCodecException exception) {
            throw new IllegalStateException("Could not serialize audit details", exception);
        }
        event.setOccurredAt(OffsetDateTime.now());
        audits.save(event);
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> beanMap(Object value) {
        return views.toMap(value);
    }

    private long countSocietyStatus(List<Society> values, SocietyStatus status) {
        return values.stream().filter(item -> status.matches(item.getStatus())).count();
    }

    private void validatePlanQuantities(SubscriptionPlan plan, int spaceCount, int staffCount) {
        if (plan.getMaxFlats() != null && spaceCount > plan.getMaxFlats()) {
            throw new IllegalArgumentException(
                    "Plan allows at most " + plan.getMaxFlats() + " spaces");
        }
        if (plan.getMaxStaff() != null && staffCount > plan.getMaxStaff()) {
            throw new IllegalArgumentException(
                    "Plan allows at most " + plan.getMaxStaff() + " staff members");
        }
    }

    private int priorityOrder(SupportTicket ticket) {
        return SupportPriority.from(ticket.getPriority()).order();
    }

    private String randomPart(int size) {
        String chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        var result = new StringBuilder();
        for (int index = 0; index < size; index++) {
            result.append(chars.charAt(random.nextInt(chars.length())));
        }
        return result.toString();
    }

    private String generateSocietyCode(String name) {
        String base =
                name.toUpperCase(Locale.ROOT)
                        .replaceAll("[^A-Z0-9]+", "-")
                        .replaceAll("(^-|-$)", "");
        if (base.isBlank()) base = "SOCIETY";
        if (base.length() > 20) base = base.substring(0, 20);
        String candidate = base;
        while (societies.existsBySocietyCodeIgnoreCase(candidate)) {
            candidate = base + "-" + randomPart(4);
        }
        return candidate;
    }

    private String generateRegistrationNumber() {
        String candidate;
        do {
            candidate = "REG-" + Year.now().getValue() + "-" + randomPart(6);
        } while (societies.existsByRegistrationNumberIgnoreCase(candidate));
        return candidate;
    }

    private void applyServiceCommercialPolicy(
            PlatformServiceModule module,
            String status,
            String availabilityType,
            BigDecimal pricePerSpace) {
        var requestedStatus = PlatformServiceStatus.from(status);
        var requestedType = ServiceAvailabilityType.from(availabilityType);
        if (requestedType == ServiceAvailabilityType.DEFAULT_FREE
                && requestedStatus != PlatformServiceStatus.ACTIVE) {
            throw new IllegalArgumentException("A default service must remain active");
        }
        var rate = pricePerSpace == null ? BigDecimal.ZERO : pricePerSpace;
        if (requestedType == ServiceAvailabilityType.PAID_PER_SPACE) {
            if (rate.signum() <= 0) {
                throw new IllegalArgumentException(
                        "A paid service requires a positive per-space price");
            }
        } else if (rate.signum() != 0) {
            throw new IllegalArgumentException("Free services must have a zero price");
        }
        module.setStatus(requestedStatus.code());
        module.setAvailabilityType(requestedType.code());
        module.setPricePerSpace(rate);
    }

    private void synchronizeServiceAvailability(PlatformServiceModule module) {
        boolean addDefault =
                PlatformServiceStatus.ACTIVE.matches(module.getStatus())
                        && ServiceAvailabilityType.DEFAULT_FREE.matches(
                                module.getAvailabilityType());
        boolean removeUnavailable = !PlatformServiceStatus.ACTIVE.matches(module.getStatus());
        if (!addDefault && !removeUnavailable) {
            return;
        }
        for (var society : societies.findAll()) {
            var selected = new LinkedHashSet<>(serviceCatalog.selected(society));
            if (addDefault) selected.add(module.getCode());
            if (removeUnavailable) selected.remove(module.getCode());
            society.setEnabledModules(
                    serviceCatalog.writeSelection(
                            serviceModules.findAllByOrderBySortOrderAscNameAsc().stream()
                                    .map(PlatformServiceModule::getCode)
                                    .filter(selected::contains)
                                    .toList()));
            society.setUpdatedAt(OffsetDateTime.now());
            societies.save(society);
        }
    }
}
