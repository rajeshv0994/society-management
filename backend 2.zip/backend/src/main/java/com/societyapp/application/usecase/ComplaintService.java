package com.societyapp.application.usecase;

import com.societyapp.application.exception.AuthorizationException;
import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.port.in.ComplaintUseCase;
import com.societyapp.application.port.in.StructureAccessUseCase;
import com.societyapp.application.port.out.persistence.*;
import com.societyapp.domain.model.*;
import com.societyapp.domain.type.AccountStatus;
import com.societyapp.domain.type.ComplaintStatus;
import com.societyapp.domain.type.StaffPermissionCode;
import com.societyapp.domain.type.UserRole;
import com.societyapp.domain.type.WorkPriority;
import java.time.OffsetDateTime;
import java.util.*;

public class ComplaintService implements ComplaintUseCase {
    private final ComplaintRepository complaints;
    private final ComplaintUpdateRepository updates;
    private final ComplaintCategoryRepository categories;
    private final UserAccountJpaRepository users;
    private final StaffPermissionRepository permissions;
    private final FlatRepository flats;
    private final FloorRepository floors;
    private final BlockRepository blocks;
    private final StructureAccessUseCase structure;

    public ComplaintService(
            ComplaintRepository complaints,
            ComplaintUpdateRepository updates,
            ComplaintCategoryRepository categories,
            UserAccountJpaRepository users,
            StaffPermissionRepository permissions,
            FlatRepository flats,
            FloorRepository floors,
            BlockRepository blocks,
            StructureAccessUseCase structure) {
        this.complaints = complaints;
        this.updates = updates;
        this.categories = categories;
        this.users = users;
        this.permissions = permissions;
        this.flats = flats;
        this.floors = floors;
        this.blocks = blocks;
        this.structure = structure;
    }

    public List<Map<String, Object>> list(UUID societyId, UUID userId, String role) {
        if (UserRole.STAFF.matches(role)) requireStaffPermission(userId);
        return complaints.findBySocietyIdOrderByCreatedAtDesc(societyId).stream()
                .filter(
                        complaint ->
                                switch (UserRole.from(role)) {
                                    case RESIDENT ->
                                            userId.equals(complaint.getResidentId())
                                                    || (complaint.getResidentId() == null
                                                            && userId.equals(
                                                                    complaint.getRaisedBy()));
                                    case STAFF ->
                                            userId.equals(complaint.getAssignedTo())
                                                    || userId.equals(complaint.getCreatedBy());
                                    default -> true;
                                })
                .map(this::view)
                .toList();
    }

    public Map<String, Object> options(UUID societyId, UUID userId, String role) {
        if (UserRole.STAFF.matches(role)) requireStaffPermission(userId);
        var result = new LinkedHashMap<String, Object>();
        result.put("current_user_id", userId);
        result.put(
                "categories",
                categories.findBySocietyIdOrderByName(societyId).stream()
                        .filter(ComplaintCategory::isActive)
                        .map(
                                category ->
                                        Map.of(
                                                "id", category.getId(),
                                                "name", category.getName(),
                                                "sla_hours", category.getSlaHours()))
                        .toList());
        if (UserRole.RESIDENT.matches(role)) {
            result.put("residents", List.of());
            result.put("staff", List.of());
            result.put("spaces", residentSpaces(societyId, userId));
        } else {
            result.put("residents", residentOptions(societyId));
            result.put(
                    "staff",
                    users
                            .findBySocietyIdAndRoleOrderByFullName(societyId, UserRole.STAFF.code())
                            .stream()
                            .filter(user -> AccountStatus.ACTIVE.matches(user.getStatus()))
                            .filter(
                                    user ->
                                            permissions.existsByStaffUserIdAndPermissionCode(
                                                    user.getId(),
                                                    StaffPermissionCode.COMPLAINTS.code()))
                            .map(
                                    user -> {
                                        var row = new LinkedHashMap<String, Object>();
                                        row.put("id", user.getId());
                                        row.put("full_name", user.getFullName());
                                        row.put("mobile", user.getMobile());
                                        return (Map<String, Object>) row;
                                    })
                            .toList());
        }
        return result;
    }

    public Map<String, Object> detail(UUID societyId, UUID userId, String role, UUID id) {
        var complaint = requireVisible(societyId, userId, role, id);
        var result = new LinkedHashMap<String, Object>(view(complaint));
        result.put(
                "timeline",
                updates.findByComplaintIdOrderByCreatedAt(id).stream()
                        .map(this::updateView)
                        .toList());
        return result;
    }

    public Map<String, Object> create(
            UUID societyId,
            UUID actorId,
            String role,
            UUID residentId,
            UUID flatId,
            UUID categoryId,
            UUID assignedTo,
            String title,
            String description,
            String priority) {
        if (UserRole.STAFF.matches(role)) requireStaffPermission(actorId);
        if (UserRole.STAFF.matches(role) && assignedTo != null && !actorId.equals(assignedTo)) {
            throw new AuthorizationException("Staff can only assign a complaint to themselves");
        }
        UUID targetResident = UserRole.RESIDENT.matches(role) ? actorId : residentId;
        if (targetResident == null) {
            throw new IllegalArgumentException("Resident is required");
        }
        var resident =
                users.findById(targetResident)
                        .filter(user -> societyId.equals(user.getSocietyId()))
                        .filter(user -> UserRole.RESIDENT.matches(user.getRole()))
                        .orElseThrow(() -> new ResourceNotFoundException("Resident not found"));
        UUID targetFlat = resolveResidentFlat(societyId, resident.getId(), flatId);
        ComplaintCategory category = null;
        if (categoryId != null) {
            category =
                    categories
                            .findById(categoryId)
                            .filter(item -> societyId.equals(item.getSocietyId()))
                            .filter(ComplaintCategory::isActive)
                            .orElseThrow(
                                    () ->
                                            new ResourceNotFoundException(
                                                    "Complaint category not found"));
        }
        if (assignedTo != null) requireAssignableStaff(societyId, assignedTo);
        var now = OffsetDateTime.now();
        var complaint = new Complaint();
        complaint.setSocietyId(societyId);
        complaint.setRaisedBy(actorId);
        complaint.setCreatedBy(actorId);
        complaint.setResidentId(resident.getId());
        complaint.setFlatId(targetFlat);
        complaint.setCategoryId(categoryId);
        complaint.setTitle(title);
        complaint.setDescription(description);
        complaint.setPriority(
                WorkPriority.from(priority == null ? WorkPriority.NORMAL.code() : priority).code());
        complaint.setAssignedTo(assignedTo);
        complaint.setStatus(
                assignedTo == null ? ComplaintStatus.OPEN.code() : ComplaintStatus.ASSIGNED.code());
        complaint.setDueAt(
                category == null ? now.plusHours(48) : now.plusHours(category.getSlaHours()));
        complaint.setCreatedAt(now);
        complaint.setUpdatedAt(now);
        complaint = complaints.save(complaint);
        addUpdate(
                complaint.getId(),
                actorId,
                "CREATED",
                null,
                complaint.getStatus(),
                "Complaint created for " + resident.getFullName());
        return Map.of("id", complaint.getId(), "status", complaint.getStatus());
    }

    public Map<String, Object> update(
            UUID societyId,
            UUID actorId,
            String role,
            UUID id,
            String status,
            UUID assignedTo,
            String note,
            String resolution) {
        var complaint = requireVisible(societyId, actorId, role, id);
        if (UserRole.RESIDENT.matches(role)) {
            throw new AuthorizationException("Residents can add comments but cannot change status");
        }
        if (UserRole.STAFF.matches(role) && assignedTo != null && !actorId.equals(assignedTo)) {
            throw new AuthorizationException("Staff can only assign a complaint to themselves");
        }
        var previous = ComplaintStatus.from(complaint.getStatus());
        UUID previousAssignee = complaint.getAssignedTo();
        if (assignedTo != null) {
            requireAssignableStaff(societyId, assignedTo);
            complaint.setAssignedTo(assignedTo);
            if ((status == null || ComplaintStatus.OPEN.matches(status))
                    && previous == ComplaintStatus.OPEN) {
                status = ComplaintStatus.ASSIGNED.code();
            }
        }
        var next = status == null ? previous : ComplaintStatus.from(status);
        validateTransition(previous, next);
        String effectiveResolution =
                resolution == null || resolution.isBlank() ? complaint.getResolution() : resolution;
        if (next.isTerminal() && (effectiveResolution == null || effectiveResolution.isBlank())) {
            throw new IllegalArgumentException("Resolution is required to resolve or close");
        }
        boolean assignmentChanged = !Objects.equals(previousAssignee, complaint.getAssignedTo());
        boolean statusChanged = previous != next;
        boolean hasNote = note != null && !note.isBlank();
        boolean hasResolution = resolution != null && !resolution.isBlank();
        if (!assignmentChanged && !statusChanged && !hasNote && !hasResolution) {
            throw new IllegalArgumentException("Add a progress note or change the complaint");
        }
        complaint.setStatus(next.code());
        if (hasResolution) complaint.setResolution(resolution);
        complaint.setUpdatedAt(OffsetDateTime.now());
        complaint.setClosedAt(next.isTerminal() ? OffsetDateTime.now() : null);
        complaints.save(complaint);
        String event =
                statusChanged
                        ? "STATUS_CHANGED"
                        : assignmentChanged ? "ASSIGNMENT_CHANGED" : "PROGRESS_NOTE";
        if (assignmentChanged && !hasNote) {
            note = "Complaint assigned to " + assignedToName(complaint.getAssignedTo());
        }
        addUpdate(id, actorId, event, previous.code(), next.code(), note);
        return Map.of("id", id, "status", next.code());
    }

    public Map<String, Object> comment(
            UUID societyId, UUID actorId, String role, UUID id, String note) {
        requireVisible(societyId, actorId, role, id);
        addUpdate(id, actorId, "COMMENT", null, null, note);
        var complaint = complaints.findByIdAndSocietyId(id, societyId).orElseThrow();
        complaint.setUpdatedAt(OffsetDateTime.now());
        complaints.save(complaint);
        return Map.of("id", id, "commented", true);
    }

    private Complaint requireVisible(UUID societyId, UUID userId, String role, UUID id) {
        if (UserRole.STAFF.matches(role)) requireStaffPermission(userId);
        return complaints
                .findByIdAndSocietyId(id, societyId)
                .filter(
                        complaint ->
                                switch (UserRole.from(role)) {
                                    case RESIDENT ->
                                            userId.equals(complaint.getResidentId())
                                                    || (complaint.getResidentId() == null
                                                            && userId.equals(
                                                                    complaint.getRaisedBy()));
                                    case STAFF ->
                                            userId.equals(complaint.getAssignedTo())
                                                    || userId.equals(complaint.getCreatedBy());
                                    default -> true;
                                })
                .orElseThrow(() -> new ResourceNotFoundException("Complaint not found"));
    }

    private void requireStaffPermission(UUID staffId) {
        if (!permissions.existsByStaffUserIdAndPermissionCode(
                staffId, StaffPermissionCode.COMPLAINTS.code())) {
            throw new AuthorizationException("Complaints permission is required");
        }
    }

    private void requireAssignableStaff(UUID societyId, UUID staffId) {
        users.findById(staffId)
                .filter(user -> societyId.equals(user.getSocietyId()))
                .filter(user -> UserRole.STAFF.matches(user.getRole()))
                .filter(user -> AccountStatus.ACTIVE.matches(user.getStatus()))
                .filter(
                        user ->
                                permissions.existsByStaffUserIdAndPermissionCode(
                                        user.getId(), StaffPermissionCode.COMPLAINTS.code()))
                .orElseThrow(
                        () ->
                                new ResourceNotFoundException(
                                        "Active staff with Complaints permission not found"));
    }

    private String assignedToName(UUID staffId) {
        if (staffId == null) return "Unassigned";
        return users.findById(staffId).map(UserAccount::getFullName).orElse("Staff");
    }

    private UUID resolveResidentFlat(UUID societyId, UUID residentId, UUID requestedFlat) {
        if (requestedFlat != null) {
            structure.requireFlat(requestedFlat, societyId);
            if (!structure.occupiedBy(requestedFlat, residentId)) {
                throw new IllegalArgumentException("Resident does not occupy the selected space");
            }
            return requestedFlat;
        }
        return flats.findAll().stream()
                .filter(flat -> structure.belongsToSociety(flat.getId(), societyId))
                .filter(
                        flat ->
                                residentId.equals(flat.getActiveOwnerId())
                                        || residentId.equals(flat.getActiveTenantId()))
                .map(Flat::getId)
                .findFirst()
                .orElseThrow(
                        () -> new IllegalArgumentException("Resident is not assigned to a space"));
    }

    private List<Map<String, Object>> residentOptions(UUID societyId) {
        var result = new ArrayList<Map<String, Object>>();
        for (var resident :
                users.findBySocietyIdAndRoleOrderByFullName(societyId, UserRole.RESIDENT.code())) {
            if (!AccountStatus.ACTIVE.matches(resident.getStatus())) continue;
            for (var space : residentSpaces(societyId, resident.getId())) {
                var row = new LinkedHashMap<String, Object>(space);
                row.put("resident_id", resident.getId());
                row.put("full_name", resident.getFullName());
                row.put("mobile", resident.getMobile());
                result.add(row);
            }
        }
        return result;
    }

    private List<Map<String, Object>> residentSpaces(UUID societyId, UUID residentId) {
        return flats.findAll().stream()
                .filter(flat -> structure.belongsToSociety(flat.getId(), societyId))
                .filter(
                        flat ->
                                residentId.equals(flat.getActiveOwnerId())
                                        || residentId.equals(flat.getActiveTenantId()))
                .map(
                        flat -> {
                            var row = new LinkedHashMap<String, Object>();
                            row.put("space_id", flat.getId());
                            row.put("space_number", flat.getFlatNumber());
                            floors.findById(flat.getFloorId())
                                    .flatMap(floor -> blocks.findById(floor.getBlockId()))
                                    .ifPresent(block -> row.put("block", block.getName()));
                            return (Map<String, Object>) row;
                        })
                .toList();
    }

    private void validateTransition(ComplaintStatus from, ComplaintStatus to) {
        if (from == to) return;
        if (!from.allowedTransitions().contains(to)) {
            throw new IllegalStateException("Invalid complaint status transition");
        }
    }

    private void addUpdate(
            UUID complaintId, UUID actorId, String event, String from, String to, String note) {
        var update = new ComplaintUpdate();
        update.setComplaintId(complaintId);
        update.setActorUserId(actorId);
        update.setEventType(event);
        update.setFromStatus(from);
        update.setToStatus(to);
        update.setNote(note);
        update.setCreatedAt(OffsetDateTime.now());
        updates.save(update);
    }

    private Map<String, Object> view(Complaint item) {
        var result = new LinkedHashMap<String, Object>();
        result.put("id", item.getId());
        result.put("reference", "CMP-" + item.getId().toString().substring(0, 8).toUpperCase());
        result.put("resident_id", item.getResidentId());
        result.put("space_id", item.getFlatId());
        result.put("category_id", item.getCategoryId());
        result.put("title", item.getTitle());
        result.put("description", item.getDescription());
        result.put("priority", item.getPriority());
        result.put("status", item.getStatus());
        result.put("assigned_to", item.getAssignedTo());
        result.put("resolution", item.getResolution());
        result.put("created_at", item.getCreatedAt());
        result.put("updated_at", item.getUpdatedAt());
        result.put("due_at", item.getDueAt());
        result.put("closed_at", item.getClosedAt());
        result.put(
                "overdue",
                item.getDueAt() != null
                        && item.getDueAt().isBefore(OffsetDateTime.now())
                        && !ComplaintStatus.from(item.getStatus()).isTerminal());
        result.put(
                "resident_name",
                item.getResidentId() == null
                        ? null
                        : users.findById(item.getResidentId())
                                .map(UserAccount::getFullName)
                                .orElse(null));
        result.put(
                "created_by_name",
                users.findById(item.getCreatedBy()).map(UserAccount::getFullName).orElse(null));
        result.put(
                "assigned_to_name",
                item.getAssignedTo() == null
                        ? null
                        : users.findById(item.getAssignedTo())
                                .map(UserAccount::getFullName)
                                .orElse(null));
        result.put(
                "category_name",
                item.getCategoryId() == null
                        ? "General"
                        : categories
                                .findById(item.getCategoryId())
                                .map(ComplaintCategory::getName)
                                .orElse("General"));
        if (item.getFlatId() != null) {
            flats.findById(item.getFlatId())
                    .ifPresent(
                            flat -> {
                                result.put("space_number", flat.getFlatNumber());
                                floors.findById(flat.getFloorId())
                                        .flatMap(floor -> blocks.findById(floor.getBlockId()))
                                        .ifPresent(block -> result.put("block", block.getName()));
                            });
        }
        return result;
    }

    private Map<String, Object> updateView(ComplaintUpdate update) {
        var result = new LinkedHashMap<String, Object>();
        result.put("id", update.getId());
        result.put("event_type", update.getEventType());
        result.put("from_status", update.getFromStatus());
        result.put("to_status", update.getToStatus());
        result.put("note", update.getNote());
        result.put("created_at", update.getCreatedAt());
        result.put(
                "actor_name",
                users.findById(update.getActorUserId()).map(UserAccount::getFullName).orElse(null));
        return result;
    }
}
