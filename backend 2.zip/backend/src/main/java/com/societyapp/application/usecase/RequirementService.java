package com.societyapp.application.usecase;

import com.societyapp.application.exception.ResourceNotFoundException;
import com.societyapp.application.mapper.ApiViewMapper;
import com.societyapp.application.port.in.RequirementUseCase;
import com.societyapp.application.port.out.JsonCodec;
import com.societyapp.application.port.out.JsonCodecException;
import com.societyapp.application.port.out.persistence.*;
import com.societyapp.domain.model.*;
import com.societyapp.domain.type.BillingCycle;
import com.societyapp.domain.type.CustomPlanStatus;
import com.societyapp.domain.type.RequirementStatus;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;

public class RequirementService implements RequirementUseCase {
    private final RequirementRequestRepository requirements;
    private final SocietyCustomPlanRepository customPlans;
    private final SocietyRepository societies;
    private final UserAccountJpaRepository users;
    private final JsonCodec json;
    private final ApiViewMapper views;

    public RequirementService(
            RequirementRequestRepository requirements,
            SocietyCustomPlanRepository customPlans,
            SocietyRepository societies,
            UserAccountJpaRepository users,
            JsonCodec json,
            ApiViewMapper views) {
        this.requirements = requirements;
        this.customPlans = customPlans;
        this.societies = societies;
        this.users = users;
        this.json = json;
        this.views = views;
    }

    public Map<String, Object> submit(
            UUID societyId,
            String societyName,
            String contact,
            String email,
            String mobile,
            String city,
            Integer estimatedFlats,
            Integer estimatedStaff,
            List<String> modules,
            String details,
            BigDecimal budget) {
        if (societyId != null && !societies.existsById(societyId)) {
            throw new ResourceNotFoundException("Society not found");
        }
        var request = new RequirementRequest();
        request.setSocietyId(societyId);
        request.setSocietyName(societyName);
        request.setContactPerson(contact);
        request.setEmail(email);
        request.setMobile(mobile);
        request.setCity(city);
        request.setEstimatedFlats(estimatedFlats);
        request.setEstimatedStaff(estimatedStaff);
        request.setRequestedModules(writeJson(modules));
        request.setRequirementDetails(details);
        request.setBudgetMonthly(budget);
        request.setStatus(RequirementStatus.NEW.code());
        request.setCreatedAt(OffsetDateTime.now());
        request.setUpdatedAt(OffsetDateTime.now());
        request = requirements.save(request);
        return Map.of(
                "requirementId", request.getId(),
                "status", RequirementStatus.NEW.code(),
                "message", "Our platform team will contact you.");
    }

    public List<Map<String, Object>> list() {
        return requirements.findAllByOrderByCreatedAtDesc().stream()
                .sorted(
                        Comparator.comparingInt(
                                item -> RequirementStatus.from(item.getStatus()).order()))
                .map(this::requirementView)
                .toList();
    }

    public Map<String, Object> review(UUID id, UUID reviewerId, String status, String notes) {
        var request =
                requirements
                        .findById(id)
                        .orElseThrow(() -> new ResourceNotFoundException("Requirement not found"));
        var requestedStatus = RequirementStatus.from(status);
        request.setStatus(requestedStatus.code());
        if (notes != null) request.setAdminNotes(notes);
        request.setAssignedTo(reviewerId);
        request.setUpdatedAt(OffsetDateTime.now());
        request.setClosedAt(requestedStatus.isClosed() ? OffsetDateTime.now() : null);
        requirements.save(request);
        return Map.of("id", id, "status", requestedStatus.code());
    }

    public Map<String, Object> createPlan(
            UUID creatorId,
            UUID societyId,
            UUID requirementId,
            String name,
            String description,
            List<String> modules,
            Integer maxFlats,
            Integer maxStaff,
            Integer maxStorage,
            BigDecimal pricePerSpace,
            BigDecimal pricePerStaff,
            BigDecimal fixedMonthlyPrice,
            BigDecimal setupFee,
            String billingCycle,
            LocalDate validFrom,
            LocalDate validUntil,
            String status) {
        validateDates(validFrom, validUntil);
        if (!societies.existsById(societyId)) {
            throw new ResourceNotFoundException("Society not found");
        }
        var requestedStatus = CustomPlanStatus.from(status);
        if (requestedStatus == CustomPlanStatus.ACTIVE) {
            replaceOtherActivePlans(societyId, null);
        }
        var plan = new SocietyCustomPlan();
        plan.setSocietyId(societyId);
        plan.setRequirementId(requirementId);
        applyPlanFields(
                plan,
                name,
                description,
                modules,
                maxFlats,
                maxStaff,
                maxStorage,
                pricePerSpace,
                pricePerStaff,
                fixedMonthlyPrice,
                setupFee,
                billingCycle,
                validFrom,
                validUntil,
                status);
        plan.setCreatedBy(creatorId);
        plan.setCreatedAt(OffsetDateTime.now());
        plan.setActivatedAt(
                requestedStatus == CustomPlanStatus.ACTIVE ? OffsetDateTime.now() : null);
        plan = customPlans.save(plan);
        if (requirementId != null) {
            requirements
                    .findById(requirementId)
                    .ifPresent(
                            request -> {
                                request.setSocietyId(societyId);
                                request.setStatus(RequirementStatus.ACCEPTED.code());
                                request.setUpdatedAt(OffsetDateTime.now());
                                requirements.save(request);
                            });
        }
        return Map.of(
                "customPlanId", plan.getId(),
                "societyId", societyId,
                "status", requestedStatus.code());
    }

    public Map<String, Object> updatePlan(
            UUID id,
            String name,
            String description,
            List<String> modules,
            Integer maxFlats,
            Integer maxStaff,
            Integer maxStorage,
            BigDecimal pricePerSpace,
            BigDecimal pricePerStaff,
            BigDecimal fixedMonthlyPrice,
            BigDecimal setupFee,
            String billingCycle,
            LocalDate validFrom,
            LocalDate validUntil,
            String status) {
        validateDates(validFrom, validUntil);
        var plan =
                customPlans
                        .findById(id)
                        .orElseThrow(() -> new ResourceNotFoundException("Custom plan not found"));
        var currentStatus = CustomPlanStatus.from(plan.getStatus());
        var requestedStatus = CustomPlanStatus.from(status);
        if (currentStatus == CustomPlanStatus.REPLACED
                || currentStatus == CustomPlanStatus.CANCELLED) {
            throw new IllegalArgumentException(
                    "A replaced or cancelled custom plan is an immutable history record");
        }
        if (currentStatus == CustomPlanStatus.ACTIVE && requestedStatus == CustomPlanStatus.DRAFT) {
            throw new IllegalArgumentException(
                    "An active custom plan cannot return to draft; activate a replacement instead");
        }
        if (requestedStatus == CustomPlanStatus.ACTIVE) {
            replaceOtherActivePlans(plan.getSocietyId(), id);
        }
        applyPlanFields(
                plan,
                name,
                description,
                modules,
                maxFlats,
                maxStaff,
                maxStorage,
                pricePerSpace,
                pricePerStaff,
                fixedMonthlyPrice,
                setupFee,
                billingCycle,
                validFrom,
                validUntil,
                status);
        if (requestedStatus == CustomPlanStatus.ACTIVE && plan.getActivatedAt() == null) {
            plan.setActivatedAt(OffsetDateTime.now());
        }
        customPlans.save(plan);
        return Map.of(
                "customPlanId",
                id,
                "societyId",
                plan.getSocietyId(),
                "status",
                requestedStatus.code());
    }

    public Map<String, Object> cancelPlan(UUID id, UUID actorId, String reason) {
        var plan =
                customPlans
                        .findById(id)
                        .orElseThrow(() -> new ResourceNotFoundException("Custom plan not found"));
        var currentStatus = CustomPlanStatus.from(plan.getStatus());
        if (currentStatus != CustomPlanStatus.DRAFT && currentStatus != CustomPlanStatus.ACTIVE) {
            throw new IllegalStateException("Only a Draft or Active custom plan can be cancelled");
        }
        if (reason == null || reason.isBlank()) {
            throw new IllegalArgumentException("Cancellation reason is required");
        }
        plan.setStatus(CustomPlanStatus.CANCELLED.code());
        plan.setCancelledBy(actorId);
        plan.setCancelledAt(OffsetDateTime.now());
        plan.setCancellationReason(reason.trim());
        customPlans.save(plan);
        return Map.of(
                "customPlanId",
                id,
                "societyId",
                plan.getSocietyId(),
                "status",
                CustomPlanStatus.CANCELLED.code());
    }

    public List<Map<String, Object>> plans() {
        return customPlans.findAllByOrderByCreatedAtDesc().stream().map(this::planView).toList();
    }

    private Map<String, Object> requirementView(RequirementRequest request) {
        var map = beanMap(request);
        map.put("requested_modules_text", request.getRequestedModules());
        map.put(
                "linked_society_name",
                request.getSocietyId() == null
                        ? null
                        : societies
                                .findById(request.getSocietyId())
                                .map(Society::getName)
                                .orElse(null));
        map.put(
                "assigned_to_name",
                request.getAssignedTo() == null
                        ? null
                        : users.findById(request.getAssignedTo())
                                .map(UserAccount::getFullName)
                                .orElse(null));
        return map;
    }

    private Map<String, Object> planView(SocietyCustomPlan plan) {
        var map = beanMap(plan);
        map.put("enabled_modules_text", plan.getEnabledModules());
        map.put(
                "society_name",
                societies.findById(plan.getSocietyId()).map(Society::getName).orElse(null));
        map.put(
                "requirement_details",
                plan.getRequirementId() == null
                        ? null
                        : requirements
                                .findById(plan.getRequirementId())
                                .map(RequirementRequest::getRequirementDetails)
                                .orElse(null));
        return map;
    }

    private void validateDates(LocalDate validFrom, LocalDate validUntil) {
        if (validUntil != null && validUntil.isBefore(validFrom)) {
            throw new IllegalArgumentException("Valid-until must be after valid-from");
        }
    }

    private void replaceOtherActivePlans(UUID societyId, UUID excludedPlanId) {
        customPlans.findAll().stream()
                .filter(plan -> societyId.equals(plan.getSocietyId()))
                .filter(plan -> CustomPlanStatus.ACTIVE.matches(plan.getStatus()))
                .filter(plan -> excludedPlanId == null || !excludedPlanId.equals(plan.getId()))
                .forEach(
                        plan -> {
                            plan.setStatus(CustomPlanStatus.REPLACED.code());
                            customPlans.save(plan);
                        });
    }

    private void applyPlanFields(
            SocietyCustomPlan plan,
            String name,
            String description,
            List<String> modules,
            Integer maxFlats,
            Integer maxStaff,
            Integer maxStorage,
            BigDecimal pricePerSpace,
            BigDecimal pricePerStaff,
            BigDecimal fixedMonthlyPrice,
            BigDecimal setupFee,
            String billingCycle,
            LocalDate validFrom,
            LocalDate validUntil,
            String status) {
        var fixed = fixedMonthlyPrice == null ? BigDecimal.ZERO : fixedMonthlyPrice;
        if (fixed.signum() > 0 && (pricePerSpace.signum() > 0 || pricePerStaff.signum() > 0)) {
            throw new IllegalArgumentException(
                    "Choose either a fixed monthly price or per-space/per-staff rates");
        }
        plan.setPlanName(name);
        plan.setDescription(description);
        plan.setEnabledModules(writeJson(modules));
        plan.setMaxFlats(maxFlats);
        plan.setMaxStaff(maxStaff);
        plan.setMaxStorageGb(maxStorage);
        plan.setPricePerSpace(pricePerSpace);
        plan.setPricePerStaff(pricePerStaff);
        plan.setPriceMonthly(fixed);
        plan.setSetupFee(setupFee == null ? BigDecimal.ZERO : setupFee);
        plan.setBillingCycle(BillingCycle.from(billingCycle).code());
        plan.setValidFrom(validFrom);
        plan.setValidUntil(validUntil);
        plan.setStatus(CustomPlanStatus.from(status).code());
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> beanMap(Object value) {
        return views.toMap(value);
    }

    private String writeJson(List<String> values) {
        try {
            return json.write(values);
        } catch (JsonCodecException exception) {
            throw new IllegalArgumentException("Invalid module list", exception);
        }
    }
}
